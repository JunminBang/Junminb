extends Node
## 방 진행 + 보스 + 사망/메타 스모크 테스트.
## 실행: godot --headless --path . res://tests/test_arena.tscn   (성공 시 exit 0)

const MainScene := preload("res://scenes/Main.tscn")

var arena: Node2D
var player: Node2D
var _run_result := [999]   # run_ended(cleared) 를 받아 기록


func _ready() -> void:
	_watchdog()
	Meta.reset()
	Inventory.reset()
	Research.reset()
	arena = MainScene.instantiate()
	add_child(arena)
	await _frames(3)
	player = arena.get_node("Player")
	player.invulnerable = true   # 방 이동 중엔 안 죽게
	arena.run_ended.connect(func(c): _run_result[0] = (1 if c else 0))

	# --- 1. 방 6개 (입구 + 전투 4 + 보스), 각 방에 벽(StaticBody2D) ---
	assert(arena.rooms.size() == 6, "방이 6개가 아님 (%d)" % arena.rooms.size())
	for r in arena.rooms:
		var walls := 0
		for c in r.get_children():
			if c is StaticBody2D:
				walls += 1
		assert(walls >= 3, "방에 벽이 부족함")

	# --- 2. 왼쪽 밖으로 못 나간다 ---
	var minx: float = arena.rooms[0].global_position.x - 480.0
	player.move_target = Vector2(minx - 400.0, 0)
	player.has_move_target = true
	await _frames(40)
	assert(player.global_position.x > minx + 10.0,
		"벽을 뚫고 왼쪽으로 나감 (x=%.0f)" % player.global_position.x)

	# --- 3. 전투방 4개를 강제 클리어하며 전진 (점점 어려워짐: 마지막 방이 첫 방보다 웨이브 물량 많음) ---
	var bi: int = arena.rooms.size() - 1   # 보스방 인덱스
	var saw_ranged := false
	for i in range(1, bi):
		player.global_position = arena.rooms[i].global_position
		await _frames(4)
		assert(arena.rooms[i]._started, "방 %d 이 시작되지 않음" % i)
		var guard := 0
		while not arena.rooms[i]._done and guard < 600:
			for e in get_tree().get_nodes_in_group("enemy"):
				if is_instance_valid(e) and not e.is_in_group("boss"):
					if e.weight == 3:
						saw_ranged = true
					e.queue_free()
			await _frames(2)
			guard += 1
		assert(arena.rooms[i]._done, "방 %d 클리어 실패" % i)
	assert(saw_ranged, "원거리 적(RANGED)이 한 방에도 안 나옴")
	assert(arena.rooms[bi - 1].waves[-1].size() > arena.rooms[1].waves[0].size(),
		"뒷 방이 앞 방보다 안 어려움")

	# --- 4. 보스방 진입 → 보스 스폰 ---
	player.global_position = arena.rooms[bi].global_position
	await _frames(10)
	var boss: Node = arena.rooms[bi].boss
	assert(boss != null, "보스가 스폰되지 않음")
	assert(boss.is_in_group("enemy"), "보스가 enemy 그룹에 없어 플레이어 공격이 안 닿음")

	# --- 5. 패턴 10종 완주 + 근접 플레이어가 실제로 맞는다 ---
	boss.phased = true
	boss.phase = 2
	boss.invuln = true
	player.dead = false
	player.invulnerable = false
	player.max_hp = 100000
	player.hp = 100000
	player.hurt_time = 0.05
	var pool: Array = boss.POOL_1 + boss.POOL_2
	assert(pool.size() == 10, "패턴이 10개가 아님 (%d)" % pool.size())
	for pat in pool:
		player.global_position = boss.global_position + Vector2(50, 0)
		boss.st = boss.St.IDLE
		boss.t = 0.0
		boss.pattern = ""
		await _frames(2)
		var pguard := 0
		while boss.st != boss.St.IDLE and pguard < 200:
			await _frames(1)
			pguard += 1
		assert(pguard < 200, "패턴이 끝나지 않고 멈춤: %s" % boss.pattern)
	assert(player.hp < 100000, "보스 패턴이 근접한 플레이어를 한 번도 못 맞힘")

	# --- 5b. 피격 시 화면이 빨개진다 ---
	var hp_pre: int = player.hp
	player.hurt_timer = 0.0
	player.take_hit(40, Vector2.RIGHT, 0.0)
	await _frames(3)
	assert(player.hp < hp_pre, "피격이 안 들어감")
	assert(arena.get_node("Hud")._flash_a > 0.1, "피격 시 화면 빨개짐이 안 걸림")

	# --- 6. 보스 처치 → 아레나 클리어 + run_ended(true) + 영혼 획득 ---
	boss.invuln = false
	var souls_before: int = Meta.souls
	var kguard := 0
	while is_instance_valid(boss) and kguard < 400:
		if is_instance_valid(boss):
			boss.take_hit(300, Vector2.DOWN, 0.0)
		await get_tree().physics_frame
		kguard += 1
	assert(not is_instance_valid(boss), "보스가 죽지 않음")
	await get_tree().physics_frame
	assert(arena._boss_dead, "보스 처치 후 아레나 클리어 처리 안 됨")
	assert(_run_result[0] == 1, "보스 클리어 시 run_ended(true) 가 안 나옴")
	assert(Meta.souls > souls_before, "보스 처치 시 영혼이 안 들어옴")

	print("test_arena: OK")
	Meta.reset()
	get_tree().quit(0)


func _frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame


func _watchdog() -> void:
	await get_tree().create_timer(55.0).timeout
	push_error("test_arena: WATCHDOG TIMEOUT")
	get_tree().quit(2)
