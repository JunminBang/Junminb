extends Node
## 최소 런타임 자체검증.
## 실행: godot --headless --path . res://tests/test_combat.tscn   (성공 시 exit 0)

const PlayerScene := preload("res://scenes/Player.tscn")
const EnemyScene := preload("res://scenes/Enemy.tscn")


func _ready() -> void:
	_watchdog()
	Meta.reset()   # 저장 파일에 좌우되지 않도록
	Inventory.reset()
	Research.reset()
	var p := PlayerScene.instantiate()
	add_child(p)
	await get_tree().physics_frame
	var start: Vector2 = p.global_position

	# --- 1. 우클릭 홀드 이동 ---
	Input.action_press(&"move_to")
	for i in 20:
		await get_tree().physics_frame
	assert(p.has_move_target, "우클릭 홀드 중 이동 목표가 유지되지 않음")
	assert(p.global_position.distance_to(start) > 5.0, "이동 명령 후 안 움직임")
	# 젤리: 이동 중엔 스케일이 1에서 벗어나 있어야 한다 (스쿼시-스트레치)
	assert(p.jelly.scale.distance_to(Vector2.ONE) > 0.01, "이동 중 젤리 변형이 없음")
	Input.action_release(&"move_to")

	# --- 2. 좌클릭 평타 시전 — GCD 와 무관 ---
	await _idle(p)
	p._input(_lclick())
	await get_tree().physics_frame
	await get_tree().physics_frame
	assert(p.state != p.State.IDLE, "좌클릭 평타가 시전되지 않음")
	assert(p.gcd_timer == 0.0, "평타가 GCD 를 걸어버림 (독립이어야 함)")

	# --- 2b. Space 대시 ---
	await _idle(p)
	p._input(_key(KEY_SPACE))
	await get_tree().physics_frame
	await get_tree().physics_frame
	assert(p.state == p.State.DASH or p.dash_cd_timer > 0.0, "Space 대시가 안 됨")
	await _idle(p)

	# --- 3. 스킬 Q -> 쿨다운 ---
	await _idle(p)
	p._input(_key(KEY_Q))
	await get_tree().physics_frame
	await get_tree().physics_frame
	assert(p.cooldowns["Q"] > 0.0, "스킬 Q 사용 후 쿨다운이 안 걸림")
	assert(p.gcd_timer > 0.0, "스킬 시전 후 글로벌 쿨타임이 안 걸림")

	# --- 3b. GCD 중엔 다음 스킬이 안 나가고, GCD 가 풀리면 예약이 자동 발동 (딜사이클) ---
	p._input(_key(KEY_E))                     # GCD 도는 중 E 예약
	for i in 4:
		await get_tree().physics_frame
	assert(p.cooldowns["E"] == 0.0, "GCD 중인데 다음 스킬이 시전됨")
	p.gcd_timer = 0.0                         # GCD 해제
	for i in 6:
		await get_tree().physics_frame
	assert(p.cooldowns["E"] > 0.0, "GCD 가 풀렸는데 예약된 스킬이 안 이어짐")

	# --- 4. 피격: HP 감소 + 게이지 증가 ---
	await _idle(p)
	p.hp = p.max_hp
	p.invulnerable = false
	p.hurt_timer = 0.0
	var g0: float = p.ultimate_gauge
	p.take_hit(10, Vector2.RIGHT, 200.0)
	assert(p.hp == p.max_hp - 10, "피격 시 HP 가 안 깎임")
	assert(p.ultimate_gauge > g0, "피격 시 필살기 게이지가 안 참")
	await get_tree().physics_frame
	await get_tree().physics_frame
	assert(p.jelly._sv.length() > 0.01 or p.jelly.scale.distance_to(Vector2.ONE) > 0.01,
		"피격 시 젤리 변형(poke)이 없음")
	await _idle(p)
	for i in 90:
		await get_tree().physics_frame
	assert(p.jelly.scale.distance_to(Vector2.ONE) < 0.1, "정지 후 젤리가 원래대로 안 돌아옴")

	# --- 5. 무적 프레임: iframe 중엔 피해 없음 ---
	p.hp = p.max_hp
	p.hurt_timer = 0.0
	p.invulnerable = true
	p.take_hit(10, Vector2.RIGHT, 200.0)
	assert(p.hp == p.max_hp, "무적 중인데 피해를 받음")
	p.invulnerable = false

	# --- 6. 필살기: 게이지 100%에서 발동하며 게이지를 소모 ---
	await _idle(p)
	p.ultimate_gauge = p.GAUGE_MAX
	p._input(_key(KEY_R))
	await get_tree().physics_frame
	await get_tree().physics_frame
	assert(p.ultimate_gauge == 0.0, "필살기 발동 후 게이지가 안 비워짐")

	# --- 7. 넉백 3단계: 경량이 고정형보다 훨씬 많이 밀림 ---
	var light := EnemyScene.instantiate()
	light.weight = 0  # LIGHT
	add_child(light)
	var fixed := EnemyScene.instantiate()
	fixed.weight = 2  # FIXED
	add_child(fixed)
	await get_tree().physics_frame
	light.take_hit(5, Vector2.RIGHT, 300.0)
	fixed.take_hit(5, Vector2.RIGHT, 300.0)
	assert(light.knockback.length() > fixed.knockback.length() + 50.0,
		"체급별 넉백 차등이 적용되지 않음 (light=%.0f fixed=%.0f)" % [light.knockback.length(), fixed.knockback.length()])

	# --- 7b. 연타 스턴락 방지: 계속 때려도 HURT 에 영구히 갇히지 않는다 ---
	var lock := EnemyScene.instantiate()
	lock.weight = 0
	add_child(lock)
	await get_tree().physics_frame
	var escaped := false
	for i in 45:
		lock.take_hit(0, Vector2.RIGHT, 60.0)   # 데미지 0으로 계속 툭툭
		await get_tree().physics_frame
		await get_tree().physics_frame
		if lock.st != lock.S.HURT and lock.stagger_immune > 0.0:
			escaped = true
			break
	assert(escaped, "연타로 적이 경직에서 못 벗어남 (스턴락)")
	lock.queue_free()

	# --- 8. 몬스터가 플레이어를 때린다 (통합) ---
	# 앞 테스트의 플레이어/적을 정리해 그룹을 깨끗이 (get_first_node_in_group 이 엉뚱한 걸 잡지 않도록)
	p.queue_free()
	light.queue_free()
	fixed.queue_free()
	await get_tree().physics_frame
	var p2 := PlayerScene.instantiate()
	add_child(p2)
	p2.position = Vector2(2000, 0)
	var foe := EnemyScene.instantiate()
	foe.weight = 0
	add_child(foe)
	foe.position = p2.position + Vector2(36, 0)
	await get_tree().physics_frame
	var hp0: int = p2.hp
	for i in 120:   # TELE(0.5) + ATTACK(0.13) + 여유
		await get_tree().physics_frame
	assert(p2.hp < hp0, "몬스터가 플레이어에게 피해를 주지 못함 (hp %d -> %d)" % [hp0, p2.hp])

	# --- 9. 사망: dead 플래그 + died 시그널 ---
	var got_died := [false]
	p2.died.connect(func(): got_died[0] = true)
	p2.hp = 3
	p2.invulnerable = false
	p2.hurt_timer = 0.0
	p2.take_hit(999, Vector2.RIGHT, 0.0)
	assert(p2.dead, "치명타를 맞아도 dead 플래그가 안 섬")
	assert(got_died[0], "사망 시 died 시그널이 안 나옴")
	p2.hurt_timer = 0.0
	p2.take_hit(10, Vector2.RIGHT, 0.0)
	assert(p2.hp == 0, "죽은 뒤에도 피해를 받음")

	# --- 10. 메타 성장: 구매 / 비용 증가 / 보너스 / 플레이어 반영 ---
	Meta.reset()
	Meta.souls = 300
	var c0 := Meta.cost("max_hp")
	assert(Meta.buy("max_hp"), "영혼이 충분한데 구매 실패")
	assert(Meta.level("max_hp") == 1, "구매 후 레벨이 안 오름")
	assert(is_equal_approx(Meta.bonus("max_hp"), 18.0), "보너스 계산 오류")
	assert(Meta.cost("max_hp") > c0, "구매 후 비용이 안 올라감")
	assert(Meta.souls == 300 - c0, "영혼 차감 오류")
	var p3 := PlayerScene.instantiate()
	add_child(p3)
	await get_tree().physics_frame
	assert(p3.max_hp >= 118, "메타 최대체력 보너스가 플레이어에 반영 안 됨 (%d)" % p3.max_hp)

	# --- 12. 빌드 정의 강화: 파쇄격 = 평타 3타 광역화 ---
	Meta.reset()
	Meta.levels = {"combo_blast": 1}
	var p4 := PlayerScene.instantiate()
	add_child(p4)
	await get_tree().physics_frame
	assert(p4._combo_blast, "combo_blast 강화가 플레이어에 반영 안 됨")
	p4.combo_index = 2   # 3타째
	var bd: Dictionary = p4._basic_data()
	assert(bd["half_angle"] >= PI, "파쇄격인데 3타째가 전방위가 아님")
	Meta.reset()
	Meta.reset()

	# --- 11. 영혼 드랍 아이템 + 획득 ---
	p2.queue_free()
	p3.queue_free()
	await get_tree().physics_frame
	Meta.reset()
	var pc := PlayerScene.instantiate()
	add_child(pc)
	pc.global_position = Vector2(-4000, 0)   # 다른 노드와 분리
	await get_tree().physics_frame
	var foec := EnemyScene.instantiate()
	foec.weight = 1
	add_child(foec)
	foec.global_position = pc.global_position + Vector2(28, 0)
	await get_tree().physics_frame
	foec.take_hit(9999, Vector2.RIGHT, 0.0)   # 즉사 → 영혼 드랍
	await get_tree().physics_frame
	assert(get_tree().get_nodes_in_group("pickup").size() > 0, "영혼이 드랍 아이템으로 안 나옴")
	var sb := Meta.souls
	for i in 150:
		await get_tree().physics_frame
	assert(Meta.souls > sb, "근처 플레이어가 영혼을 못 먹음 (%d -> %d)" % [sb, Meta.souls])
	Meta.reset()

	# --- 13. 채집 자원 노드: 부수면 자원이 인벤토리에 들어온다 ---
	pc.queue_free()
	Inventory.reset()
	var pw := PlayerScene.instantiate()
	add_child(pw)
	pw.global_position = Vector2(6000, 0)
	await get_tree().physics_frame
	var rnode: Node = load("res://scenes/ResourceNode.tscn").instantiate()
	rnode.kind = "wood"
	add_child(rnode)
	rnode.global_position = pw.global_position + Vector2(22, 0)
	await get_tree().physics_frame
	assert(rnode.is_in_group("harvestable"), "자원 노드가 harvestable 그룹에 없음")
	rnode.take_hit(9999, Vector2.RIGHT, 0.0)   # 즉시 파괴
	await get_tree().physics_frame
	assert(get_tree().get_nodes_in_group("pickup").size() > 0, "자원이 드랍 아이템으로 안 나옴")
	var wb := Inventory.amount("wood")
	for i in 150:
		await get_tree().physics_frame
	assert(Inventory.amount("wood") > wb, "채집 자원이 인벤토리에 안 들어옴 (%d -> %d)" % [wb, Inventory.amount("wood")])
	Inventory.reset()
	Meta.reset()

	# --- 14. 영혼 제단 (Altar): 열기 / 리롤(영혼 소비) / 오퍼 구매 ---
	Meta.reset()
	Meta.souls = 500
	var altar := CanvasLayer.new()
	altar.set_script(load("res://scripts/Altar.gd"))
	add_child(altar)
	await get_tree().physics_frame
	altar.open_shop()
	assert(altar.visible and get_tree().paused, "제단이 안 열림 / 일시정지 안 됨")
	assert(Meta.offer.size() == 3, "제단 오퍼 3종이 아님")
	var arc: int = altar._reroll_cost()
	var as0: int = Meta.souls
	altar._do_reroll()
	assert(Meta.souls == as0 - arc, "리롤이 영혼을 안 씀")
	var apick: String = Meta.offer[0]
	var alv0: int = Meta.level(apick)
	altar._buy(apick)
	assert(Meta.level(apick) == alv0 + 1, "제단 오퍼 구매가 안 됨")
	altar._close_shop()
	assert(not altar.visible and not get_tree().paused, "제단이 안 닫힘")
	Meta.reset()

	# --- 15. 연구: 잠긴 강화 해금 + 패시브 적용 ---
	Meta.reset()
	Research.reset()
	Inventory.reset()
	Meta.roll_offer()
	assert(not Meta._available().has("dash_slash"), "연구 전인데 dash_slash 가 오퍼 풀에 있음")
	Inventory.add("wood", 20)
	Inventory.add("herb", 10)
	assert(Research.can_research("blade_arts"), "자원 있는데 blade_arts 연구 불가")
	assert(Research.research("blade_arts"), "blade_arts 연구 실패")
	assert(Research.is_upgrade_unlocked("dash_slash"), "연구했는데 dash_slash 해금 안 됨")
	assert(Meta._available().has("dash_slash"), "해금됐는데 오퍼 풀에 안 들어옴")
	assert(Inventory.amount("wood") == 8, "연구 비용(목재 12)이 안 빠짐 (%d)" % Inventory.amount("wood"))
	assert(not Research.requires_met("vitality"), "선행(toughness) 없이 vitality 가능으로 뜸")
	Inventory.add("stone", 10)
	Research.research("toughness")
	var pr := PlayerScene.instantiate()
	add_child(pr)
	await get_tree().physics_frame
	assert(pr._armor >= 1, "연구 패시브(armor)가 플레이어에 반영 안 됨")
	Meta.reset()
	Research.reset()
	Inventory.reset()

	print("test_combat: OK")
	get_tree().quit(0)


func _watchdog() -> void:
	await get_tree().create_timer(45.0).timeout
	push_error("test_combat: WATCHDOG TIMEOUT")
	get_tree().quit(2)


func _idle(p: Node) -> void:
	for i in 120:
		await get_tree().physics_frame
		if p.state == p.State.IDLE and p.hurt_timer <= 0.0 and p.gcd_timer <= 0.0:
			return


func _lclick() -> InputEventMouseButton:
	var e := InputEventMouseButton.new()
	e.button_index = MOUSE_BUTTON_LEFT
	e.pressed = true
	e.position = Vector2(500, 120)
	return e


func _key(k: Key) -> InputEventKey:
	var e := InputEventKey.new()
	e.physical_keycode = k
	e.pressed = true
	return e
