extends Node
## 자동 플레이 봇 — Main.tscn 을 실제로 돌려 6개 방 + 보스 클리어를 시도하고 리포트한다.
## 죽으면 진짜 게임처럼 제단에서 강화를 사고 처음부터 다시 시작한다 (런 루프).
## 실행: godot --headless --path . res://tests/playthrough.tscn

const DEATH_CAP := 15
const RUN_SECONDS := 320.0

var arena: Node2D
var p: Node2D
var deaths := 0
var best_room := 0
var _last_room := -1
var _last_wave := {}
var _t := 0.0
var _log: Array[String] = []
var _busy := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	Meta.reset()
	Inventory.reset()
	Research.reset()
	_watchdog()
	_new_run(false)
	_say("시작 — 방 %d개, 사망 %d회까지 시도" % [arena.rooms.size(), DEATH_CAP])


func _new_run(is_restart: bool) -> void:
	_busy = true
	if is_instance_valid(arena):
		arena.queue_free()
		await get_tree().physics_frame
	get_tree().paused = false
	arena = load("res://scenes/Main.tscn").instantiate()
	add_child(arena)
	await get_tree().physics_frame
	await get_tree().physics_frame
	p = arena.get_node("Player")
	_last_room = -1
	_last_wave = {}
	if is_restart:
		_say("[%5.1fs] ── 재시작 #%d — HP %d, 강화: %s" % [_t, deaths, p.max_hp, _levels_str()])
	_busy = false


func _physics_process(delta: float) -> void:
	_t += delta
	if _busy or not is_instance_valid(p):
		return

	if arena._boss_dead:
		_finish(true)
		return

	if p.dead:
		_on_death()
		return

	var ri: int = arena._reached
	best_room = maxi(best_room, ri)
	if ri != _last_room:
		_last_room = ri
		var kind := "보스방" if arena.rooms[ri].is_boss else ("입구" if ri == 0 else "전투방")
		_say("[%5.1fs] 방 %d (%s) — HP %d/%d, 영혼 %d" % [_t, ri, kind, p.hp, p.max_hp, Meta.souls])

	var room: Node = arena.rooms[ri]
	if not room.is_boss and room._started:
		var w: int = room._wave_i
		if _last_wave.get(ri, -99) != w and w < room.waves.size():
			_last_wave[ri] = w
			_say("[%5.1fs]   웨이브 %d — 적 %d" % [_t, w + 1, _enemies_in(room).size()])

	if room.is_boss and is_instance_valid(room.boss):
		_fight(room.boss, true)
	else:
		var foe: Node2D = _nearest(room)
		if foe:
			_fight(foe, false)
		elif ri + 1 < arena.rooms.size():
			p.move_target = arena.rooms[ri + 1].global_position
			p.has_move_target = true


# ------------------------------------------------------------------ 전투
func _fight(target: Node2D, is_boss: bool) -> void:
	var to: Vector2 = target.global_position - p.global_position
	var d := to.length()
	var dir := to.normalized() if d > 1.0 else Vector2.RIGHT

	# 회피
	if p.dash_cd_timer <= 0.0 and not p.invulnerable:
		var danger := _danger(is_boss)
		var low: bool = float(p.hp) < float(p.max_hp) * (0.55 if is_boss else 0.32)
		if danger != Vector2.ZERO or low:
			p.facing = (danger if danger != Vector2.ZERO else -dir).normalized()
			p._buffer("DASH")
			return

	# 간격
	var want := (240.0 if is_boss else 95.0)
	if d > want + 25.0:
		p.move_target = target.global_position
		p.has_move_target = true
	elif d < want - 45.0:
		p.move_target = p.global_position - dir * 130.0
		p.has_move_target = true
	else:
		p.has_move_target = false

	p.facing = dir

	# 스킬: R > W(무적 진입) > Q > E > 평타
	if p.ultimate_gauge >= p.GAUGE_MAX:
		p._buffer("R")
	elif p.gcd_timer <= 0.0:
		if float(p.cooldowns["W"]) <= 0.0 and d > 55.0:
			p._buffer("W")
		elif float(p.cooldowns["Q"]) <= 0.0:
			p._buffer("Q")
		elif float(p.cooldowns["E"]) <= 0.0 and (is_boss or _enemies_in(arena.rooms[arena._reached]).size() >= 2):
			p._buffer("E")
		else:
			p._buffer("BASIC")
	else:
		p._buffer("BASIC")


func _danger(is_boss: bool) -> Vector2:
	var proj_reach := 115.0 if is_boss else 75.0
	for h in get_tree().get_nodes_in_group("hazard"):
		if not is_instance_valid(h):
			continue
		var off: Vector2 = p.global_position - h.global_position
		if h.has_method("_contains"):   # AoeWarning
			if h._t / maxf(0.01, h.tele) > 0.4 and h._contains(p.global_position):
				return off.normalized() if off.length() > 1.0 else Vector2.RIGHT
		elif off.length() < proj_reach: # Projectile
			return Vector2(-h.velocity.y, h.velocity.x).normalized()
	# 보스가 예고/실행 중이고 가까우면 무조건 벌린다
	if is_boss:
		var b: Node = arena.rooms[arena._reached].boss
		if is_instance_valid(b) and (b.st == b.St.TELE or b.st == b.St.ACT):
			if p.global_position.distance_to(b.global_position) < 230.0:
				return (p.global_position - b.global_position).normalized()
	return Vector2.ZERO


func _nearest(room: Node) -> Node2D:
	var best: Node2D = null
	var bd := 1e9
	for e in _enemies_in(room):
		var dd: float = p.global_position.distance_squared_to(e.global_position)
		if dd < bd:
			bd = dd
			best = e
	return best


func _enemies_in(room: Node) -> Array:
	var b: Rect2 = room.bounds()
	return get_tree().get_nodes_in_group("enemy").filter(
		func(e): return is_instance_valid(e) and not e.is_in_group("boss") and b.has_point(e.global_position))


# ------------------------------------------------------------------ 사망 → 강화 → 재시작
func _on_death() -> void:
	deaths += 1
	_say("[%5.1fs] ☠ 사망 #%d (방 %d) — 영혼 %d" % [_t, deaths, arena._reached, Meta.souls])
	if deaths >= DEATH_CAP:
		_finish(false)
		return
	# 연구소: 채집 자원으로 살 수 있는 연구 다 하기
	var researched: Array[String] = []
	for _r in range(9):
		var did_r := false
		for rid in Research.ORDER:
			if Research.can_research(rid):
				Research.research(rid)
				researched.append(Research.NODES[rid]["name"])
				did_r = true
		if not did_r:
			break
	if not researched.is_empty():
		_say("           연구: %s" % ", ".join(researched))
	# 제단: 오퍼에서 살 수 있는 것 다 구매 (돈 남으면 리롤)
	if Meta.offer.is_empty():
		Meta.roll_offer()
	var bought: Array[String] = []
	for _n in range(12):
		var did := false
		for id in Meta.offer:
			if Meta.can_buy(id):
				Meta.buy(id)
				Meta.consume_offer(id)
				bought.append(Meta.UPGRADES[id]["name"])
				did = true
				break
		if not did:
			var rc := 6
			if Meta.offer.size() >= 2 and Meta.souls >= rc + 15 and Meta.spend(rc):
				Meta.roll_offer()
			else:
				break
	if not bought.is_empty():
		_say("           구매: %s" % ", ".join(bought))
	_new_run(true)


func _finish(won: bool) -> void:
	set_physics_process(false)
	_say("")
	_say("=== 클리어! 6개 방 + 보스 격파 ===" if won else "=== 미클리어 — 최고 도달 방 %d ===" % best_room)
	_say("시간 %.1fs / 사망 %d회 / 시도 %d회 / 최종 영혼 %d" % [_t, deaths, Meta.runs, Meta.souls])
	_say("강화: " + _levels_str())
	print("\n".join(_log))
	Meta.reset()
	get_tree().quit(0 if won else 1)


func _levels_str() -> String:
	var parts: Array[String] = []
	for id in Meta.ORDER:
		if Meta.level(id) > 0:
			parts.append("%s Lv.%d" % [Meta.UPGRADES[id]["name"], Meta.level(id)])
	return "없음" if parts.is_empty() else ", ".join(parts)


func _say(s: String) -> void:
	_log.append(s)


func _watchdog() -> void:
	await get_tree().create_timer(RUN_SECONDS).timeout
	_finish(false)
