extends Node2D
## 방 하나. 벽으로 둘러싸이고 오른쪽에 문(door)이 있다.
## 왼쪽은 이전 방의 오른쪽 벽/문이 막아주므로 벽을 세우지 않는다 (solid_left 인 첫 방만 예외).
## begin() 하면 웨이브를 스폰하고, 전멸 시 다음 웨이브, 모두 끝나면 cleared 시그널.
## is_boss 면 보스를 스폰하고 died 를 기다린다.

const BossScene := preload("res://scenes/Boss.tscn")
const EnemyScene := preload("res://scenes/Enemy.tscn")
const ResourceNodeScene := preload("res://scenes/ResourceNode.tscn")

signal cleared

const WALL := 26.0

var size := Vector2(960, 640)
var door_gap := 150.0
var solid_left := false
var solid_right := false
var waves: Array = []       # [[0,0,1], [0,1,2], ...]  (Enemy.Weight 정수 배열)
var nodes: Array = []       # ["wood","stone","herb","ore"] — 방에 흩어놓을 채집 노드
var is_boss := false

var _exit_shape: CollisionShape2D
var _exit_rect: ColorRect
var _alive: Array = []
var _wave_i := -1
var _started := false
var _done := false
var boss: Node = null


func _ready() -> void:
	_build()


func bounds() -> Rect2:
	return Rect2(global_position - size * 0.5, size)


func _inner_spawn() -> Vector2:
	var mx := size.x * 0.5 - WALL * 3.0
	var my := size.y * 0.5 - WALL * 3.0
	return Vector2(randf_range(-mx, mx), randf_range(-my, my))


# ------------------------------------------------------------------ 구조물
func _build() -> void:
	var hw := size.x * 0.5
	var hh := size.y * 0.5
	var seg := (size.y - door_gap) * 0.5

	var floor_rect := ColorRect.new()
	floor_rect.color = Color(0.19, 0.13, 0.15) if is_boss else Color(0.14, 0.15, 0.19)
	floor_rect.size = size - Vector2(WALL, WALL) * 2.0
	floor_rect.position = -floor_rect.size * 0.5
	floor_rect.z_index = -10
	add_child(floor_rect)

	_wall(Vector2(0, -hh + WALL * 0.5), Vector2(size.x, WALL))
	_wall(Vector2(0, hh - WALL * 0.5), Vector2(size.x, WALL))
	if solid_left:
		_wall(Vector2(-hw + WALL * 0.5, 0), Vector2(WALL, size.y))
	if solid_right:
		_wall(Vector2(hw - WALL * 0.5, 0), Vector2(WALL, size.y))
	else:
		_wall(Vector2(hw - WALL * 0.5, -hh + seg * 0.5), Vector2(WALL, seg))
		_wall(Vector2(hw - WALL * 0.5, hh - seg * 0.5), Vector2(WALL, seg))
		_build_exit_door(Vector2(hw - WALL * 0.5, 0), Vector2(WALL, door_gap))


func _wall(c: Vector2, sz: Vector2) -> void:
	var b := StaticBody2D.new()
	b.collision_layer = 1
	b.collision_mask = 0
	b.position = c
	var cs := CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = sz
	cs.shape = rs
	b.add_child(cs)
	var r := ColorRect.new()
	r.color = Color(0.24, 0.25, 0.31)
	r.size = sz
	r.position = -sz * 0.5
	b.add_child(r)
	add_child(b)


func _build_exit_door(c: Vector2, sz: Vector2) -> void:
	var b := StaticBody2D.new()
	b.collision_layer = 1
	b.collision_mask = 0
	b.position = c
	_exit_shape = CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = sz
	_exit_shape.shape = rs
	b.add_child(_exit_shape)
	_exit_rect = ColorRect.new()
	_exit_rect.color = Color(0.85, 0.7, 0.3)
	_exit_rect.size = sz
	_exit_rect.position = -sz * 0.5
	b.add_child(_exit_rect)
	add_child(b)


func open_exit() -> void:
	if _exit_shape:
		_exit_shape.set_deferred("disabled", true)
		_exit_rect.visible = false


func lock_exit() -> void:
	if _exit_shape:
		_exit_shape.set_deferred("disabled", false)
		_exit_rect.visible = true


# ------------------------------------------------------------------ 진행
func begin() -> void:
	if _started:
		return
	_started = true
	if is_boss:
		boss = BossScene.instantiate()
		boss.arena_rect = Rect2(
			-size.x * 0.5 + WALL * 3.0, -size.y * 0.5 + WALL * 3.0,
			size.x - WALL * 6.0, size.y - WALL * 6.0)
		add_child(boss)
		boss.position = Vector2(0, -110)
		boss.died.connect(_finish)
	else:
		for k in nodes:
			var rn := ResourceNodeScene.instantiate()
			rn.kind = k
			add_child(rn)
			rn.position = _inner_spawn()
		_next_wave()


func _next_wave() -> void:
	_wave_i += 1
	if _wave_i >= waves.size():
		_finish()
		return
	for w in waves[_wave_i]:
		var e := EnemyScene.instantiate()
		e.weight = int(w)
		add_child(e)
		e.position = _inner_spawn()
		_alive.append(e)


func _process(_delta: float) -> void:
	if not _started or _done or is_boss:
		return
	_alive = _alive.filter(func(e): return is_instance_valid(e))
	if _alive.is_empty():
		_next_wave()


func _finish() -> void:
	if _done:
		return
	_done = true
	open_exit()
	cleared.emit()
