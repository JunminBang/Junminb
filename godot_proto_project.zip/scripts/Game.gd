extends Node
## 씬 매니저 (메인 씬). 거점(Base) ↔ 던전(Main) 을 World 컨테이너에 로드/교체한다.
##   - 거점 던전 포탈 → enter_dungeon()
##   - 던전 클리어/사망 → run_ended 시그널 → 결과 배너 → 거점 복귀
##   - Tab: 영혼 제단 (어디서든)

const BaseScene := preload("res://scenes/Base.tscn")
const DungeonScene := preload("res://scenes/Main.tscn")

@onready var _world: Node = $World
@onready var _altar: CanvasLayer = $Altar
@onready var _research: CanvasLayer = $Research
@onready var _banner_bg: ColorRect = $Banner/BG
@onready var _banner: Label = $Banner/BG/Label

var _in_dungeon := false


func _ready() -> void:
	add_to_group("game")
	$Banner.visible = false
	_load_base()


func _clear_world() -> void:
	for c in _world.get_children():
		_world.remove_child(c)   # 즉시 트리에서 제거 → 그룹에서도 빠짐
		c.queue_free()


func _load_base() -> void:
	_clear_world()
	_in_dungeon = false
	_world.add_child(BaseScene.instantiate())


func enter_dungeon() -> void:
	if _in_dungeon:
		return
	_clear_world()
	_in_dungeon = true
	var d := DungeonScene.instantiate()
	d.run_ended.connect(_on_run_ended)
	_world.add_child(d)


func _on_run_ended(cleared: bool) -> void:
	if not _in_dungeon:
		return
	_in_dungeon = false   # 중복 방지
	_banner.text = "던전 클리어!" if cleared else "쓰러졌다..."
	_banner.add_theme_color_override("font_color",
		Color(0.5, 0.9, 0.6) if cleared else Color(0.85, 0.2, 0.2))
	$Banner.visible = true
	await get_tree().create_timer(1.9).timeout
	$Banner.visible = false
	_load_base()


func open_shop() -> void:
	_altar.open_shop()


func open_research() -> void:
	_research.open_bench()
