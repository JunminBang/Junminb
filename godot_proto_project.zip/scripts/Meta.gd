extends Node
## 메타 성장 (오토로드 Meta). 컬트 오브 더 램의 교단 업그레이드처럼,
## 런에서 모은 "영혼"을 죽어도 유지하고, 사망/클리어 화면에서 영구 강화에 쓴다.
## user://mabi_proto_save.cfg 에 저장.

const SAVE_PATH := "user://mabi_proto_save.cfg"

# id: { name, max(레벨상한), cost0(1레벨 비용), growth(레벨당 비용 배수), per(레벨당 효과량), unit(설명) }
# 스탯은 최대 2레벨로 얕게 → HP 한 곳에 몰빵 불가. 빌드 정의 강화는 1레벨(비쌈).
const UPGRADES := {
	# --- 스탯 (최대 2레벨) : 생존 루트를 여러 개로 분산 ---
	"max_hp":    {"name": "강철 심장", "max": 2, "cost0": 16, "growth": 1.7, "per": 18.0, "unit": "최대 체력 +18"},
	"armor":     {"name": "방벽",      "max": 2, "cost0": 18, "growth": 1.7, "per": 2.0,  "unit": "받는 피해 -2 (고정)"},
	"vigor":     {"name": "불굴",      "max": 2, "cost0": 18, "growth": 1.7, "per": 0.1,  "unit": "피격 후 무적 +0.1초"},
	"iframe":    {"name": "잔상",      "max": 2, "cost0": 20, "growth": 1.8, "per": 0.05, "unit": "대시 무적 +0.05초"},
	"damage":    {"name": "예리함",    "max": 2, "cost0": 16, "growth": 1.7, "per": 0.1,  "unit": "모든 피해 +10%"},
	"haste":     {"name": "속공",      "max": 2, "cost0": 20, "growth": 1.8, "per": 0.04, "unit": "글로벌 쿨타임 -0.04초"},
	"swift":     {"name": "질풍",      "max": 2, "cost0": 20, "growth": 1.8, "per": 0.1,  "unit": "대시 쿨다운 -0.1초"},
	"lifesteal": {"name": "흡혈",      "max": 2, "cost0": 22, "growth": 1.8, "per": 0.06, "unit": "가한 피해의 6% 회복", "locked": true},
	"greed":     {"name": "탐욕",      "max": 2, "cost0": 14, "growth": 1.6, "per": 0.2,  "unit": "영혼 획득 +20%", "locked": true},
	# --- 빌드 정의 (1레벨) : 플레이 방식을 바꾼다. 전부 연구로 해금 ---
	"dash_slash":  {"name": "잔영검",     "max": 1, "cost0": 45, "growth": 1.0, "per": 1.0, "unit": "대시 끝나면 진행 방향으로 검기", "locked": true},
	"ult_double":  {"name": "폭주의 그릇", "max": 1, "cost0": 50, "growth": 1.0, "per": 1.0, "unit": "필살 게이지 2칸 + 획득 +50%", "locked": true},
	"combo_blast": {"name": "파쇄격",     "max": 1, "cost0": 42, "growth": 1.0, "per": 1.0, "unit": "평타 3타째가 전방위 폭발", "locked": true},
	"berserk":     {"name": "광전사",     "max": 1, "cost0": 48, "growth": 1.0, "per": 1.0, "unit": "HP 40% 이하일 때 피해·이속 +40%", "locked": true},
}
const ORDER := ["max_hp", "armor", "vigor", "iframe", "damage", "haste", "swift", "lifesteal", "greed",
	"dash_slash", "ult_double", "combo_blast", "berserk"]
const OFFER_SIZE := 3

var souls := 0
var levels: Dictionary = {}
var runs := 0
var offer: Array = []   # 제단에 현재 걸려 있는 강화 3종 (id). 리롤로 교체.


func _ready() -> void:
	load_game()


func level(id: String) -> int:
	return int(levels.get(id, 0))


func is_max(id: String) -> bool:
	return level(id) >= int(UPGRADES[id]["max"])


func cost(id: String) -> int:
	var u: Dictionary = UPGRADES[id]
	return int(round(float(u["cost0"]) * pow(float(u["growth"]), level(id))))


func can_buy(id: String) -> bool:
	return not is_max(id) and souls >= cost(id)


func buy(id: String) -> bool:
	if not can_buy(id):
		return false
	souls -= cost(id)
	levels[id] = level(id) + 1
	save_game()
	return true


## 해당 업그레이드의 누적 효과량 (레벨 × per)
func bonus(id: String) -> float:
	return level(id) * float(UPGRADES[id]["per"])


## 빌드 정의 강화 보유 여부
func has(id: String) -> bool:
	return level(id) > 0


func add_souls(base: int) -> void:
	souls += int(round(base * (1.0 + bonus("greed"))))
	save_game()   # ponytail: 처치마다 파일 쓰기. cfg 가 작아 무해, 필요하면 디바운스.


func note_run() -> void:
	runs += 1
	save_game()


# --- 제단 오퍼 (3종 랜덤 강화) ---------------------------------------------------
func _available() -> Array:
	return ORDER.filter(func(id):
		return not is_max(id) \
			and (not UPGRADES[id].get("locked", false) or Research.is_upgrade_unlocked(id)))


## 오퍼 3종을 새로 뽑는다 (리롤 / 최초 오픈).
func roll_offer() -> void:
	var pool: Array = _available()
	pool.shuffle()
	offer = pool.slice(0, OFFER_SIZE)
	save_game()


## 구매한 슬롯을 "다른" 강화로 교체한다 — 같은 걸 연속으로 못 사게 해서 빌드가 갈리게.
## (레벨 2를 원하면 나중에 다시 굴러 나오거나 리롤해야 함.) 채울 게 없으면 슬롯을 비운다.
func consume_offer(bought_id: String) -> void:
	var i: int = offer.find(bought_id)
	if i < 0:
		return
	var pool: Array = _available().filter(func(id): return not offer.has(id))
	if pool.is_empty():
		offer.remove_at(i)
	else:
		pool.shuffle()
		offer[i] = pool[0]
	# 혹시 최대치 도달분이 남아 있으면 정리
	offer = offer.filter(func(id): return not is_max(id))
	save_game()


func spend(n: int) -> bool:
	if souls < n:
		return false
	souls -= n
	save_game()
	return true


func reset() -> void:
	souls = 0
	levels = {}
	runs = 0
	offer = []
	save_game()


func save_game() -> void:
	var cf := ConfigFile.new()
	cf.set_value("meta", "souls", souls)
	cf.set_value("meta", "levels", levels)
	cf.set_value("meta", "runs", runs)
	cf.set_value("meta", "offer", offer)
	cf.save(SAVE_PATH)


func load_game() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) != OK:
		return
	souls = int(cf.get_value("meta", "souls", 0))
	levels = cf.get_value("meta", "levels", {})
	runs = int(cf.get_value("meta", "runs", 0))
	offer = cf.get_value("meta", "offer", [])
	offer = offer.filter(func(id): return UPGRADES.has(id) and not is_max(id))
