extends CharacterBody2D
## 플레이어 전투 컨트롤러 (마우스 이동 + 좌클릭 평타 + QWER 스킬)
##
## 조작:
##   우클릭(홀드)    - 커서 위치로 이동. 누르고 있으면 커서를 계속 따라간다.
##   좌클릭          - 평타 (연타 시 3타 콤보, 항상 커서 방향으로 타격). GCD 무관
##   Q / W / E       - 스킬 (쿨다운). Q 횡베기 / W 대시참격(무적) / E 충격파
##   R              - 필살기 (게이지 100%에서 발동, 전방위 강타 + 화면 슬로우)
##   Space          - 대시 (짧은 무적)
##
## 핵심 기획 포인트 (기획서 2-3, 2-4, 2-8):
##   - 모든 공격/스킬은 커서 방향으로 나가며, 시전 즉시 SlashEffect(검기)로 사거리·각도를 표시한다.
##   - 적중했을 때만 히트스탑 + 카메라 셰이크 + HitSpark + 타격음. (헛스윙은 검기+휙 소리만)
##   - 대시 종료 후 dash_cancel_window 안에 공격/스킬을 입력하면 후딜(RECOVER)을 스킵한다.
##   - 피격 시 hurt_time 동안 경직 + 무적. 대시/W/R 의 무적 프레임으로 회피 가능.
##   - 튜닝 상수는 인스펙터에서 바로 조정 (@export).

# --- 인스펙터 튜닝 (기획서 2-8) ---
@export var move_speed := 280.0
@export var dash_speed := 640.0
@export var dash_time := 0.14
@export var dash_cooldown := 0.4
@export var dash_cancel_window := 0.2   # 대시 종료 후 이 시간 안에 공격 입력 시 후딜 스킵 (0.1~0.2s 튜닝 대상)
@export var max_hp := 100
@export var hurt_time := 0.35           # 피격 후 경직 + 무적 시간
@export var gcd_time := 0.35            # 스킬 글로벌 쿨타임: 이 간격보다 빨리는 다음 스킬을 못 낸다

const INPUT_BUFFER := 0.18
const SKILL_BUFFER := 0.6              # 스킬 선입력 유지 (GCD 대기 동안 예약을 붙잡아 딜사이클이 안 끊기게)
const ARRIVE_DIST := 6.0
const GAUGE_MAX := 100.0
const GAUGE_PER_HIT := 6.0              # 적을 때릴 때 게이지 획득
const GAUGE_PER_DMG := 0.9              # 맞을 때 피해량 비례 게이지 획득

const SlashEffect := preload("res://scripts/SlashEffect.gd")
const HitSpark := preload("res://scripts/HitSpark.gd")

signal died

enum State { IDLE, DASH, ACT, RECOVER }

var state: State = State.IDLE
var facing: Vector2 = Vector2.RIGHT
var dead := false

# 메타 성장 반영 값 (Meta 오토로드에서 _ready 시 적용)
var _damage_mult := 1.0
var _lifesteal := 0.0
var _armor := 0
var _gauge_cap := 100.0
var _gauge_gain := 1.0
var _dash_slash := false
var _combo_blast := false
var _berserk := false

var move_target: Vector2 = Vector2.ZERO
var has_move_target := false

var combo_index := 0
var combo_reset_timer := 0.0
var gcd_timer := 0.0
var dash_cd_timer := 0.0
var cancel_timer := 0.0
var act_timer := 0.0
var invulnerable := false          # 액션(대시/W/R)에 의한 무적

var hp: int
var hurt_timer := 0.0
var knockback_vel: Vector2 = Vector2.ZERO
var ultimate_gauge := 0.0

var current: Dictionary = {}
var _acting_is_skill := false                     # 지금 시전/후딜 중인 게 스킬인가 (평타면 false)
var cooldowns := {"Q": 0.0, "W": 0.0, "E": 0.0}   # R 은 게이지제

var _buffered := ""
var _buffer_timer := 0.0

@onready var sprite: ColorRect = $Vis/Sprite
@onready var jelly: Node2D = $Vis

# --- 공격/스킬 데이터 ------------------------------------------------------------
# range: 사거리 / half_angle: 부채꼴 절반각(PI 이상이면 전방위)
# windup: 시전~판정 / recover: 후딜 / lunge: 시전 중 전진 속도 / iframe: 무적 / slow: 화면 슬로우
const BASIC := {
	"range": 62.0, "half_angle": 1.05, "damage": 5, "knockback": 130.0,
	"windup": 0.05, "recover": 0.16, "lunge": 0.0, "iframe": false, "slow": false,
	"color": Color(0.72, 0.86, 1.0), "shake": 3.0, "hitstop": 0.04,
}
const SKILLS := {
	"Q": {  # 횡베기: 넓은 부채꼴 근접
		"range": 82.0, "half_angle": 1.35, "damage": 22, "knockback": 280.0,
		"windup": 0.07, "recover": 0.26, "lunge": 0.0, "iframe": false, "slow": false,
		"color": Color(0.70, 0.90, 1.0), "shake": 5.0, "hitstop": 0.06, "cooldown": 2.5,
	},
	"W": {  # 대시 참격: 커서 방향으로 돌진하며 벤다 (무적)
		"range": 72.0, "half_angle": 0.7, "damage": 26, "knockback": 320.0,
		"windup": 0.12, "recover": 0.20, "lunge": 900.0, "iframe": true, "slow": false,
		"color": Color(1.0, 0.86, 0.5), "shake": 5.0, "hitstop": 0.07, "cooldown": 4.0,
	},
	"E": {  # 충격파: 전방위 넉백
		"range": 135.0, "half_angle": PI, "damage": 18, "knockback": 440.0,
		"windup": 0.09, "recover": 0.30, "lunge": 0.0, "iframe": false, "slow": false,
		"color": Color(0.60, 1.0, 0.82), "shake": 7.0, "hitstop": 0.06, "cooldown": 6.0,
	},
	"R": {  # 필살기: 전방위 대미지 + 화면 슬로우 (게이지 소모)
		"range": 200.0, "half_angle": PI, "damage": 60, "knockback": 640.0,
		"windup": 0.14, "recover": 0.50, "lunge": 0.0, "iframe": true, "slow": true,
		"color": Color(1.0, 0.60, 0.92), "shake": 14.0, "hitstop": 0.22,
	},
}


func _ready() -> void:
	add_to_group("player")   # Enemy 가 타겟을 그룹으로 찾는다
	_apply_meta()
	hp = max_hp
	_ensure_actions()


func _apply_meta() -> void:
	# Meta = 런마다 제단에서 사는 강화 / Research = 연구로 얻는 영구 패시브
	max_hp += int(Meta.bonus("max_hp")) + int(Research.passive("max_hp"))
	_armor = int(Meta.bonus("armor")) + int(Research.passive("armor"))
	_damage_mult = 1.0 + Meta.bonus("damage") + Research.passive("damage")
	_lifesteal = Meta.bonus("lifesteal")
	gcd_time = maxf(0.12, gcd_time - Meta.bonus("haste"))
	dash_cooldown = maxf(0.14, dash_cooldown - Meta.bonus("swift"))
	dash_time += Meta.bonus("iframe")      # 대시 이동 시간 = 무적 시간
	hurt_time += Meta.bonus("vigor")
	_dash_slash = Meta.has("dash_slash")
	_combo_blast = Meta.has("combo_blast")
	_berserk = Meta.has("berserk")
	_gauge_cap = 200.0 if Meta.has("ult_double") else 100.0
	_gauge_gain = 1.5 if Meta.has("ult_double") else 1.0


func _berserk_on() -> bool:
	return _berserk and hp < max_hp * 0.4


# --- 입력 액션 등록 (project.godot 을 건드리지 않고 런타임에 바인딩) ----------------
func _ensure_actions() -> void:
	_bind(&"move_to", _mb(MOUSE_BUTTON_RIGHT))
	_bind(&"attack", _mb(MOUSE_BUTTON_LEFT))   # 평타: 좌클릭
	_bind(&"skill_q", _kb(KEY_Q))
	_bind(&"skill_w", _kb(KEY_W))
	_bind(&"skill_e", _kb(KEY_E))
	_bind(&"skill_r", _kb(KEY_R))
	_bind(&"dash", _kb(KEY_SPACE))             # 대시: 스페이스
	_bind(&"interact", _kb(KEY_F))             # 거점 상호작용


func _bind(action: StringName, ev: InputEvent) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	else:
		InputMap.action_erase_events(action)
	InputMap.action_add_event(action, ev)


func _kb(k: Key) -> InputEventKey:
	var e := InputEventKey.new()
	e.physical_keycode = k
	return e


func _mb(b: MouseButton) -> InputEventMouseButton:
	var e := InputEventMouseButton.new()
	e.button_index = b
	return e


func _input(event: InputEvent) -> void:
	if dead:
		return
	# 이동은 "누르고 있는 동안" 커서를 따라가야 하므로 _physics_process 에서 폴링한다.
	if event.is_action_pressed(&"attack"):
		_buffer("BASIC")
	elif event.is_action_pressed(&"skill_q"):
		_buffer("Q")
	elif event.is_action_pressed(&"skill_w"):
		_buffer("W")
	elif event.is_action_pressed(&"skill_e"):
		_buffer("E")
	elif event.is_action_pressed(&"skill_r"):
		_buffer("R")
	elif event.is_action_pressed(&"dash"):
		_buffer("DASH")


func _buffer(a: String) -> void:
	_buffered = a
	# 스킬은 GCD 대기 동안 예약을 붙잡아야 하므로 길게, 평타/대시는 짧게
	_buffer_timer = SKILL_BUFFER if a in ["Q", "W", "E", "R"] else INPUT_BUFFER


func _physics_process(delta: float) -> void:
	if dead:
		velocity = Vector2.ZERO
		return
	dash_cd_timer = maxf(0.0, dash_cd_timer - delta)
	combo_reset_timer = maxf(0.0, combo_reset_timer - delta)
	gcd_timer = maxf(0.0, gcd_timer - delta)
	cancel_timer = maxf(0.0, cancel_timer - delta)
	_buffer_timer = maxf(0.0, _buffer_timer - delta)
	hurt_timer = maxf(0.0, hurt_timer - delta)
	for k in cooldowns:
		cooldowns[k] = maxf(0.0, cooldowns[k] - delta)
	if _buffer_timer <= 0.0:
		_buffered = ""
	if combo_reset_timer <= 0.0:
		combo_index = 0

	knockback_vel = knockback_vel.move_toward(Vector2.ZERO, 1400.0 * delta)

	# 피격 경직: 넉백만 받고 입력 무시
	if hurt_timer > 0.0:
		velocity = knockback_vel
		move_and_slide()
		return

	# 우클릭 홀드 이동
	if Input.is_action_pressed(&"move_to"):
		move_target = get_global_mouse_position()
		has_move_target = true

	match state:
		State.IDLE:
			_move_to_target()
			_try_consume_buffer(true)
		State.DASH:
			_do_dash(delta)
		State.ACT:
			_do_act(delta)
		State.RECOVER:
			_do_recover(delta)

	velocity += knockback_vel
	move_and_slide()


func _move_to_target() -> void:
	if not has_move_target:
		velocity = Vector2.ZERO
		return
	var to := move_target - global_position
	if to.length() <= ARRIVE_DIST:
		has_move_target = false
		velocity = Vector2.ZERO
		return
	facing = to.normalized()
	velocity = facing * move_speed * (1.25 if _berserk_on() else 1.0)


func _try_consume_buffer(allow_dash: bool) -> bool:
	if _buffered == "":
		return false
	var a := _buffered
	if a == "DASH":
		if allow_dash and dash_cd_timer <= 0.0:
			_buffered = ""
			_start_dash()
			return true
		return false
	if a == "BASIC":
		# 평타는 GCD 와 무관 — 자체 콤보 간격(recover)으로만 페이싱
		_buffered = ""
		_start_act(_basic_data(), false)
		return true
	# 여기부터 스킬 Q/W/E/R — 글로벌 쿨타임 공유
	if gcd_timer > 0.0:
		return false
	if a == "R":
		if ultimate_gauge < GAUGE_MAX:
			return false
		_buffered = ""
		ultimate_gauge -= GAUGE_MAX   # ult_double 이면 2칸까지 차니 한 칸만 소모 (연속 발동)
		gcd_timer = gcd_time
		_start_act(SKILLS["R"].duplicate(), true)
		return true
	# 스킬 Q/W/E
	if float(cooldowns.get(a, 0.0)) > 0.0:
		return false
	_buffered = ""
	var sk: Dictionary = SKILLS[a].duplicate()
	cooldowns[a] = sk["cooldown"]
	gcd_timer = gcd_time
	_start_act(sk, true)
	return true


func _basic_data() -> Dictionary:
	var d := BASIC.duplicate()
	match combo_index:
		0:
			pass
		1:
			d["damage"] = 7
			d["knockback"] = 170.0
		_:
			d["damage"] = 10
			d["knockback"] = 240.0
			d["shake"] = 5.0
			d["hitstop"] = 0.07
			d["recover"] = 0.24
			if _combo_blast:                 # 파쇄격: 3타째 전방위 폭발
				d["half_angle"] = PI
				d["range"] = 95.0
				d["knockback"] = 320.0
				d["color"] = Color(1.0, 0.7, 0.4)
	combo_index = mini(combo_index + 1, 2)
	combo_reset_timer = 0.55
	return d


func _start_dash() -> void:
	state = State.DASH
	act_timer = dash_time
	dash_cd_timer = dash_cooldown
	invulnerable = true
	has_move_target = false
	var to_mouse := get_global_mouse_position() - global_position
	if to_mouse.length() > 1.0:
		facing = to_mouse.normalized()
	jelly.poke_dir(facing, 0.7)
	Sfx.play("dash")


func _do_dash(delta: float) -> void:
	velocity = facing * dash_speed
	act_timer -= delta
	if act_timer <= 0.0:
		invulnerable = false
		cancel_timer = dash_cancel_window
		state = State.IDLE
		if _dash_slash:
			_dash_slash_hit()


## 타격 대상 = 적 + 채집 자원 노드
func _hit_targets() -> Array:
	return get_tree().get_nodes_in_group("enemy") + get_tree().get_nodes_in_group("harvestable")


func _dash_slash_hit() -> void:
	var col := Color(0.75, 0.88, 1.0)
	var fx := SlashEffect.new()
	add_child(fx)
	fx.setup(facing, 92.0, 0.95, col, 0.16)
	Sfx.play("whoosh")
	var hits := 0
	for e in _hit_targets():
		if not is_instance_valid(e) or not e.has_method("take_hit"):
			continue
		var to_e: Vector2 = e.global_position - global_position
		if to_e.length() > 92.0 or (to_e.length() > 1.0 and absf(facing.angle_to(to_e)) > 0.95):
			continue
		e.take_hit(maxi(1, int(round(15 * _damage_mult))), to_e.normalized(), 220.0)
		_spawn_spark(e.global_position, col)
		hits += 1
	if hits > 0:
		Hitstop.hitstop(0.05, 0.06)
		_shake_camera(4.0)


func _start_act(data: Dictionary, is_skill := false) -> void:
	current = data
	_acting_is_skill = is_skill
	state = State.ACT
	act_timer = data["windup"]
	invulnerable = data.get("iframe", false)
	has_move_target = false
	var to_mouse := get_global_mouse_position() - global_position
	if to_mouse.length() > 1.0:
		facing = to_mouse.normalized()
	jelly.poke_dir(facing, 0.28)   # 시전 앞으로 살짝 뻗기


func _do_act(delta: float) -> void:
	var lunge: float = current.get("lunge", 0.0)
	if lunge > 0.0:
		velocity = facing * lunge
	else:
		velocity = velocity.move_toward(Vector2.ZERO, move_speed * 5.0 * delta)
	act_timer -= delta
	if act_timer <= 0.0:
		_resolve_hit()
		invulnerable = false
		state = State.RECOVER
		act_timer = current["recover"]


func _do_recover(delta: float) -> void:
	velocity = velocity.move_toward(Vector2.ZERO, move_speed * 6.0 * delta)
	if _buffered == "DASH" and dash_cd_timer <= 0.0:
		_buffered = ""
		_start_dash()
		return
	# 딜사이클: 다음 입력이 예약돼 있으면 후딜을 끊고 바로 이어간다.
	#  - 스킬 예약: 항상 시도 (실제 속도는 gcd_timer 가 통제)
	#  - 평타 예약: 스킬 후딜만 끊게 허용 (평타→평타 난사 방지, 콤보 간격 유지)
	#  - 대시 직후(cancel_timer)에는 무엇이든 캔슬 가능 (기획서 2-3)
	if _buffered != "" and _buffered != "DASH":
		var buffered_is_skill := _buffered != "BASIC"
		if buffered_is_skill or _acting_is_skill or cancel_timer > 0.0:
			if _try_consume_buffer(false):
				return
	act_timer -= delta
	if act_timer <= 0.0:
		state = State.IDLE


func _resolve_hit() -> void:
	var rng: float = current["range"]
	var half: float = current["half_angle"]
	var col: Color = current["color"]
	var mult := _damage_mult * (1.4 if _berserk_on() else 1.0)
	var dmg: int = maxi(1, int(round(int(current["damage"]) * mult)))

	# 검기 / 범위 이펙트 — 빗나가도 항상 표시
	var fx := SlashEffect.new()
	add_child(fx)
	fx.setup(facing, rng, half, col, 0.22 if half >= PI else 0.16)
	Sfx.play("whoosh")

	var origin := global_position
	var hits := 0
	for e in _hit_targets():
		if not is_instance_valid(e) or not e.has_method("take_hit"):
			continue
		var to_e: Vector2 = e.global_position - origin
		var dist := to_e.length()
		if dist > rng:
			continue
		if half < PI and dist > 1.0 and absf(facing.angle_to(to_e)) > half:
			continue
		var kb_dir := to_e.normalized() if dist > 1.0 else facing
		e.take_hit(dmg, kb_dir, float(current["knockback"]))
		_spawn_spark(e.global_position, col)
		ultimate_gauge = minf(_gauge_cap, ultimate_gauge + GAUGE_PER_HIT * _gauge_gain)
		if _lifesteal > 0.0:
			hp = mini(max_hp, hp + maxi(1, int(dmg * _lifesteal)))
		hits += 1

	var slow: bool = current.get("slow", false)
	if hits > 0:
		Hitstop.hitstop(current["hitstop"], 0.10 if slow else 0.06)
		_shake_camera(current["shake"])
		jelly.poke_dir(facing, 0.2)
		if dmg >= 40:
			Sfx.play("hit_crit")
		elif dmg >= 20:
			Sfx.play("hit_heavy")
		else:
			Sfx.play("hit_light")
	elif slow:
		Hitstop.hitstop(current["hitstop"], 0.10)
		_shake_camera(current["shake"])


## 몬스터가 호출한다. dir 은 플레이어가 밀려날 방향.
func take_hit(damage: int, dir: Vector2, knockback: float) -> void:
	if dead or invulnerable or hurt_timer > 0.0:
		return
	var taken := maxi(1, damage - _armor)      # 방벽: 고정 감소
	hp -= taken
	ultimate_gauge = minf(_gauge_cap, ultimate_gauge + taken * GAUGE_PER_DMG * _gauge_gain)
	knockback_vel = dir.normalized() * knockback
	hurt_timer = hurt_time
	_buffered = ""
	jelly.poke(-0.32, 0.55)   # 맞으면 세로로 쭉 눌렸다 튀어나옴
	Sfx.play("hurt")
	_shake_camera(7.0)
	_flash(Color(1.0, 0.35, 0.35))
	if hp <= 0:
		_down()


func _down() -> void:
	if dead:
		return
	dead = true
	hp = 0
	velocity = Vector2.ZERO
	knockback_vel = Vector2.ZERO
	jelly.poke(0.9, -0.65)
	Sfx.play("death")
	Hitstop.hitstop(0.2, 0.05)
	_shake_camera(20.0)
	_flash(Color(0.9, 0.2, 0.2))
	died.emit()   # Arena 가 받아서 YOU DIED 화면을 띄운다


func _flash(c: Color) -> void:
	sprite.color = c
	var tw := create_tween()
	tw.tween_property(sprite, "color", Color(0.25, 0.6, 1.0), 0.18)


## 영혼을 먹었을 때 Soul 이 호출 — 살짝 부풀며 반응
func pop_soul() -> void:
	jelly.poke(0.13, 0.16)


func _spawn_spark(pos: Vector2, col: Color) -> void:
	var s := HitSpark.new()
	get_parent().add_child(s)
	s.global_position = pos
	s.setup(col.lerp(Color.WHITE, 0.5), 28.0)


func _shake_camera(strength: float) -> void:
	Hitstop.shake(strength)
