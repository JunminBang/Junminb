extends Node
## 빌드연구 (오토로드 Research). 채집 자원으로 영구 해금.
##   unlock: 제단(Altar) 오퍼 풀에 그 강화 id 를 추가
##   passive: 영구 스탯 (Player._apply_meta 가 합산). key = max_hp / armor / damage / harvest ...
## user://mabi_proto_research.cfg 저장.

const SAVE_PATH := "user://mabi_proto_research.cfg"

# id: { name, cost{자원:개수}, requires[선행 id], desc, unlock:"강화id" / passive:{key:값} }
const NODES := {
	"harvest_1": {"name": "채집 도구", "cost": {"wood": 10}, "requires": [],
		"passive": {"harvest": 0.3}, "desc": "채집 자원 획득 +30%"},
	"toughness": {"name": "가죽 무두질", "cost": {"stone": 8}, "requires": [],
		"passive": {"armor": 1.0}, "desc": "받는 피해 -1 (영구)"},
	"vitality": {"name": "골법 단련", "cost": {"stone": 12, "wood": 8}, "requires": ["toughness"],
		"passive": {"max_hp": 12.0}, "desc": "최대 체력 +12 (영구)"},
	"blade_arts": {"name": "검술 연구", "cost": {"wood": 12, "herb": 4}, "requires": [],
		"unlock": "dash_slash", "desc": "제단에 '잔영검' 해금"},
	"shatter": {"name": "파쇄 이론", "cost": {"stone": 14}, "requires": ["blade_arts"],
		"unlock": "combo_blast", "desc": "제단에 '파쇄격' 해금"},
	"overflow": {"name": "정수 그릇", "cost": {"ore": 8, "stone": 12}, "requires": ["blade_arts"],
		"unlock": "ult_double", "desc": "제단에 '폭주의 그릇' 해금"},
	"bloodlust": {"name": "피의 의식", "cost": {"herb": 10, "ore": 4}, "requires": [],
		"unlock": "lifesteal", "desc": "제단에 '흡혈' 해금"},
	"frenzy": {"name": "광기 각인", "cost": {"ore": 12, "herb": 6}, "requires": ["bloodlust"],
		"unlock": "berserk", "desc": "제단에 '광전사' 해금"},
	"avarice": {"name": "탐욕의 룬", "cost": {"wood": 8, "stone": 8}, "requires": ["harvest_1"],
		"unlock": "greed", "desc": "제단에 '탐욕' 해금"},
}
const ORDER := ["harvest_1", "toughness", "vitality", "blade_arts", "shatter", "overflow",
	"bloodlust", "frenzy", "avarice"]

var done: Array = []   # 완료한 연구 id


func _ready() -> void:
	load_research()


func is_done(id: String) -> bool:
	return done.has(id)


func requires_met(id: String) -> bool:
	for r in NODES[id]["requires"]:
		if not is_done(r):
			return false
	return true


func can_research(id: String) -> bool:
	if is_done(id) or not requires_met(id):
		return false
	return Inventory.can_afford(NODES[id]["cost"])


func research(id: String) -> bool:
	if not can_research(id):
		return false
	if not Inventory.pay(NODES[id]["cost"]):
		return false
	done.append(id)
	save_research()
	return true


## 제단 강화 id 가 연구로 해금됐는가
func is_upgrade_unlocked(upgrade_id: String) -> bool:
	for id in done:
		if NODES[id].get("unlock", "") == upgrade_id:
			return true
	return false


## 완료한 연구들의 passive[key] 합
func passive(key: String) -> float:
	var total := 0.0
	for id in done:
		total += float(NODES[id].get("passive", {}).get(key, 0.0))
	return total


func reset() -> void:
	done = []
	save_research()


func save_research() -> void:
	var cf := ConfigFile.new()
	cf.set_value("research", "done", done)
	cf.save(SAVE_PATH)


func load_research() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		done = cf.get_value("research", "done", [])
		done = done.filter(func(id): return NODES.has(id))
