extends CanvasLayer
## 프로토타입 HUD: 체력 / 필살기 게이지 / QWER / 영혼 + 피격 시 화면 빨개짐.

@export var player_path: NodePath

@onready var _p: Node = get_node_or_null(player_path)
@onready var _hp: ProgressBar = $HpBar
@onready var _gauge: ProgressBar = $GaugeBar
@onready var _skills: Label = $Skills
@onready var _souls: Label = $Souls
@onready var _res: Label = $Res
@onready var _flash: ColorRect = $Flash

var _last_hp := -1
var _flash_a := 0.0
var _time := 0.0


func _process(delta: float) -> void:
	if not is_instance_valid(_p):
		return
	_time += delta

	_hp.max_value = _p.max_hp
	_hp.value = _p.hp
	_gauge.max_value = _p._gauge_cap
	_gauge.value = _p.ultimate_gauge

	var s := ""
	var gcd := float(_p.gcd_timer)
	s += ("[GCD]  " if gcd > 0.0 else "[ ]  ")
	for k in ["Q", "W", "E"]:
		var t := float(_p.cooldowns.get(k, 0.0))
		s += "%s:%s   " % [k, "READY" if t <= 0.0 else "%.1f" % t]
	var g: float = _p.ultimate_gauge
	if g >= _p.GAUGE_MAX:
		s += "R:READY" + ("x2" if g >= _p.GAUGE_MAX * 2.0 else "")
	else:
		s += "R:%d%%" % int(g * 100.0 / _p.GAUGE_MAX)
	_skills.text = s
	_souls.text = "영혼  %d" % Meta.souls
	var rt := ""
	for k in Inventory.ORDER:
		if Inventory.amount(k) > 0:
			rt += "%s %d   " % [Inventory.KINDS[k]["name"], Inventory.amount(k)]
	_res.text = rt

	# 피격 시 화면 빨개짐 (피해량이 클수록 진하게 = 치명타일수록 새빨감)
	if _last_hp < 0:
		_last_hp = _p.hp
	if _p.hp < _last_hp:
		var dropped := float(_last_hp - _p.hp)
		_flash_a = maxf(_flash_a, clampf(0.12 + dropped / 55.0, 0.16, 0.62))
	_last_hp = _p.hp
	_flash_a = maxf(0.0, _flash_a - delta * 2.3)

	# 체력이 낮으면 은은하게 빨간 맥동
	var low := 0.0
	var frac: float = float(_p.hp) / maxf(1.0, float(_p.max_hp))
	if _p.hp > 0 and frac < 0.3:
		low = (0.3 - frac) / 0.3 * 0.24 * (0.55 + 0.45 * sin(_time * 6.0))

	_flash.color = Color(0.85, 0.05, 0.05, maxf(_flash_a, low))
