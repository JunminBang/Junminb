extends CanvasLayer
## 연구소 — 채집 자원으로 영구 해금 (Altar 와 같은 스타일). 연구소 스테이션 F, 또는 Esc 로 닫기.

var _grace := 0.0
var _overlay: ColorRect
var _res: Label
var _list: VBoxContainer


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _process(delta: float) -> void:
	if _grace > 0.0:
		_grace = maxf(0.0, _grace - delta)


func _build() -> void:
	_overlay = ColorRect.new()
	_overlay.color = Color(0, 0, 0, 0.94)
	_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_overlay)

	var box := VBoxContainer.new()
	box.anchor_left = 0.5
	box.anchor_top = 0.5
	box.anchor_right = 0.5
	box.anchor_bottom = 0.5
	box.offset_left = -380.0
	box.offset_right = 380.0
	box.offset_top = -240.0
	box.offset_bottom = 240.0
	box.add_theme_constant_override("separation", 8)
	_overlay.add_child(box)

	var title := Label.new()
	title.text = "연구소"
	title.add_theme_font_size_override("font_size", 48)
	title.add_theme_color_override("font_color", Color(0.55, 0.8, 0.9))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)

	var sub := Label.new()
	sub.text = "채집 자원으로 영구 해금.  (F / Esc 로 닫기)"
	sub.add_theme_color_override("font_color", Color(0.6, 0.6, 0.62))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(sub)

	_res = Label.new()
	_res.add_theme_color_override("font_color", Color(0.75, 0.68, 0.5))
	_res.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_res)

	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 10)
	box.add_child(gap)

	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 3)
	box.add_child(_list)

	var gap2 := Control.new()
	gap2.custom_minimum_size = Vector2(0, 10)
	box.add_child(gap2)

	var close := Button.new()
	close.text = "닫기   [F]"
	close.pressed.connect(_close)
	box.add_child(close)


func open_bench() -> void:
	if visible:
		return
	_refresh()
	visible = true
	_grace = 0.35
	get_tree().paused = true


func _close() -> void:
	visible = false
	get_tree().paused = false


func _cost_str(cost: Dictionary) -> String:
	var parts: Array[String] = []
	for k in cost:
		parts.append("%s %d" % [Inventory.KINDS[k]["name"], int(cost[k])])
	return "  ".join(parts)


func _inv_str() -> String:
	var parts: Array[String] = []
	for k in Inventory.ORDER:
		parts.append("%s %d" % [Inventory.KINDS[k]["name"], Inventory.amount(k)])
	return "  ".join(parts)


func _refresh() -> void:
	_res.text = "보유   " + _inv_str()
	for c in _list.get_children():
		c.queue_free()
	for id in Research.ORDER:
		var n: Dictionary = Research.NODES[id]
		var b := Button.new()
		if Research.is_done(id):
			b.text = "✓ %s  —  %s" % [n["name"], n["desc"]]
			b.disabled = true
		elif not Research.requires_met(id):
			var req: Array[String] = []
			for r in n["requires"]:
				req.append(Research.NODES[r]["name"])
			b.text = "🔒 %s  (선행: %s)  —  %s" % [n["name"], "  ".join(req), n["desc"]]
			b.disabled = true
		else:
			b.text = "%s   [%s]   %s" % [n["name"], _cost_str(n["cost"]), n["desc"]]
			b.disabled = not Research.can_research(id)
			b.pressed.connect(_do.bind(id))
		_list.add_child(b)


func _do(id: String) -> void:
	if Research.research(id):
		Sfx.play("soul")
		_refresh()


func _unhandled_input(e: InputEvent) -> void:
	if _grace > 0.0 or not visible:
		return
	if e is InputEventKey and e.pressed and not e.echo and (e.keycode == KEY_F or e.keycode == KEY_ESCAPE):
		_close()
