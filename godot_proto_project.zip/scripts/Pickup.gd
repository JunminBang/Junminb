extends Node2D
## 드랍 아이템 — 영혼 / 채집 자원(목재·석재·약초·광석) 공용.
## 튀어나와 흩어지고, 플레이어가 가까이 오면 빨려들어간다. 획득 순간 팝 + 사운드 + 젤리 반응.
## kind == "soul" 이면 Meta.add_souls, 그 외엔 Inventory.add(kind).

const HitSpark := preload("res://scripts/HitSpark.gd")
const _Self := preload("res://scripts/Pickup.gd")

const MAGNET := 120.0
const COLLECT := 16.0
const LIFETIME := 14.0
const SCATTER_DELAY := 0.3

var kind := "soul"
var value := 1
var _vel := Vector2.ZERO
var _t := 0.0
var _homing := false
var _collecting := false
var _ct := 0.0


## 총량을 여러 개로 쪼개 at 위치에 뿌린다.
static func drop(parent: Node, at: Vector2, kind_: String, total: int) -> void:
	var n: int = clampi(total, 1, 6)
	for i in range(n):
		var v: int = total / n + (1 if i < total % n else 0)
		var s: Node2D = _Self.new()
		s.kind = kind_
		s.value = maxi(1, v)
		parent.add_child(s)
		s.global_position = at + Vector2(randf_range(-8, 8), randf_range(-8, 8))


func _ready() -> void:
	add_to_group("pickup")
	var a := randf() * TAU
	_vel = Vector2(cos(a), sin(a)) * randf_range(95.0, 200.0)


func _collect() -> void:
	if kind == "soul":
		Meta.add_souls(value)
	else:
		var m := 1.0 + Research.passive("harvest")   # 연구 '채집 도구'
		Inventory.add(kind, maxi(1, int(round(value * m))))


func _physics_process(delta: float) -> void:
	_t += delta

	if _collecting:
		_ct += delta
		scale = Vector2.ONE * (1.0 + _ct * 7.0)
		modulate.a = maxf(0.0, 1.0 - _ct / 0.12)
		if _ct >= 0.12:
			queue_free()
		return

	if _t >= LIFETIME:
		_collect()
		queue_free()
		return

	var p := _nearest_player()
	if _t > SCATTER_DELAY and is_instance_valid(p):
		var to: Vector2 = p.global_position - global_position
		var d := to.length()
		if d <= COLLECT:
			_collecting = true
			_collect()
			Sfx.play("soul")
			if p.has_method("pop_soul"):
				p.pop_soul()
			var s := HitSpark.new()
			get_parent().add_child(s)
			s.global_position = global_position
			s.setup(_color().lerp(Color.WHITE, 0.4), 16.0)
			return
		if _homing or d <= MAGNET:
			_homing = true
			_vel = _vel.lerp(to.normalized() * 540.0, clampf(delta * 9.0, 0.0, 1.0))

	if not _homing:
		_vel = _vel.move_toward(Vector2.ZERO, 400.0 * delta)
	global_position += _vel * delta
	queue_redraw()


func _nearest_player() -> Node2D:
	var best: Node2D = null
	var bd := INF
	for pl in get_tree().get_nodes_in_group("player"):
		if not is_instance_valid(pl):
			continue
		var d := global_position.distance_squared_to(pl.global_position)
		if d < bd:
			bd = d
			best = pl
	return best


func _color() -> Color:
	if kind == "soul":
		return Color(1.0, 0.92, 0.55)
	return Inventory.KINDS.get(kind, {}).get("color", Color(1, 1, 1))


func _draw() -> void:
	var pulse := 0.75 + 0.25 * sin(_t * 9.0)
	var r := 5.0 * pulse
	var c := _color()
	c.a = 0.95
	if kind == "soul":
		# 영혼: 다이아몬드
		draw_colored_polygon(PackedVector2Array([
			Vector2(0, -r * 1.7), Vector2(r, 0), Vector2(0, r * 1.7), Vector2(-r, 0)]), c)
	else:
		# 자원: 작은 사각 조각
		draw_rect(Rect2(-r, -r, r * 2.0, r * 2.0), c)
	var glow := c
	glow.a = 0.22
	draw_arc(Vector2.ZERO, r * 2.6, 0.0, TAU, 16, glow, 2.0)
