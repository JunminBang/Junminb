extends Node2D
## 거점 — 스크롤 없는 방. 던전 포탈 + 영혼 제단 스테이션. 여기서 자원을 소비한다(연구/건설은 다음 단계).

const PlayerScene := preload("res://scenes/Player.tscn")
const InteractableScene := preload("res://scenes/Interactable.tscn")

const SIZE := Vector2(920, 620)
const WALL := 24.0

var player: Node2D


func _ready() -> void:
	_build_room()

	player = PlayerScene.instantiate()
	add_child(player)
	player.position = Vector2(0, 140)
	var cam := player.get_node_or_null("Camera2D")
	if cam:
		cam.limit_left = int(-SIZE.x * 0.5)
		cam.limit_right = int(SIZE.x * 0.5)
		cam.limit_top = int(-SIZE.y * 0.5)
		cam.limit_bottom = int(SIZE.y * 0.5)

	_station("dungeon", "던전 입장", Vector2(0, -210), Color(0.72, 0.32, 0.85))
	_station("altar", "영혼 제단", Vector2(-280, 30), Color(0.86, 0.8, 0.55))
	_station("research", "연구소", Vector2(280, 30), Color(0.4, 0.7, 0.85))


func _station(sid: String, text: String, pos: Vector2, col: Color) -> void:
	var it := InteractableScene.instantiate()
	it.id = sid
	it.label_text = text
	it.tint = col
	add_child(it)
	it.position = pos
	it.triggered.connect(_on_trigger)


func _on_trigger(sid: String) -> void:
	var g := get_tree().get_first_node_in_group("game")
	if not is_instance_valid(g):
		return
	match sid:
		"dungeon":
			g.enter_dungeon()
		"altar":
			g.open_shop()
		"research":
			g.open_research()


func _build_room() -> void:
	var hw := SIZE.x * 0.5
	var hh := SIZE.y * 0.5
	var floor_rect := ColorRect.new()
	floor_rect.color = Color(0.14, 0.16, 0.18)
	floor_rect.size = SIZE - Vector2(WALL, WALL) * 2.0
	floor_rect.position = -floor_rect.size * 0.5
	floor_rect.z_index = -10
	add_child(floor_rect)

	for w in [
		[Vector2(0, -hh + WALL * 0.5), Vector2(SIZE.x, WALL)],
		[Vector2(0, hh - WALL * 0.5), Vector2(SIZE.x, WALL)],
		[Vector2(-hw + WALL * 0.5, 0), Vector2(WALL, SIZE.y)],
		[Vector2(hw - WALL * 0.5, 0), Vector2(WALL, SIZE.y)],
	]:
		var b := StaticBody2D.new()
		b.collision_layer = 1
		b.collision_mask = 0
		b.position = w[0]
		var cs := CollisionShape2D.new()
		var rs := RectangleShape2D.new()
		rs.size = w[1]
		cs.shape = rs
		b.add_child(cs)
		var r := ColorRect.new()
		r.color = Color(0.22, 0.24, 0.28)
		r.size = w[1]
		r.position = -w[1] * 0.5
		b.add_child(r)
		add_child(b)
