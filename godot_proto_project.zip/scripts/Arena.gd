extends Node2D
## 방을 가로로 이어 붙이고 진행을 관리한다 (기획서 2-6: 입구 - 전투룸 - 보스룸).
## 플레이어가 다음 방에 진입하면 뒤 문을 잠그고(백트래킹 차단) 그 방을 시작한다.
## 방을 클리어하면 그 방의 출구가 열린다. 보스룸 클리어 시 전체 개방.

const RoomScript := preload("res://scripts/Room.gd")

const ROOM_W := 980.0
const ROOM_H := 660.0

signal run_ended(cleared: bool)   # Game 매니저가 받아서 거점으로 복귀시킨다

var rooms: Array = []
var _reached := 0
var _boss_dead := false
var _ended := false

@onready var player: Node2D = $Player


func _ready() -> void:
	# Weight: 0 LIGHT / 1 HEAVY / 2 FIXED / 3 RANGED — 방이 깊어질수록 물량·중량·원거리 증가
	# nodes: 방에 흩어놓을 채집 자원 (wood/stone/herb/ore) — 클리어 판정엔 무관
	var defs := [
		{"solid_left": true, "waves": []},                                        # 0 입구 (안전)
		{"waves": [[0, 0], [0, 0, 3], [0, 1, 3]], "nodes": ["wood", "wood", "herb"]},          # 1
		{"waves": [[0, 0, 1], [0, 1, 3], [1, 1, 3, 3]], "nodes": ["wood", "stone", "herb"]},   # 2
		{"waves": [[0, 1, 3, 3], [0, 1, 1, 3], [1, 1, 2, 3, 3]], "nodes": ["stone", "stone", "ore"]},  # 3
		{"waves": [[0, 1, 3, 3], [1, 2, 3, 3], [0, 1, 1, 3, 3]], "nodes": ["stone", "ore", "ore"]},  # 4
		{"boss": true, "solid_right": true, "waves": []},                         # 5 보스
	]
	var x := 0.0
	for i in defs.size():
		var d: Dictionary = defs[i]
		var r := Node2D.new()
		r.set_script(RoomScript)
		r.name = "Room%d" % i
		r.size = Vector2(ROOM_W, ROOM_H)
		r.is_boss = d.get("boss", false)
		r.waves = d.get("waves", [])
		r.nodes = d.get("nodes", [])
		r.solid_left = d.get("solid_left", false)
		r.solid_right = d.get("solid_right", false)
		add_child(r)
		r.position = Vector2(x + ROOM_W * 0.5, 0.0)
		r.cleared.connect(_on_room_cleared.bind(i))
		rooms.append(r)
		x += ROOM_W

	player.position = rooms[0].position
	player.died.connect(_end_run.bind(false))
	_set_camera_limits(Rect2(0.0, -ROOM_H * 0.5, x, ROOM_H))
	rooms[0].call_deferred("begin")        # 입구는 즉시 클리어 → 출구 개방


func _process(_delta: float) -> void:
	if not is_instance_valid(player):
		return
	var idx := _room_index_at(player.global_position)
	if idx > _reached:
		rooms[idx - 1].lock_exit()          # 뒤 문 잠금
		_reached = idx
		rooms[idx].begin()


func _room_index_at(gp: Vector2) -> int:
	for i in range(rooms.size() - 1, -1, -1):
		if rooms[i].bounds().has_point(gp):
			return i
	return _reached


func _on_room_cleared(i: int) -> void:
	if rooms[i].is_boss:
		_boss_dead = true
		for r in rooms:
			r.open_exit()
		print("ARENA CLEARED")
		_end_run(true)


func _end_run(cleared: bool) -> void:
	if _ended:
		return
	_ended = true
	Meta.note_run()
	run_ended.emit(cleared)


func _set_camera_limits(r: Rect2) -> void:
	var cam := player.get_node_or_null("Camera2D")
	if cam:
		cam.limit_left = int(r.position.x)
		cam.limit_top = int(r.position.y)
		cam.limit_right = int(r.end.x)
		cam.limit_bottom = int(r.end.y)
