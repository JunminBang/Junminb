# 액션 로그라이크 전투 프로토타입 (Godot 4)

`Docs/액션로그라이크_전투기획서.md`(전투) + `Docs/확장_기획서.md`(거점·채집·건설·연구 로드맵)를 최소 구현으로 검증하는 프로토타입입니다.
**현재: 전투 루프 완성 + 확장 1~3단계(자원 채집 / 거점↔던전 루프 / 빌드연구) 완료.**

## 여는 법 / 실행
Godot 4 로 `project.godot` 임포트 → F5. **메인 씬은 `Game.tscn`** (거점에서 시작).
거점의 보라 스테이션에서 `F` → 던전. 클리어/사망 시 거점 복귀. `Tab` → 영혼 제단(어디서든).
Godot 4.2 이상에서 열어 확인하세요 (다른 4.x 버전이면 "프로젝트 변환" 팝업이 뜨는데 그대로 진행).

## 여는 법
1. Godot 4 실행 → "가져오기(Import)" → 이 폴더의 `project.godot` 선택
2. F5 또는 실행 버튼으로 `Main.tscn` 실행

## 조작
| 입력 | 동작 |
|---|---|
| 우클릭(홀드) | 커서 위치로 이동. 누르고 있으면 커서를 계속 따라간다 |
| 좌클릭 | 평타 (연타 시 3타 콤보, 항상 커서 방향으로 타격). GCD 무관 |
| Q | 횡베기 — 넓은 부채꼴 근접 (쿨 2.5초) |
| W | 대시 참격 — 커서 방향 돌진하며 벤다, 돌진 중 무적 (쿨 4초) |
| E | 충격파 — 전방위 넉백 (쿨 6초) |
| R | 필살기 — 전방위 강타 + 화면 슬로우. **게이지 100%에서 발동** |
| Space | 대시 (짧은 무적) |
| Tab | 영혼 제단 열기/닫기 (아무 때나, 게임 일시정지) |

HUD(좌상단): 체력바 / 필살기 게이지바 / QWER 상태.

## 구현된 것

### 조작 체계 (기획서 2-3)
- `scripts/Player.gd`: 우클릭 홀드 이동 / 좌클릭 3콤보 평타 / QWER 스킬 / Space 대시
- 입력 액션은 `project.godot`를 건드리지 않고 `Player._ensure_actions()`에서 런타임 바인딩 (키 변경도 여기서)
- 입력 버퍼링(평타 0.18초 / 스킬 0.6초) + 대시 캔슬:
  - 후딜 중 Space → 즉시 대시 전환(후딜 스킵)
  - 대시 종료 후 `dash_cancel_window`(기본 0.2초) 안에 공격/스킬 입력 → 남은 후딜 스킵
- **글로벌 쿨타임(GCD, 기본 0.35초)**: QWER 스킬끼리만 공유. 다음 스킬을 예약하면 후딜을 끊고
  GCD가 풀리는 순간 자동 발동 → 끊김 없는 딜 사이클.
- **평타(좌클릭)는 GCD 무관** — 자체 콤보 간격으로만 페이싱. 스킬 후딜 사이에 자유롭게 끼워넣기.
  (평타→평타 난사는 콤보 recover 로 방지, 적 스턴락은 `Enemy.stagger_immune` 로 방지)
- **튜닝 상수는 인스펙터 `@export`** — `move_speed`, `dash_time/speed/cooldown`, `dash_cancel_window`,
  `gcd_time`, `max_hp`, `hurt_time` (기획서 2-8)

### 스쿼시-스트레치 디폼 (컬트 오브 더 램식 "띠용")
- `scripts/Jelly.gd`: 유닛(플레이어/몹/보스)의 스프라이트를 감싸는 `Vis` 노드에 붙는다.
  본체 속도를 읽어 **진행축으로 늘고 직교축으로 눌리며**, 걸을 때 세로로 통통 튀고(속도 비례),
  정지 시엔 미세하게 숨 쉰다. 스프링 감쇠라 목표를 지나쳤다 되돌아온다.
- `poke()` / `poke_dir()`: 피격(납작하게), 대시·돌진(앞으로 쭉), 착지·처치, 스킬 시전 등에서 순간 변형.
- 튜닝은 `Vis` 인스펙터에서 (`stiffness` / `damping` / `walk_bounce` / `speed_stretch` / `tilt` ...).
- 콜리전·체력바는 `Vis` 밖(본체 직속)이라 안 흔들린다.

### 타격 피드백 (기획서 2-4)
- `scripts/SlashEffect.gd`: 검기 / 범위 이펙트. 빗나가도 나옴 → "입력 먹혔는지" 피드백
- `scripts/HitSpark.gd`: 피격 스파크. 처치 시 크게
- `scripts/HitstopManager.gd` (오토로드 `Hitstop`): 적중 시에만 히트스탑
- 피격 시 **화면이 빨개진다** (`Hud.gd`) — 피해량에 비례(치명타일수록 진하게), 체력 30% 미만이면 은은한 빨간 맥동
- `scripts/Sfx.gd` (오토로드 `Sfx`): **절차적 효과음**. 외부 에셋 없이 코드로 파형을 굽는다.
  저역 강조 타격음(약/강) + 크리티컬 고음 레이어 + 휙 소리 / 대시 / 예비동작 / 피격 / 처치
- 필살기(R)는 적중 시 화면 슬로우 + 강한 셰이크

### 몬스터 AI (기획서 2-3 무적 프레임 검증)
- `scripts/Enemy.gd`: IDLE → CHASE → **TELE(노란 발광 + 빨간 피격범위 예고)** → ATTACK(돌진) → RECOVER
  - TELE 진입 시 공격 방향을 확정하고, **착지 예상 지점에 `AoeWarning` 원형 장판**을 띄운다
    (`damage 0` = 표시만). 딱 붙어도 어디를 맞는지 보이고, 재조준 없이 그 방향으로만 돌진.
  - 예고를 보고 대시/W/R의 무적으로 회피, 직후 되받아치는 루프
  - TELE/ATTACK 중 맞으면 예비동작 + 예고 취소
- 플레이어 피격: `hurt_time` 동안 경직 + 무적, 넉백, HP UI, 0이 되면 완전 회복(프로토타입, 게임오버 없음)

### 몬스터 체급 (기획서 2-4)
- `Enemy.weight` (`@export`): **LIGHT / HEAVY / FIXED / RANGED**
  - LIGHT: 작고 빠름, 넉백 ×1.4, HP 30
  - HEAVY: 크고 느림, 넉백 ×0.5, HP 70
  - FIXED: 안 밀림(넉백 ×0), 경직 거의 없음, HP 55
  - **RANGED**: 사거리(190~360) 유지하며 스트레이프 → 조준(시안색 콘 예고) → 투사체 발사.
    HP 20으로 약함, 붙으면 후퇴. `Projectile.gd` 재사용
- 각 방의 웨이브에 체급을 섞어 스폰
- 피격 후 `경직시간 + 0.55초` 재경직 면역 → 연타 스턴락 방지

### 거점 ↔ 던전 루프 (확장 2단계)
- `scripts/Game.gd` + `scenes/Game.tscn` (**메인 씬**): `World` 컨테이너에 거점/던전 씬을 교체 로드
- `scripts/Base.gd` + `scenes/Base.tscn`: 거점 방 + 스테이션 (던전 포탈 / 영혼 제단)
- `scripts/Interactable.gd` + `.tscn`: 근처에 오면 `[F]` 프롬프트 → `triggered(id)` 신호
- `scripts/Altar.gd`: 영혼 제단(강화). `GameOver.gd` 에서 사망/재시작 걷어내고 제단만. Tab/Esc 로 어디서든
- `scripts/Arena.gd`: `run_ended(cleared)` 시그널. 사망/보스 클리어 → 재시작 대신 거점 복귀(결과 배너 1.9초)

### 빌드연구 (확장 3단계)
- `scripts/Research.gd` (오토로드): 연구 노드 9종·2티어, `user://` 저장.
  `unlock` → 제단 오퍼 풀에 잠긴 강화(정의 강화 4종 + 흡혈·탐욕) 추가.
  `passive` → 영구 스탯(채집 +30% / 받는 피해 -1 / 최대 체력 +12), `Player._apply_meta` 합산
- `scripts/ResearchBench.gd`: 연구소 UI. 거점 청록 스테이션에서 `F`
- `Meta._available()` 이 `locked` 강화를 `Research` 로 필터

### 채집 자원 (확장 1단계 — `Docs/확장_기획서.md`)
- `scripts/Inventory.gd` (오토로드 `Inventory`): 자원 카운트(목재·석재·약초·광석), `user://` 별도 저장
- `scripts/ResourceNode.gd` + `.tscn`: AI 없는 파괴 가능 오브젝트. 종류별 색·크기·체력·산출량 다름.
  전투방에 흩어져 있고(클리어 판정엔 무관), 공격으로 부수면 자원 드랍
- `scripts/Pickup.gd`: 영혼 + 자원 드랍 공용 (`Soul.gd` 일반화). 자석·팝 연출 그대로.
  `kind=="soul"` → `Meta`, 그 외 → `Inventory`
- Player `_hit_targets()` = `enemy` + `harvestable` 그룹. Arena 방 1~4에 wood/herb → stone/ore 순으로 배치
- HUD 하단에 자원 카운터

### 방 구조 (기획서 2-6)
- `scripts/Arena.gd`: 방 6개를 가로로 이어붙임 — **입구 → 전투방 ×4 → 보스방**
- `scripts/Room.gd`: 각 방은 벽(`StaticBody2D`)으로 둘러싸여 **밖으로 못 나간다**. 오른쪽에 문.
  - 방에 진입하면 **뒤 문이 잠기고**(백트래킹 차단) 웨이브 시작
  - 웨이브 전멸 → 다음 웨이브, 전부 클리어 → 오른쪽 문 개방
  - 전투방은 웨이브 3회, **뒤로 갈수록 물량·중량·원거리 증가** (Arena.gd `defs` 배열에서 조정)
  - 보스방은 보스 1기
- 카메라는 아레나 전체 폭으로 limit 설정

### 사망 / 재시작 / 메타 성장 (컬트 오브 더 램식 교단 업그레이드)
- `scripts/GameOver.gd` = **영혼 제단** (강화 화면). 세 가지로 열림:
  - **Tab: 아무 때나** (게임 일시정지, `닫기 [Tab/Esc]`)
  - 사망 시 **검은 바탕 + 빨간 "YOU DIED"**, 클리어 시 "YOU WIN" (그땐 `다시 시작 [R]`만)
  - 뜬 직후 0.4초는 입력 무시(연타로 즉시 닫힘/재시작 방지)
- `scripts/Meta.gd` (오토로드 `Meta`): 런에서 모은 **영혼**을 죽어도 유지, `user://` 에 저장.
  - 몹 처치 시 `scripts/Soul.gd` **영혼 드랍 아이템**이 흩어지고, 플레이어가 가까이 가면 빨려들어감.
    획득 순간 팝(확대+페이드) + 사운드 + 플레이어 젤리 반응. (보스는 즉시 지급 — 런이 끝나므로)
  - 제단은 **3종 랜덤 오퍼** 중 골라 구매(비용 = 레벨마다 증가). **리롤**은 영혼 소비
    (열 때마다 비용 초기화, 리롤할수록 6 → 10 → 14 …). 구매/최대치 슬롯은 새 랜덤으로 자동 채움.
  - **강화 풀 13종 — HP 한 곳 몰빵 불가하도록 스탯은 최대 2레벨, 정의 강화는 1레벨:**
    - 스탯(생존 루트 분산): 강철 심장(+HP) / **방벽**(피해 -고정) / **불굴**(피격 무적 +) /
      **잔상**(대시 무적 +) / 예리함(+피해%) / 속공(-GCD) / 질풍(-대시쿨) / 흡혈(회복) / 탐욕(+영혼)
    - **정의 강화(★, 플레이 방식 변경)**: 잔영검(대시 후 검기) / 폭주의 그릇(필살 2칸) /
      파쇄격(평타 3타 광역) / 광전사(저체력 시 피해·이속 +40%)
  - Player `_apply_meta()` 가 재시작마다 반영. 봇 플레이테스트에서 HP 없이 방벽+잔상+흡혈+정의 3종으로 클리어 확인
  - 재시작 → 씬 리로드, `Player._apply_meta()` 가 강화치를 다시 적용
- HUD에 보유 영혼 표시

### 보스전 (기획서 2-6 파훼형 미니 긴장감 확장)
- `scripts/Boss.gd` + `scenes/Boss.tscn`: HP바(1050), 2페이즈, **패턴 10종**
  - 상태: INTRO → IDLE(패턴 선택) → **TELE(노란 발광 + 빨간 예고 장판)** → ACT → RECOVER
  - **페이즈1은 첫 도전자용으로 완만하게**: 첫 패턴은 느린 예고형 고정, 패턴 간격 0.8~1.25초, 예고 길게.
    페이즈2(HP 50%↓)부터 간격 촘촘 + 원거리/소환/난도 패턴 해금 → 본격 난이도
  - 페이즈1 풀: `charge`(돌진) / `triple_charge`(3연 돌진) / `cone_slash`(부채꼴 참격) /
    `ring_aoe`(도넛 장판) / `cross_aoe`(십자 장판)
  - HP 50% → 페이즈2 전환(무적 + 로어), 풀에 추가: `bullet_spray`(방사 산탄) /
    `homing_shots`(유도 투사체) / `summon`(잡몹 소환) / `jump_slam`(점프 내려찍기) / `spin`(회전 난도)
- `scripts/Projectile.gd`: 보스 투사체 (직선 / 유도), 거리 판정
- `scripts/AoeWarning.gd`: 예고형 장판 (원 / 도넛 / 십자 / 부채꼴). tele 후 폭발하며 범위 내 플레이어 타격.
  `damage<=0` 이면 경고만 (돌진 경로 표시용)
- 보스도 `enemy` 그룹 → 플레이어 스킬로 그대로 타격, 게이지도 충전됨

### 필살기 게이지 (기획서 2-3)
- `ultimate_gauge` 0~100. 적 타격 +6/회, 피격 시 피해량 ×0.9 만큼 축적
- R은 쿨다운이 아니라 게이지 100% 소모

### 판정 방식
공격 판정은 물리 Area2D 대신 `_resolve_hit()`에서 `enemy` 그룹을 순회하며 사거리 + 각도로 검사.
몬스터/보스 공격은 `player` 그룹 대상 거리·형태 검사. 벽만 물리 콜라이더(`StaticBody2D`).

## 자체검증
```bash
"<godot>" --headless --path . res://tests/test_combat.tscn
"<godot>" --headless --path . res://tests/test_arena.tscn
```
- `test_combat`: 이동 / 평타 / GCD·딜사이클 / 피격·게이지 / 무적 / 필살기 / 넉백 3단계 / 몬스터 공격 / 젤리 디폼 / 사망·시그널 / 메타 성장 / 스턴락 방지 / 영혼 드랍·획득
- `test_arena`: 방 6개·벽 / 벽 밖 이탈 불가 / 전투방 4개 클리어 진행(난이도 증가·원거리 등장) / 보스 패턴 10종 완주 / 보스 처치 → `run_ended(true)` + 영혼 획득
- `test_loop`: 거점 로드 → 던전 입장 → 보스 처치 → 거점 복귀 → Tab 제단 (Game.tscn 통합)
- `playthrough` (수동, ~5분): 자동 봇이 Main.tscn 을 실제로 플레이 — 6개 방 클리어 시도, 죽으면 강화 사고 재시작
- `qa_balance` / `qa_boss` (수동, 백그라운드 권장): 고정 빌드 여러 개로 자동 플레이해 클리어 가능 여부를 표로 뽑는 밸런스 QA
  ```
  godot --headless --path . res://tests/playthrough.tscn
  godot --headless --path . res://tests/qa_boss.tscn
  ```

### 밸런스 QA 결과 (봇 자동 플레이)
- **방 1~4**: 무강화 포함 모든 빌드가 사망 1~2회로 통과. 난이도 곡선 OK
- **보스**: 6레벨 빌드(탱/브루저/글래스캐논)·9레벨 밸런스 전부 첫 시도 격파(18~46초).
  무강화(0레벨)만 미격파(보스 HP 46%까지) — 최소한의 강화 투자를 요구하는 게이트
- **지배 빌드 없음**: HP 없이 아머·회피·흡혈·공격 어느 축으로도 클리어 가능

## 아직 없는 것 / 다음 단계 (기획서 2-5)
- 인벤토리 배치형 아티팩트, 무기 교체 — 기획서에서도 MVP 이후로 명시
  (메타 성장은 넣었지만, 런 단위 빌드 선택은 아직)
- 방 랜덤 구성 / 방 개수 확장, 방 사이 카메라 전환, 파훼(스태거) 게이지
- 클릭 이동은 경로 탐색 없음 (적/벽에 막히면 미는 정도)
- 이펙트/사운드/도형은 코드 생성 placeholder — 실제 아트/오디오 에셋으로 교체 예정

## 코드 구조
```
scenes/
  Main.tscn      - Arena + 플레이어 + HUD
  Player.tscn    - CharacterBody2D > Vis(Jelly) > Sprite, Camera2D
  Enemy.tscn     - CharacterBody2D > Vis(Jelly) > Sprite, 체력바
  Boss.tscn      - CharacterBody2D > Vis(Jelly) > Sprite, 체력바
scripts/
  Arena.gd           - 방 배치 + 진행(문 잠금/개방, 카메라 limit)
  GameOver.gd        - 영혼 제단 (Tab 상시 / 사망·클리어 시 자동) + 3종 오퍼·리롤 + 재시작
  Meta.gd            - 오토로드: 영혼·영구 강화·제단 오퍼 저장(user://)
  Soul.gd            - 영혼 드랍 아이템 (자석·획득 팝)
  Jelly.gd           - 스쿼시-스트레치 디폼 (Vis 노드에 부착)
  Room.gd            - 방 1개: 벽·문 생성, 웨이브 스폰, 클리어 판정
  Player.gd          - 이동 / 평타·QWER / 대시·캔슬 / GCD / HP·무적 / 게이지 / 판정
  Enemy.gd           - 추격·예비동작·돌진 AI + RANGED 카이팅 / 체급별 스탯 / 경직 면역
  Boss.gd            - 2페이즈, 패턴 10종
  Projectile.gd      - 투사체 (보스 + RANGED 적 공용, 직선/유도)
  AoeWarning.gd      - 예고형 장판 (원/도넛/십자/부채꼴)
  Hud.gd             - 체력 / 게이지 / QWER 표시
  HitstopManager.gd  - 오토로드: 히트스탑 + 카메라 셰이크
  Sfx.gd             - 오토로드: 절차적 효과음
  SlashEffect.gd     - 검기 / 범위 이펙트 (_draw)
  HitSpark.gd        - 피격 스파크 (_draw)
tests/
  test_combat.tscn   - 전투 자체검증
  test_arena.tscn    - 방 진행 + 보스 자체검증
```
