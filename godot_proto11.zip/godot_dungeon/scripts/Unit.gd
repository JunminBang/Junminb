# Unit.gd
# 플레이어 파티 몬스터 유닛

class_name Unit
extends CharacterBody2D

enum State { IDLE, MOVING, ATTACKING, DEAD }

var state: int = State.IDLE
var controlled: bool = false   # 플레이어가 직접 조종 중
var unit_type: String = "slime"
var hp: int = 60
var max_hp: int = 60
var atk: int = 10
var speed: float = 130.0
var atk_range: float = 55.0
var atk_cooldown: float = 1.2
var _atk_timer: float = 0.0
var _target: Node2D = null
var _move_target: Vector2 = Vector2.ZERO
var _has_move_target: bool = false
var party_index: int = 0   # 0~3, 파티에서 몇 번째인지
var _wander_timer: float = 0.0
var _wander_pos: Vector2 = Vector2.ZERO
var _has_wander_pos: bool = false

signal died(index: int)
signal hp_changed(cur: int, max_v: int)

# 타입별 기본 색상
const TYPE_COLORS: Dictionary = {
	"slime":    Color(0.5, 0.9, 0.3),
	"skeleton": Color(0.95, 0.93, 0.85),
	"orc":      Color(0.4, 0.55, 0.25),
	"goblin":   Color(0.95, 0.9, 0.4),
}

# 타입별 기본 스탯
const TYPE_STATS: Dictionary = {
	"slime":    {"hp": 60,  "atk": 10, "speed": 130.0, "range": 80.0},
	"skeleton": {"hp": 45,  "atk": 18, "speed": 110.0, "range": 90.0},
	"orc":      {"hp": 140, "atk": 22, "speed": 75.0,  "range": 95.0},
	"goblin":   {"hp": 40,  "atk": 26, "speed": 165.0, "range": 75.0},
}

func setup(type: String, hp_bonus: int, atk_bonus: int) -> void:
	unit_type = type
	var stats: Dictionary = TYPE_STATS[type]
	max_hp = stats["hp"] + hp_bonus
	hp = max_hp
	atk = stats["atk"] + atk_bonus
	speed = stats["speed"]
	atk_range = stats["range"]

func _ready() -> void:
	add_to_group("unit")
	collision_layer = 2
	collision_mask = 5  # 1=wall, 4=adventurer

	# 콜리전 셰이프 생성
	var col := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 18.0
	col.shape = shape
	add_child(col)

func _physics_process(delta: float) -> void:
	if state == State.DEAD:
		return

	_atk_timer -= delta
	if _atk_timer < 0.0:
		_atk_timer = 0.0

	# 타겟 유효성 확인
	if _target != null and (not is_instance_valid(_target) or _target.is_queued_for_deletion()):
		_target = null

	if _target == null:
		_target = _find_nearest_enemy()

	# 공격은 조종 여부 상관없이 항상 실행
	if _target != null:
		var dist: float = global_position.distance_to(_target.global_position)
		if dist <= atk_range:
			_attack(_target)

	# 이동 AI는 조종 중일 때 Main에서 처리
	if controlled:
		return

	if _target != null:
		var dist: float = global_position.distance_to(_target.global_position)
		if dist > atk_range:
			var dir: Vector2 = (_target.global_position - global_position).normalized()
			velocity = dir * speed
			move_and_slide()
		else:
			velocity = Vector2.ZERO
	else:
		_do_wander(delta)

func _do_wander(delta: float) -> void:
	_wander_timer -= delta
	if _wander_timer <= 0.0 or not _has_wander_pos:
		_wander_timer = randf_range(1.5, 3.5)
		_wander_pos = Vector2(randf_range(100.0, 1180.0), randf_range(100.0, 620.0))
		_has_wander_pos = true
	var dist: float = global_position.distance_to(_wander_pos)
	if dist > 20.0:
		velocity = (_wander_pos - global_position).normalized() * speed * 0.45
		move_and_slide()
	else:
		velocity = Vector2.ZERO
		_has_wander_pos = false

func _find_nearest_enemy() -> Node2D:
	var enemies: Array = get_tree().get_nodes_in_group("adventurer")
	var nearest: Node2D = null
	var best_dist: float = INF
	for e in enemies:
		if not is_instance_valid(e):
			continue
		# 현재 방(visible)의 적만 대상
		var parent: Node2D = e.get_parent() as Node2D
		if parent == null or not parent.visible:
			continue
		var d: float = global_position.distance_to(e.global_position)
		if d < best_dist:
			best_dist = d
			nearest = e
	return nearest

func _attack(target: Node2D) -> void:
	if _atk_timer > 0.0:
		return
	_atk_timer = atk_cooldown
	if target.has_method("take_hit"):
		target.take_hit(atk)
	_play_squash()
	_spawn_hit_fx(target.global_position)

func _spawn_hit_fx(pos: Vector2) -> void:
	# 타겟 위치에 짧게 빛나는 원형 이펙트
	var fx := Node2D.new()
	fx.position = pos
	get_parent().add_child(fx)

	var col: Color = TYPE_COLORS.get(unit_type, Color(1.0, 1.0, 1.0))
	var radius: float = 22.0
	var alpha: float = 1.0

	# 클로저로 draw
	fx.draw.connect(func():
		fx.draw_circle(Vector2.ZERO, radius, Color(col.r, col.g, col.b, alpha * 0.5))
		fx.draw_arc(Vector2.ZERO, radius, 0.0, TAU, 24, Color(col.r, col.g, col.b, alpha), 3.0)
	)
	fx.set_process(true)

	var tw := fx.create_tween()
	tw.tween_method(func(v: float):
		alpha = v
		radius = 22.0 + (1.0 - v) * 14.0
		fx.queue_redraw()
	, 1.0, 0.0, 0.18)
	tw.tween_callback(fx.queue_free)

func _play_squash() -> void:
	var tween: Tween = create_tween()
	tween.tween_property(self, "scale", Vector2(1.4, 0.6), 0.08)
	tween.tween_property(self, "scale", Vector2(0.8, 1.3), 0.08)
	tween.tween_property(self, "scale", Vector2(1.0, 1.0), 0.08)

func take_hit(dmg: int) -> void:
	if state == State.DEAD:
		return
	hp -= dmg
	if hp < 0:
		hp = 0
	hp_changed.emit(hp, max_hp)
	_play_hit_flash()
	if hp <= 0:
		_die()

func _play_hit_flash() -> void:
	var tween: Tween = create_tween()
	tween.tween_property(self, "modulate", Color(1.0, 0.2, 0.2), 0.05)
	tween.tween_property(self, "modulate", Color(1.0, 1.0, 1.0), 0.10)

func _die() -> void:
	state = State.DEAD
	set_physics_process(false)
	var tween: Tween = create_tween()
	tween.tween_property(self, "scale", Vector2(0.0, 0.0), 0.3)
	tween.parallel().tween_property(self, "modulate:a", 0.0, 0.3)
	tween.tween_callback(_emit_died)

func _emit_died() -> void:
	died.emit(party_index)
	queue_free()

func _draw() -> void:
	# 몸통 원
	var col: Color = TYPE_COLORS.get(unit_type, Color(0.5, 0.9, 0.3))
	draw_circle(Vector2.ZERO, 18.0, col)
	draw_arc(Vector2.ZERO, 18.0, 0.0, TAU, 32, Color(0.0, 0.0, 0.0, 0.5), 2.0)

	# controlled 노란 테두리
	if controlled:
		draw_arc(Vector2.ZERO, 22.0, 0.0, TAU, 32, Color(1.0, 0.9, 0.0), 3.0)

	# HP 바 (머리 위)
	var bar_w: float = 40.0
	var bar_h: float = 5.0
	var bar_x: float = -bar_w * 0.5
	var bar_y: float = -28.0
	draw_rect(Rect2(bar_x, bar_y, bar_w, bar_h), Color(0.2, 0.2, 0.2))
	var ratio: float = float(hp) / float(max_hp) if max_hp > 0 else 0.0
	var hp_col: Color = Color(0.2, 0.9, 0.2) if ratio > 0.5 else (Color(0.9, 0.7, 0.1) if ratio > 0.25 else Color(0.9, 0.2, 0.2))
	draw_rect(Rect2(bar_x, bar_y, bar_w * ratio, bar_h), hp_col)
