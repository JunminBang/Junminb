# Room.gd
# 던전의 방 하나. 1280x720 공간 안에 벽/적 배치.

class_name Room
extends Node2D

var room_id: int = 0
var room_type: String = "combat"  # "combat", "chest", "anvil", "start", "exit"
var floor_num: int = 1
var cleared: bool = false
var enemy_count: int = 0
var connected_rooms: Array = []   # Room 노드 참조들
var _enemies: Array = []
var _doors: Array = []            # 도어 딕셔너리들 {rect, dir, target_room, open, color_rect}
var _run_gold_earned: int = 0     # 이 방에서 얻은 골드 합산
var interactable_type: String = ""   # "chest" or "anvil"
var interactable_pos: Vector2 = Vector2.ZERO

signal room_cleared
signal door_entered(target_room: Room)
signal gold_earned(amount: int)

const WALL_THICKNESS: float = 20.0
const ROOM_W: float = 1280.0
const ROOM_H: float = 720.0

# 연결 방향 상수
const DIR_UP    = "up"
const DIR_DOWN  = "down"
const DIR_LEFT  = "left"
const DIR_RIGHT = "right"

func setup(type: String, floor: int, connections: Array) -> void:
	room_type = type
	floor_num = floor
	connected_rooms = connections

func _ready() -> void:
	_make_walls()
	_make_room_content()
	_make_doors()
	if cleared:
		_open_doors()

func _make_walls() -> void:
	# 상하좌우 테두리 벽
	var wall_defs: Array = [
		Rect2(0, 0, ROOM_W, WALL_THICKNESS),                              # 상단
		Rect2(0, ROOM_H - WALL_THICKNESS, ROOM_W, WALL_THICKNESS),        # 하단
		Rect2(0, 0, WALL_THICKNESS, ROOM_H),                              # 좌측
		Rect2(ROOM_W - WALL_THICKNESS, 0, WALL_THICKNESS, ROOM_H),        # 우측
	]
	for wr in wall_defs:
		var body := StaticBody2D.new()
		body.collision_layer = 1
		body.collision_mask = 0
		var col := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = Vector2(wr.size.x, wr.size.y)
		col.shape = shape
		col.position = Vector2(wr.position.x + wr.size.x * 0.5, wr.position.y + wr.size.y * 0.5)
		body.add_child(col)
		add_child(body)

func _make_room_content() -> void:
	match room_type:
		"combat":
			_spawn_enemies()
		"chest":
			_make_chest()
		"anvil":
			_make_anvil()
		"start":
			cleared = true
		"exit":
			cleared = true

func _spawn_enemies() -> void:
	var spawn_types: Array = []
	match floor_num:
		1:
			spawn_types = ["tank", "dps"]
		2, 3:
			spawn_types = ["tank", "dps", "healer"]
		_:
			# floor 4+: 랜덤으로 둘 중 하나
			if randi() % 2 == 0:
				spawn_types = ["tank", "tank", "dps", "dps"]
			else:
				spawn_types = ["tank", "dps", "dps", "healer"]

	for adv_type in spawn_types:
		var adv: Adventurer = Adventurer.new()
		adv.setup(adv_type, floor_num)
		# 오른쪽에 스폰
		adv.position = Vector2(
			randf_range(800.0, 1100.0),
			randf_range(150.0, 570.0)
		)
		adv.died.connect(_on_enemy_died)
		add_child(adv)
		_enemies.append(adv)
		enemy_count += 1

func _make_chest() -> void:
	interactable_type = "chest"
	interactable_pos = Vector2(ROOM_W * 0.5, ROOM_H * 0.5)

	var chest := ColorRect.new()
	chest.size = Vector2(60.0, 60.0)
	chest.position = Vector2(ROOM_W * 0.5 - 30.0, ROOM_H * 0.5 - 30.0)
	chest.color = Color(0.9, 0.8, 0.1)
	chest.name = "ChestRect"
	add_child(chest)

	var hint := Label.new()
	hint.text = "[E] 상자 열기"
	hint.position = Vector2(ROOM_W * 0.5 - 50.0, ROOM_H * 0.5 - 55.0)
	hint.add_theme_font_size_override("font_size", 13)
	hint.add_theme_color_override("font_color", Color(1.0, 0.95, 0.5))
	add_child(hint)

func _make_anvil() -> void:
	interactable_type = "anvil"
	interactable_pos = Vector2(ROOM_W * 0.5, ROOM_H * 0.5)

	var anvil := ColorRect.new()
	anvil.size = Vector2(50.0, 70.0)
	anvil.position = Vector2(ROOM_W * 0.5 - 25.0, ROOM_H * 0.5 - 35.0)
	anvil.color = Color(0.5, 0.5, 0.5)
	anvil.name = "AnvilRect"
	add_child(anvil)

	var hint := Label.new()
	hint.text = "[E] 강화하기"
	hint.position = Vector2(ROOM_W * 0.5 - 45.0, ROOM_H * 0.5 - 55.0)
	hint.add_theme_font_size_override("font_size", 13)
	hint.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	add_child(hint)

func trigger_interactable() -> void:
	if cleared or interactable_type == "":
		return
	cleared = true
	# 열린 상태 시각 변경
	var chest_rect := get_node_or_null("ChestRect")
	if chest_rect:
		chest_rect.color = Color(0.5, 0.4, 0.05)
	room_cleared.emit()
	_open_doors()

func _make_doors() -> void:
	# 연결된 방 수에 따라 방향 자동 배정
	# 방향: 연결 순서에 따라 UP, RIGHT, DOWN 순으로 배정
	var dir_list: Array = [DIR_UP, DIR_RIGHT, DIR_DOWN, DIR_LEFT]
	for i in range(min(connected_rooms.size(), dir_list.size())):
		var target_room: Room = connected_rooms[i]
		var dir: String = dir_list[i]
		_create_door(dir, target_room)

func _create_door(dir: String, target_room: Room) -> void:
	var door_rect := ColorRect.new()
	var door_pos := Vector2.ZERO
	var door_size := Vector2.ZERO

	match dir:
		DIR_UP:
			door_size = Vector2(80.0, 40.0)
			door_pos = Vector2(ROOM_W * 0.5 - 40.0, 0.0)
		DIR_DOWN:
			door_size = Vector2(80.0, 40.0)
			door_pos = Vector2(ROOM_W * 0.5 - 40.0, ROOM_H - 40.0)
		DIR_LEFT:
			door_size = Vector2(40.0, 80.0)
			door_pos = Vector2(0.0, ROOM_H * 0.5 - 40.0)
		DIR_RIGHT:
			door_size = Vector2(40.0, 80.0)
			door_pos = Vector2(ROOM_W - 40.0, ROOM_H * 0.5 - 40.0)

	door_rect.size = door_size
	door_rect.position = door_pos
	door_rect.color = Color(0.3, 0.15, 0.05)
	add_child(door_rect)

	var lbl := Label.new()
	lbl.text = _dir_hint(dir)
	lbl.add_theme_font_size_override("font_size", 11)
	lbl.position = door_pos + Vector2(4.0, 4.0)
	add_child(lbl)

	_doors.append({
		"color_rect": door_rect,
		"dir": dir,
		"target": target_room,
		"open": false,
		"rect": Rect2(door_pos, door_size),
	})

func _dir_hint(dir: String) -> String:
	match dir:
		DIR_UP:    return "↑"
		DIR_DOWN:  return "↓"
		DIR_LEFT:  return "←"
		DIR_RIGHT: return "→"
	return "?"

# 유닛 위치 기준 가까운 열린 문 반환
func get_door_near(world_pos: Vector2, threshold: float = 55.0) -> Room:
	for door in _doors:
		if not door["open"]:
			continue
		var r: Rect2 = door["rect"]
		var center: Vector2 = r.position + r.size * 0.5
		if world_pos.distance_to(center) < threshold:
			return door["target"]
	return null

# 유닛 위치 기준 가까운 상호작용 오브젝트 타입 반환
func get_interactable_near(world_pos: Vector2, threshold: float = 70.0) -> String:
	if cleared or interactable_type == "":
		return ""
	if world_pos.distance_to(interactable_pos) < threshold:
		return interactable_type
	return ""

func _on_enemy_died(gold: int) -> void:
	enemy_count -= 1
	_run_gold_earned += gold
	gold_earned.emit(gold)
	if enemy_count <= 0:
		cleared = true
		room_cleared.emit()
		_open_doors()

func _open_doors() -> void:
	for door in _doors:
		door["open"] = true
		var cr: ColorRect = door["color_rect"]
		cr.color = Color(0.7, 0.5, 0.2)  # 열린 도어 색

func _close_doors() -> void:
	for door in _doors:
		door["open"] = false
		var cr: ColorRect = door["color_rect"]
		cr.color = Color(0.3, 0.15, 0.05)

func open_doors() -> void:
	_open_doors()

func close_doors() -> void:
	_close_doors()

func _draw() -> void:
	# 바닥 어두운 타일 패턴
	var tile_size: float = 64.0
	var cols: int = int(ROOM_W / tile_size) + 1
	var rows: int = int(ROOM_H / tile_size) + 1
	for row in range(rows):
		for col in range(cols):
			var base: Color = Color(0.13, 0.10, 0.08) if (row + col) % 2 == 0 else Color(0.11, 0.08, 0.07)
			draw_rect(Rect2(col * tile_size, row * tile_size, tile_size, tile_size), base)

	# 그리드 선
	for col in range(cols):
		draw_line(Vector2(col * tile_size, 0.0), Vector2(col * tile_size, ROOM_H), Color(0.0, 0.0, 0.0, 0.15), 1.0)
	for row in range(rows):
		draw_line(Vector2(0.0, row * tile_size), Vector2(ROOM_W, row * tile_size), Color(0.0, 0.0, 0.0, 0.15), 1.0)

	# 방 타입 표시 (상단 중앙 텍스트 대신 색 테두리)
	var border_col: Color
	match room_type:
		"start":  border_col = Color(0.2, 0.8, 0.2, 0.5)
		"exit":   border_col = Color(0.8, 0.8, 0.1, 0.5)
		"chest":  border_col = Color(0.9, 0.7, 0.1, 0.4)
		"anvil":  border_col = Color(0.6, 0.6, 0.6, 0.4)
		_:        border_col = Color(0.4, 0.2, 0.1, 0.3)
	draw_rect(Rect2(WALL_THICKNESS, WALL_THICKNESS, ROOM_W - WALL_THICKNESS * 2.0, ROOM_H - WALL_THICKNESS * 2.0), border_col, false, 3.0)
