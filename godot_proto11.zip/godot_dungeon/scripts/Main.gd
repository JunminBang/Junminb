# Main.gd
# 게임 전체 흐름 관리. 루트 노드.

extends Node2D

const UnitScript      := preload("res://scripts/Unit.gd")
const FloorScript     := preload("res://scripts/Floor.gd")
const HudScript       := preload("res://scripts/Hud.gd")
const GameStateScript := preload("res://scripts/GameState.gd")

enum Phase { STORY, META, RUN, ROUTE_SELECT, GAME_OVER }

var phase: int = Phase.STORY

var _hud: Hud = null
var _floor: Floor = null
var _party: Array = []           # Unit 노드들
var _controlled_idx: int = 0
var _run_gold: int = 0           # 이번 런에서 모은 골드
var _current_floor_num: int = 1
var _overlay: CanvasLayer = null # 스토리/메타/선택 UI용
var _party_died_flag: bool = false

# 스토리 대화 데이터
const STORY_LINES: Array = [
	{"speaker": "[ 마왕의 왕좌 ]",  "text": ""},
	{"speaker": "스켈레톤",          "text": "마, 마왕님! 큰일 났습니다!"},
	{"speaker": "마왕",              "text": "무슨 일이냐."},
	{"speaker": "스켈레톤",          "text": "위층에서... 또 모험가들이 내려오고 있습니다! 저희가 막기에는 너무 많아요!"},
	{"speaker": "마왕",              "text": "...직접 나서야겠군. 군대를 소집하라."},
	{"speaker": "스켈레톤",          "text": "넵! 현재 슬라임 한 마리를 동원할 수 있습니다!"},
	{"speaker": "마왕",              "text": "충분하다. 올라간다."},
]
var _story_idx: int = 0
var _story_speaker_lbl: Label = null
var _story_text_lbl: Label = null
var _story_can_advance: bool = true

# 메타 UI 버튼 참조
var _meta_gold_lbl: Label = null
var _upgrade_btns: Array = []

# chest/anvil 이벤트 카드 UI
var _event_overlay: CanvasLayer = null

# 루트 선택 후 보너스
var _next_route_bonus: String = ""

func _ready() -> void:
	randomize()
	get_viewport().physics_object_picking = true
	_show_story()

# ─────────────────────────────────────────────
# STORY 페이즈
# ─────────────────────────────────────────────

func _show_story() -> void:
	phase = Phase.STORY
	_story_idx = 0

	_overlay = CanvasLayer.new()
	_overlay.layer = 10
	add_child(_overlay)

	# 검은 배경
	var bg := ColorRect.new()
	bg.size = Vector2(1280.0, 720.0)
	bg.color = Color(0.0, 0.0, 0.0, 0.95)
	_overlay.add_child(bg)

	# 하단 대화 박스
	var box := Panel.new()
	box.size = Vector2(1100.0, 160.0)
	box.position = Vector2(90.0, 510.0)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.04, 0.08, 0.92)
	style.border_width_left = 2
	style.border_width_right = 2
	style.border_width_top = 2
	style.border_width_bottom = 2
	style.border_color = Color(0.5, 0.3, 0.6)
	style.corner_radius_top_left = 6
	style.corner_radius_top_right = 6
	style.corner_radius_bottom_left = 6
	style.corner_radius_bottom_right = 6
	box.add_theme_stylebox_override("panel", style)
	_overlay.add_child(box)

	# 화자 이름
	_story_speaker_lbl = Label.new()
	_story_speaker_lbl.position = Vector2(20.0, 10.0)
	_story_speaker_lbl.size = Vector2(400.0, 30.0)
	_story_speaker_lbl.add_theme_font_size_override("font_size", 18)
	_story_speaker_lbl.add_theme_color_override("font_color", Color(0.9, 0.75, 1.0))
	box.add_child(_story_speaker_lbl)

	# 대사
	_story_text_lbl = Label.new()
	_story_text_lbl.position = Vector2(20.0, 45.0)
	_story_text_lbl.size = Vector2(1060.0, 80.0)
	_story_text_lbl.add_theme_font_size_override("font_size", 16)
	_story_text_lbl.add_theme_color_override("font_color", Color(0.95, 0.92, 0.95))
	_story_text_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(_story_text_lbl)

	# 힌트
	var hint := Label.new()
	hint.text = "[ 클릭 또는 SPACE ]"
	hint.position = Vector2(870.0, 125.0)
	hint.size = Vector2(220.0, 25.0)
	hint.add_theme_font_size_override("font_size", 12)
	hint.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	box.add_child(hint)

	# 배경 클릭 감지
	bg.gui_input.connect(_on_story_input)
	bg.mouse_filter = Control.MOUSE_FILTER_STOP

	_display_story_line()

func _display_story_line() -> void:
	if _story_idx >= STORY_LINES.size():
		return
	var line: Dictionary = STORY_LINES[_story_idx]
	_story_speaker_lbl.text = line["speaker"]
	_story_text_lbl.text = line["text"]

func _on_story_input(event: InputEvent) -> void:
	if not _story_can_advance:
		return
	if event is InputEventMouseButton:
		var mb: InputEventMouseButton = event as InputEventMouseButton
		if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT:
			_advance_story()

func _input(event: InputEvent) -> void:
	if phase == Phase.STORY:
		if event is InputEventKey:
			var ke: InputEventKey = event as InputEventKey
			if ke.pressed and ke.keycode == KEY_SPACE:
				_advance_story()
		return

	if phase == Phase.RUN:
		_handle_run_input(event)
		if event is InputEventKey:
			var ke: InputEventKey = event as InputEventKey
			if ke.pressed and ke.keycode == KEY_E:
				_try_interact()

func _advance_story() -> void:
	_story_idx += 1
	if _story_idx >= STORY_LINES.size():
		_start_meta()
	else:
		_display_story_line()

# ─────────────────────────────────────────────
# META 페이즈
# ─────────────────────────────────────────────

func _start_meta() -> void:
	phase = Phase.META
	if _overlay != null:
		_overlay.queue_free()
		_overlay = null

	_overlay = CanvasLayer.new()
	_overlay.layer = 10
	add_child(_overlay)

	# 배경
	var bg := ColorRect.new()
	bg.size = Vector2(1280.0, 720.0)
	bg.color = Color(0.04, 0.03, 0.06, 0.97)
	_overlay.add_child(bg)

	# 타이틀
	var title := Label.new()
	title.text = "마왕의 왕좌"
	title.position = Vector2(0.0, 40.0)
	title.size = Vector2(1280.0, 60.0)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 36)
	title.add_theme_color_override("font_color", Color(0.9, 0.7, 1.0))
	_overlay.add_child(title)

	# 부제
	var sub := Label.new()
	sub.text = "\"위에서 또 모험가들이 온다... 준비하라.\""
	sub.position = Vector2(0.0, 95.0)
	sub.size = Vector2(1280.0, 30.0)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 14)
	sub.add_theme_color_override("font_color", Color(0.6, 0.55, 0.65))
	_overlay.add_child(sub)

	# 골드 표시
	_meta_gold_lbl = Label.new()
	_meta_gold_lbl.text = "보유 골드: %d" % GameState.meta_gold
	_meta_gold_lbl.position = Vector2(0.0, 140.0)
	_meta_gold_lbl.size = Vector2(1280.0, 35.0)
	_meta_gold_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_meta_gold_lbl.add_theme_font_size_override("font_size", 20)
	_meta_gold_lbl.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2))
	_overlay.add_child(_meta_gold_lbl)

	# 잠금 해제 현황
	var unlock_lbl := Label.new()
	unlock_lbl.text = "해금된 유닛: " + ", ".join(GameState.unlocked_types)
	unlock_lbl.position = Vector2(0.0, 180.0)
	unlock_lbl.size = Vector2(1280.0, 25.0)
	unlock_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	unlock_lbl.add_theme_font_size_override("font_size", 14)
	unlock_lbl.add_theme_color_override("font_color", Color(0.7, 0.9, 0.7))
	_overlay.add_child(unlock_lbl)

	# 업그레이드 목록
	var upgrades: Array = [
		{"label": "HP 강화 (+10 HP)",       "cost": 50,  "key": "hp_bonus",    "type": "stat"},
		{"label": "공격력 강화 (+3 ATK)",    "cost": 50,  "key": "atk_bonus",   "type": "stat"},
		{"label": "파티 확장 (+1 슬롯, 최대 4)", "cost": 100, "key": "party_size","type": "stat"},
		{"label": "스켈레톤 해금",            "cost": 80,  "key": "skeleton",    "type": "unlock"},
		{"label": "오크 해금",               "cost": 120, "key": "orc",         "type": "unlock"},
		{"label": "고블린 해금",             "cost": 100, "key": "goblin",      "type": "unlock"},
	]

	_upgrade_btns.clear()
	var start_y: float = 225.0
	var col_w: float = 380.0
	var col_gap: float = 20.0
	var cols: int = 3
	var rows_per_col: int = 2

	for i in range(upgrades.size()):
		var upg: Dictionary = upgrades[i]
		var col_idx: int = i % cols
		var row_idx: int = i / cols
		var bx: float = (1280.0 - (col_w * cols + col_gap * (cols - 1))) * 0.5 + col_idx * (col_w + col_gap)
		var by: float = start_y + row_idx * 110.0

		var btn_panel := Panel.new()
		btn_panel.size = Vector2(col_w, 95.0)
		btn_panel.position = Vector2(bx, by)

		var is_purchased: bool = _is_upgrade_purchased(upg)
		var can_afford: bool = GameState.meta_gold >= upg["cost"]

		var ps := StyleBoxFlat.new()
		if is_purchased:
			ps.bg_color = Color(0.1, 0.2, 0.1, 0.8)
			ps.border_color = Color(0.3, 0.5, 0.3)
		elif can_afford:
			ps.bg_color = Color(0.12, 0.1, 0.18, 0.9)
			ps.border_color = Color(0.6, 0.4, 0.7)
		else:
			ps.bg_color = Color(0.08, 0.07, 0.09, 0.8)
			ps.border_color = Color(0.3, 0.3, 0.35)
		ps.border_width_left = 2
		ps.border_width_right = 2
		ps.border_width_top = 2
		ps.border_width_bottom = 2
		ps.corner_radius_top_left = 5
		ps.corner_radius_top_right = 5
		ps.corner_radius_bottom_left = 5
		ps.corner_radius_bottom_right = 5
		btn_panel.add_theme_stylebox_override("panel", ps)
		_overlay.add_child(btn_panel)

		var upg_lbl := Label.new()
		upg_lbl.text = upg["label"]
		upg_lbl.position = Vector2(10.0, 10.0)
		upg_lbl.size = Vector2(col_w - 20.0, 30.0)
		upg_lbl.add_theme_font_size_override("font_size", 14)
		upg_lbl.add_theme_color_override("font_color", Color(0.9, 0.85, 0.95) if not is_purchased else Color(0.5, 0.7, 0.5))
		btn_panel.add_child(upg_lbl)

		var cost_lbl := Label.new()
		cost_lbl.text = "구매 완료" if is_purchased else ("%d 골드" % upg["cost"])
		cost_lbl.position = Vector2(10.0, 42.0)
		cost_lbl.size = Vector2(col_w - 20.0, 25.0)
		cost_lbl.add_theme_font_size_override("font_size", 13)
		cost_lbl.add_theme_color_override("font_color", Color(0.5, 0.7, 0.5) if is_purchased else (Color(1.0, 0.85, 0.2) if can_afford else Color(0.5, 0.5, 0.5)))
		btn_panel.add_child(cost_lbl)

		if not is_purchased:
			var buy_btn := Button.new()
			buy_btn.text = "구매"
			buy_btn.position = Vector2(col_w - 80.0, 60.0)
			buy_btn.size = Vector2(70.0, 28.0)
			buy_btn.disabled = not can_afford
			buy_btn.pressed.connect(_on_upgrade_bought.bind(upg))
			btn_panel.add_child(buy_btn)

		_upgrade_btns.append(btn_panel)

	# 출발 버튼
	var start_btn := Button.new()
	start_btn.text = "출발!"
	start_btn.position = Vector2(540.0, 640.0)
	start_btn.size = Vector2(200.0, 50.0)
	start_btn.pressed.connect(_start_run)
	_overlay.add_child(start_btn)

func _is_upgrade_purchased(upg: Dictionary) -> bool:
	match upg["type"]:
		"unlock":
			return GameState.unlocked_types.has(upg["key"])
		"stat":
			match upg["key"]:
				"party_size":
					return GameState.permanent_upgrades["party_size"] >= 4
				_:
					return false
	return false

func _on_upgrade_bought(upg: Dictionary) -> void:
	if GameState.meta_gold < upg["cost"]:
		return
	GameState.meta_gold -= upg["cost"]

	match upg["type"]:
		"stat":
			match upg["key"]:
				"hp_bonus":
					GameState.permanent_upgrades["hp_bonus"] += 10
				"atk_bonus":
					GameState.permanent_upgrades["atk_bonus"] += 3
				"party_size":
					if GameState.permanent_upgrades["party_size"] < 4:
						GameState.permanent_upgrades["party_size"] += 1
		"unlock":
			if not GameState.unlocked_types.has(upg["key"]):
				GameState.unlocked_types.append(upg["key"])

	# 메타 화면 갱신
	_start_meta()

# ─────────────────────────────────────────────
# RUN 페이즈
# ─────────────────────────────────────────────

func _start_run() -> void:
	phase = Phase.RUN
	_run_gold = 0
	_current_floor_num = 1
	_party_died_flag = false
	_next_route_bonus = ""

	if _overlay != null:
		_overlay.queue_free()
		_overlay = null

	# 파티 구성
	_build_party()

	# HUD 생성
	if _hud != null:
		_hud.queue_free()
	_hud = Hud.new()
	add_child(_hud)
	_hud.update_party(_party)
	_hud.set_controlled(0)
	_hud.set_floor(_current_floor_num, _run_gold)

	_load_floor(_current_floor_num)

func _build_party() -> void:
	# 기존 파티 정리
	for u in _party:
		if is_instance_valid(u):
			u.queue_free()
	_party.clear()

	var slot_count: int = min(GameState.permanent_upgrades["party_size"], 4)
	var hp_bonus: int = GameState.permanent_upgrades["hp_bonus"]
	var atk_bonus: int = GameState.permanent_upgrades["atk_bonus"]

	# 테스트: 4종 고정 조합
	var test_lineup: Array = ["slime", "skeleton", "orc", "goblin"]
	for i in range(slot_count):
		var unit_type: String = test_lineup[i % test_lineup.size()]

		var unit: Unit = Unit.new()
		unit.setup(unit_type, hp_bonus, atk_bonus)
		unit.party_index = i
		unit.died.connect(_on_unit_died)
		unit.hp_changed.connect(_on_unit_hp_changed.bind(i))
		_party.append(unit)

	# 첫 번째 유닛 조종
	_controlled_idx = 0
	if _party.size() > 0:
		_party[0].controlled = true

func _load_floor(floor_num: int) -> void:
	# 이전 Floor 제거 전에 파티 유닛들을 Main으로 reparent
	if _floor != null:
		for u in _party:
			if is_instance_valid(u) and u.get_parent() != null and u.get_parent() != self:
				u.get_parent().remove_child(u)
				add_child(u)
		_floor.queue_free()
		_floor = null

	_floor = Floor.new()
	_floor.setup(floor_num, _party, _next_route_bonus)
	_floor.floor_completed.connect(_on_floor_completed)
	_floor.party_died.connect(_on_party_died)
	_floor.chest_event_triggered.connect(_on_chest_event)
	_floor.anvil_event_triggered.connect(_on_anvil_event)
	add_child(_floor)
	_floor.generate()

	if _hud != null:
		_hud.set_floor_ref(_floor)
		_hud.set_floor(floor_num, _run_gold)
		_hud.update_party(_party)

func _process(delta: float) -> void:
	if phase != Phase.RUN:
		return
	if _party_died_flag:
		return

	_handle_controlled_movement(delta)
	_check_door_proximity()

	# 미니맵 갱신
	if _hud != null:
		_hud.refresh_minimap()

func _check_door_proximity() -> void:
	if _floor == null or _floor.current_room == null:
		return
	if _controlled_idx < 0 or _controlled_idx >= _party.size():
		return
	var unit = _party[_controlled_idx]
	if not is_instance_valid(unit) or unit.state == Unit.State.DEAD:
		return
	var target_room = _floor.current_room.get_door_near(unit.global_position, 55.0)
	if target_room != null:
		_floor.enter_room(target_room)

func _handle_controlled_movement(_delta: float) -> void:
	if _controlled_idx < 0 or _controlled_idx >= _party.size():
		return
	var unit = _party[_controlled_idx]
	if not is_instance_valid(unit) or unit.state == Unit.State.DEAD:
		return

	if unit._has_move_target:
		var dist: float = unit.global_position.distance_to(unit._move_target)
		if dist > 10.0:
			unit.velocity = (unit._move_target - unit.global_position).normalized() * unit.speed
		else:
			unit.velocity = Vector2.ZERO
			unit._has_move_target = false
	else:
		unit.velocity = Vector2.ZERO
	unit.move_and_slide()
	unit.queue_redraw()

func _handle_run_input(event: InputEvent) -> void:
	# 숫자키로 파티 전환
	if event is InputEventKey:
		var ke: InputEventKey = event as InputEventKey
		if ke.pressed:
			match ke.keycode:
				KEY_1: _set_controlled(0)
				KEY_2: _set_controlled(1)
				KEY_3: _set_controlled(2)
				KEY_4: _set_controlled(3)

	# 마우스 클릭
	if event is InputEventMouseButton:
		var mb: InputEventMouseButton = event as InputEventMouseButton

		# 우클릭: 조종 유닛 이동 목표 지정
		if mb.pressed and mb.button_index == MOUSE_BUTTON_RIGHT:
			if _controlled_idx >= 0 and _controlled_idx < _party.size():
				var cu = _party[_controlled_idx]
				if is_instance_valid(cu) and cu.state != Unit.State.DEAD:
					cu._move_target = get_global_mouse_position()
					cu._has_move_target = true
			return

		if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT:
			var click_pos: Vector2 = mb.position

			# 유닛 클릭 감지
			var closest_unit_idx: int = -1
			var closest_unit_dist: float = 50.0
			for i in range(_party.size()):
				var u = _party[i]
				if not is_instance_valid(u) or u.state == Unit.State.DEAD:
					continue
				var d: float = click_pos.distance_to(u.global_position)
				if d < closest_unit_dist:
					closest_unit_dist = d
					closest_unit_idx = i

			if closest_unit_idx >= 0:
				_set_controlled(closest_unit_idx)
				return

			# 적 클릭 감지 → 현재 조종 유닛 타겟 설정
			var enemies: Array = get_tree().get_nodes_in_group("adventurer")
			var closest_enemy: Node2D = null
			var closest_enemy_dist: float = 50.0
			for e in enemies:
				if not is_instance_valid(e):
					continue
				var d: float = click_pos.distance_to(e.global_position)
				if d < closest_enemy_dist:
					closest_enemy_dist = d
					closest_enemy = e

			if closest_enemy != null and _controlled_idx >= 0 and _controlled_idx < _party.size():
				var cu = _party[_controlled_idx]
				if is_instance_valid(cu):
					cu._target = closest_enemy
				return


func _set_controlled(idx: int) -> void:
	if idx < 0 or idx >= _party.size():
		return
	var u = _party[idx]
	if not is_instance_valid(u) or u.state == Unit.State.DEAD:
		return

	# 기존 해제
	if _controlled_idx >= 0 and _controlled_idx < _party.size():
		var prev = _party[_controlled_idx]
		if is_instance_valid(prev):
			prev.controlled = false
			prev.queue_redraw()

	_controlled_idx = idx
	u.controlled = true
	u.queue_redraw()

	if _hud != null:
		_hud.set_controlled(idx)

func _on_unit_died(idx: int) -> void:
	# HUD 갱신
	if _hud != null:
		if idx < _party.size():
			_hud.on_unit_hp(idx, 0, 1)

	# 조종 중이던 유닛이 죽으면 다른 유닛으로 전환
	if idx == _controlled_idx:
		for i in range(_party.size()):
			var u = _party[i]
			if is_instance_valid(u) and u.state != Unit.State.DEAD:
				_set_controlled(i)
				break

func _on_unit_hp_changed(cur: int, max_v: int, idx: int) -> void:
	if _hud != null:
		_hud.on_unit_hp(idx, cur, max_v)

func _on_floor_completed(gold: int) -> void:
	var actual_gold: int = gold
	# 전투 집중 루트 보너스: 골드 +50%
	if _next_route_bonus == "gold":
		actual_gold = int(gold * 1.5)
	_run_gold += actual_gold

	# 층 3 이상이면 중간 세이브
	if _current_floor_num >= 3:
		GameState.meta_gold += _run_gold
		_run_gold = 0

	_current_floor_num += 1
	_show_route_select()

func _on_party_died() -> void:
	if _party_died_flag:
		return
	_party_died_flag = true
	phase = Phase.GAME_OVER
	GameState.meta_gold += _run_gold / 2
	_show_game_over()

# ─────────────────────────────────────────────
# CHEST / ANVIL 이벤트
# ─────────────────────────────────────────────

func _try_interact() -> void:
	if _floor == null or _floor.current_room == null:
		return
	if _controlled_idx < 0 or _controlled_idx >= _party.size():
		return
	var unit = _party[_controlled_idx]
	if not is_instance_valid(unit):
		return
	var room := _floor.current_room
	var itype: String = room.get_interactable_near(unit.global_position, 70.0)
	if itype == "":
		return
	room.trigger_interactable()
	if itype == "chest":
		_show_card_event("chest")
	elif itype == "anvil":
		_show_card_event("anvil")

func _on_chest_event(_room: Room) -> void:
	_show_card_event("chest")

func _on_anvil_event(_room: Room) -> void:
	_show_card_event("anvil")

func _show_card_event(event_type: String) -> void:
	if _event_overlay != null:
		_event_overlay.queue_free()
	_event_overlay = CanvasLayer.new()
	_event_overlay.layer = 20
	add_child(_event_overlay)

	var bg := ColorRect.new()
	bg.size = Vector2(1280.0, 720.0)
	bg.color = Color(0.0, 0.0, 0.0, 0.7)
	_event_overlay.add_child(bg)

	var title_text: String = "보물 상자!" if event_type == "chest" else "대장간 모루"
	var title := Label.new()
	title.text = title_text
	title.position = Vector2(0.0, 80.0)
	title.size = Vector2(1280.0, 50.0)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color(1.0, 0.9, 0.3))
	_event_overlay.add_child(title)

	var cards: Array
	if event_type == "chest":
		cards = [
			{"label": "HP 회복",      "desc": "파티 전원 HP 50% 회복",    "action": "heal"},
			{"label": "공격 강화",    "desc": "이번 런 ATK +5 (일시적)", "action": "atk_temp"},
			{"label": "속도 강화",    "desc": "이번 런 SPD +20 (일시적)","action": "spd_temp"},
		]
	else:
		cards = [
			{"label": "체력 강화",    "desc": "이번 런 HP +10 (영구적)", "action": "hp_perm"},
			{"label": "공격 강화",    "desc": "이번 런 ATK +4 (영구적)", "action": "atk_perm"},
			{"label": "속도 강화",    "desc": "이번 런 SPD +20 (영구적)","action": "spd_perm"},
		]

	var card_w: float = 280.0
	var total_w: float = card_w * 3.0 + 40.0 * 2.0
	var start_x: float = (1280.0 - total_w) * 0.5

	for i in range(cards.size()):
		var card: Dictionary = cards[i]
		var cx: float = start_x + i * (card_w + 40.0)
		var cy: float = 200.0

		var card_panel := Panel.new()
		card_panel.size = Vector2(card_w, 300.0)
		card_panel.position = Vector2(cx, cy)
		var cs := StyleBoxFlat.new()
		cs.bg_color = Color(0.1, 0.08, 0.15, 0.95)
		cs.border_width_left = 2
		cs.border_width_right = 2
		cs.border_width_top = 2
		cs.border_width_bottom = 2
		cs.border_color = Color(0.6, 0.4, 0.8)
		cs.corner_radius_top_left = 8
		cs.corner_radius_top_right = 8
		cs.corner_radius_bottom_left = 8
		cs.corner_radius_bottom_right = 8
		card_panel.add_theme_stylebox_override("panel", cs)
		_event_overlay.add_child(card_panel)

		var card_title := Label.new()
		card_title.text = card["label"]
		card_title.position = Vector2(10.0, 20.0)
		card_title.size = Vector2(card_w - 20.0, 40.0)
		card_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		card_title.add_theme_font_size_override("font_size", 18)
		card_title.add_theme_color_override("font_color", Color(0.95, 0.9, 1.0))
		card_panel.add_child(card_title)

		var card_desc := Label.new()
		card_desc.text = card["desc"]
		card_desc.position = Vector2(10.0, 80.0)
		card_desc.size = Vector2(card_w - 20.0, 100.0)
		card_desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		card_desc.add_theme_font_size_override("font_size", 13)
		card_desc.add_theme_color_override("font_color", Color(0.75, 0.75, 0.85))
		card_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		card_panel.add_child(card_desc)

		var select_btn := Button.new()
		select_btn.text = "선택"
		select_btn.position = Vector2(card_w * 0.5 - 50.0, 240.0)
		select_btn.size = Vector2(100.0, 40.0)
		select_btn.pressed.connect(_on_event_card_selected.bind(card["action"]))
		card_panel.add_child(select_btn)

func _on_event_card_selected(action: String) -> void:
	match action:
		"heal":
			for u in _party:
				if is_instance_valid(u) and u.state != Unit.State.DEAD:
					u.hp = min(u.hp + int(u.max_hp * 0.5), u.max_hp)
					u.hp_changed.emit(u.hp, u.max_hp)
					u.queue_redraw()
		"atk_temp":
			for u in _party:
				if is_instance_valid(u):
					u.atk += 5
		"spd_temp":
			for u in _party:
				if is_instance_valid(u):
					u.speed += 20.0
		"hp_perm":
			for u in _party:
				if is_instance_valid(u):
					u.max_hp += 10
					u.hp += 10
					u.hp_changed.emit(u.hp, u.max_hp)
					u.queue_redraw()
		"atk_perm":
			for u in _party:
				if is_instance_valid(u):
					u.atk += 4
		"spd_perm":
			for u in _party:
				if is_instance_valid(u):
					u.speed += 20.0

	if _event_overlay != null:
		_event_overlay.queue_free()
		_event_overlay = null

# ─────────────────────────────────────────────
# ROUTE_SELECT 페이즈
# ─────────────────────────────────────────────

func _show_route_select() -> void:
	phase = Phase.ROUTE_SELECT

	if _overlay != null:
		_overlay.queue_free()
	_overlay = CanvasLayer.new()
	_overlay.layer = 15
	add_child(_overlay)

	var bg := ColorRect.new()
	bg.size = Vector2(1280.0, 720.0)
	bg.color = Color(0.0, 0.0, 0.0, 0.75)
	_overlay.add_child(bg)

	var title := Label.new()
	title.text = "%d층으로 가는 길" % _current_floor_num
	title.position = Vector2(0.0, 60.0)
	title.size = Vector2(1280.0, 50.0)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5))
	_overlay.add_child(title)

	var routes: Array = [
		{"label": "전투 집중 루트",  "desc": "적 처치 골드 +50%",         "bonus": "gold"},
		{"label": "보물 루트",       "desc": "다음 층 chest 2개 보장",     "bonus": "chest"},
		{"label": "강화 루트",       "desc": "다음 층 anvil 2개 보장",     "bonus": "anvil"},
	]
	routes.shuffle()

	var card_w: float = 300.0
	var gap: float = 40.0
	var total_w: float = card_w * 3.0 + gap * 2.0
	var start_x: float = (1280.0 - total_w) * 0.5

	for i in range(3):
		var route: Dictionary = routes[i]
		var cx: float = start_x + i * (card_w + gap)
		var cy: float = 180.0

		var card := Panel.new()
		card.size = Vector2(card_w, 320.0)
		card.position = Vector2(cx, cy)
		var cs := StyleBoxFlat.new()
		cs.bg_color = Color(0.08, 0.07, 0.12, 0.95)
		cs.border_width_left = 2
		cs.border_width_right = 2
		cs.border_width_top = 2
		cs.border_width_bottom = 2
		cs.border_color = Color(0.5, 0.45, 0.3)
		cs.corner_radius_top_left = 8
		cs.corner_radius_top_right = 8
		cs.corner_radius_bottom_left = 8
		cs.corner_radius_bottom_right = 8
		card.add_theme_stylebox_override("panel", cs)
		_overlay.add_child(card)

		var rlbl := Label.new()
		rlbl.text = route["label"]
		rlbl.position = Vector2(10.0, 25.0)
		rlbl.size = Vector2(card_w - 20.0, 40.0)
		rlbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		rlbl.add_theme_font_size_override("font_size", 17)
		rlbl.add_theme_color_override("font_color", Color(0.95, 0.9, 0.7))
		card.add_child(rlbl)

		var rdesc := Label.new()
		rdesc.text = route["desc"]
		rdesc.position = Vector2(10.0, 80.0)
		rdesc.size = Vector2(card_w - 20.0, 120.0)
		rdesc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		rdesc.add_theme_font_size_override("font_size", 14)
		rdesc.add_theme_color_override("font_color", Color(0.7, 0.7, 0.75))
		rdesc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		card.add_child(rdesc)

		var sel_btn := Button.new()
		sel_btn.text = "이 루트 선택"
		sel_btn.position = Vector2(card_w * 0.5 - 65.0, 265.0)
		sel_btn.size = Vector2(130.0, 40.0)
		sel_btn.pressed.connect(_on_route_selected.bind(route["bonus"]))
		card.add_child(sel_btn)

func _on_route_selected(bonus: String) -> void:
	_next_route_bonus = bonus

	if _overlay != null:
		_overlay.queue_free()
		_overlay = null

	# 골드 보너스 루트: 다음 층 적 처치 골드 +50% 는 Floor/Room에서 처리하기 위해
	# ponytail: gold bonus는 Floor generate 후 Room에 배율 전달 대신 run_gold에 직접 적용
	# 간단히 처리: 골드 보너스는 floor_completed 시 _run_gold에 50% 추가 적립
	if bonus == "gold":
		_next_route_bonus = "gold"

	phase = Phase.RUN
	_load_floor(_current_floor_num)

# ─────────────────────────────────────────────
# GAME_OVER
# ─────────────────────────────────────────────

func _show_game_over() -> void:
	if _overlay != null:
		_overlay.queue_free()
	_overlay = CanvasLayer.new()
	_overlay.layer = 30
	add_child(_overlay)

	var bg := ColorRect.new()
	bg.size = Vector2(1280.0, 720.0)
	bg.color = Color(0.0, 0.0, 0.0, 0.85)
	_overlay.add_child(bg)

	var defeat := Label.new()
	defeat.text = "패배..."
	defeat.position = Vector2(0.0, 220.0)
	defeat.size = Vector2(1280.0, 80.0)
	defeat.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	defeat.add_theme_font_size_override("font_size", 48)
	defeat.add_theme_color_override("font_color", Color(0.7, 0.2, 0.2))
	_overlay.add_child(defeat)

	var gold_lbl := Label.new()
	gold_lbl.text = "획득 골드: %d" % (GameState.meta_gold)
	gold_lbl.position = Vector2(0.0, 330.0)
	gold_lbl.size = Vector2(1280.0, 40.0)
	gold_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	gold_lbl.add_theme_font_size_override("font_size", 22)
	gold_lbl.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2))
	_overlay.add_child(gold_lbl)

	var sub := Label.new()
	sub.text = "(이번 런 획득량의 절반이 지급되었습니다)"
	sub.position = Vector2(0.0, 375.0)
	sub.size = Vector2(1280.0, 30.0)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 14)
	sub.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	_overlay.add_child(sub)

	var back_btn := Button.new()
	back_btn.text = "왕좌로 돌아가기"
	back_btn.position = Vector2(490.0, 450.0)
	back_btn.size = Vector2(300.0, 55.0)
	back_btn.pressed.connect(_on_return_to_meta)
	_overlay.add_child(back_btn)

func _on_return_to_meta() -> void:
	# 파티 유닛 먼저 분리 후 정리 (Floor.queue_free에 딸려 삭제되는 것 방지)
	for u in _party:
		if is_instance_valid(u):
			if u.get_parent() != null and u.get_parent() != self:
				u.get_parent().remove_child(u)
				add_child(u)
			u.queue_free()
	_party.clear()
	if _floor != null:
		_floor.queue_free()
		_floor = null
	if _hud != null:
		_hud.queue_free()
		_hud = null
	_start_meta()
