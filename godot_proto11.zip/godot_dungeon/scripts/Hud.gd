# Hud.gd
# HUD - 파티 슬롯, 층수/골드, 미니맵 배경

class_name Hud
extends CanvasLayer

var _slot_panels: Array = []
var _slot_hp_bars: Array = []
var _slot_labels: Array = []
var _floor_label: Label = null
var _gold_label: Label = null
var _controlled_idx: int = 0
var _minimap_panel: Panel = null
var _minimap_container: Control = null
var _minimap_room_rects: Array = []   # ColorRect 배열 (방 6개)
var _minimap_line_nodes: Array = []   # ColorRect 배열 (연결선)
var _floor_ref: Floor = null          # 미니맵 데이터용

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	# 하단 파티 슬롯 4개
	for i in range(4):
		var panel := Panel.new()
		panel.size = Vector2(110.0, 90.0)
		panel.position = Vector2(10.0 + i * 120.0, 720.0 - 100.0)
		# 스타일 설정
		var style := StyleBoxFlat.new()
		style.bg_color = Color(0.1, 0.08, 0.06, 0.85)
		style.border_width_left = 2
		style.border_width_right = 2
		style.border_width_top = 2
		style.border_width_bottom = 2
		style.border_color = Color(0.4, 0.3, 0.2)
		style.corner_radius_top_left = 4
		style.corner_radius_top_right = 4
		style.corner_radius_bottom_left = 4
		style.corner_radius_bottom_right = 4
		panel.add_theme_stylebox_override("panel", style)
		add_child(panel)
		_slot_panels.append(panel)

		# 유닛 이름 레이블
		var lbl := Label.new()
		lbl.text = "---"
		lbl.position = Vector2(5.0, 5.0)
		lbl.size = Vector2(100.0, 20.0)
		lbl.add_theme_font_size_override("font_size", 12)
		lbl.add_theme_color_override("font_color", Color(0.9, 0.85, 0.7))
		panel.add_child(lbl)
		_slot_labels.append(lbl)

		# HP 바 배경
		var hp_bg := ColorRect.new()
		hp_bg.size = Vector2(90.0, 10.0)
		hp_bg.position = Vector2(10.0, 60.0)
		hp_bg.color = Color(0.2, 0.2, 0.2)
		panel.add_child(hp_bg)

		# HP 바 전경
		var hp_bar := ColorRect.new()
		hp_bar.size = Vector2(90.0, 10.0)
		hp_bar.position = Vector2(10.0, 60.0)
		hp_bar.color = Color(0.2, 0.8, 0.2)
		panel.add_child(hp_bar)
		_slot_hp_bars.append(hp_bar)

		# 슬롯 번호 힌트
		var num_lbl := Label.new()
		num_lbl.text = str(i + 1)
		num_lbl.position = Vector2(90.0, 5.0)
		num_lbl.size = Vector2(15.0, 20.0)
		num_lbl.add_theme_font_size_override("font_size", 11)
		num_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
		panel.add_child(num_lbl)

	# 좌상단 층수 레이블
	var floor_panel := Panel.new()
	floor_panel.size = Vector2(160.0, 30.0)
	floor_panel.position = Vector2(10.0, 10.0)
	var fp_style := StyleBoxFlat.new()
	fp_style.bg_color = Color(0.0, 0.0, 0.0, 0.6)
	fp_style.corner_radius_top_left = 4
	fp_style.corner_radius_top_right = 4
	fp_style.corner_radius_bottom_left = 4
	fp_style.corner_radius_bottom_right = 4
	floor_panel.add_theme_stylebox_override("panel", fp_style)
	add_child(floor_panel)

	_floor_label = Label.new()
	_floor_label.text = "층: 1"
	_floor_label.position = Vector2(10.0, 6.0)
	_floor_label.add_theme_font_size_override("font_size", 14)
	_floor_label.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5))
	floor_panel.add_child(_floor_label)

	# 좌상단 골드 레이블
	var gold_panel := Panel.new()
	gold_panel.size = Vector2(160.0, 30.0)
	gold_panel.position = Vector2(10.0, 45.0)
	gold_panel.add_theme_stylebox_override("panel", fp_style)
	add_child(gold_panel)

	_gold_label = Label.new()
	_gold_label.text = "골드: 0"
	_gold_label.position = Vector2(10.0, 6.0)
	_gold_label.add_theme_font_size_override("font_size", 14)
	_gold_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2))
	gold_panel.add_child(_gold_label)

	# 우상단 미니맵 배경 패널
	_minimap_panel = Panel.new()
	_minimap_panel.size = Vector2(200.0, 150.0)
	_minimap_panel.position = Vector2(1280.0 - 210.0, 10.0)
	var mm_style := StyleBoxFlat.new()
	mm_style.bg_color = Color(0.0, 0.0, 0.0, 0.5)
	mm_style.border_width_left = 1
	mm_style.border_width_right = 1
	mm_style.border_width_top = 1
	mm_style.border_width_bottom = 1
	mm_style.border_color = Color(0.5, 0.4, 0.2)
	mm_style.corner_radius_top_left = 4
	mm_style.corner_radius_top_right = 4
	mm_style.corner_radius_bottom_left = 4
	mm_style.corner_radius_bottom_right = 4
	_minimap_panel.add_theme_stylebox_override("panel", mm_style)
	add_child(_minimap_panel)

	# 미니맵 타이틀
	var mm_title := Label.new()
	mm_title.text = "미니맵"
	mm_title.position = Vector2(8.0, 4.0)
	mm_title.add_theme_font_size_override("font_size", 11)
	mm_title.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	_minimap_panel.add_child(mm_title)

	# 미니맵 컨테이너 (ColorRect 기반)
	_minimap_container = Control.new()
	_minimap_container.position = Vector2(10.0, 25.0)
	_minimap_container.size = Vector2(180.0, 120.0)
	_minimap_panel.add_child(_minimap_container)

	# 방 6개용 ColorRect 미리 생성
	for i in range(6):
		var r := ColorRect.new()
		r.size = Vector2(18.0, 18.0)
		r.color = Color(0.3, 0.3, 0.3)
		r.visible = false
		_minimap_container.add_child(r)
		_minimap_room_rects.append(r)

		# 현재 방 하이라이트용 테두리 (별도 ColorRect)
		var border := ColorRect.new()
		border.size = Vector2(18.0, 18.0)
		border.color = Color(0.0, 0.0, 0.0, 0.0)
		border.visible = false
		_minimap_container.add_child(border)
		_minimap_line_nodes.append(border)  # 재사용: border rect로 활용

func update_party(units: Array) -> void:
	for i in range(4):
		var panel: Panel = _slot_panels[i]
		var lbl: Label = _slot_labels[i]
		var hp_bar: ColorRect = _slot_hp_bars[i]

		if i < units.size() and is_instance_valid(units[i]):
			var unit = units[i]
			lbl.text = unit.unit_type
			var ratio: float = float(unit.hp) / float(unit.max_hp) if unit.max_hp > 0 else 0.0
			hp_bar.size = Vector2(90.0 * ratio, 10.0)
			hp_bar.color = Color(0.2, 0.8, 0.2) if ratio > 0.5 else (Color(0.9, 0.7, 0.1) if ratio > 0.25 else Color(0.9, 0.2, 0.2))
			panel.modulate = Color(1.0, 1.0, 1.0)
		else:
			lbl.text = "---"
			hp_bar.size = Vector2(0.0, 10.0)
			panel.modulate = Color(0.4, 0.4, 0.4)

func on_unit_hp(idx: int, cur: int, max_v: int) -> void:
	if idx < 0 or idx >= _slot_hp_bars.size():
		return
	var hp_bar: ColorRect = _slot_hp_bars[idx]
	var ratio: float = float(cur) / float(max_v) if max_v > 0 else 0.0
	hp_bar.size = Vector2(90.0 * ratio, 10.0)
	hp_bar.color = Color(0.2, 0.8, 0.2) if ratio > 0.5 else (Color(0.9, 0.7, 0.1) if ratio > 0.25 else Color(0.9, 0.2, 0.2))

func set_controlled(idx: int) -> void:
	_controlled_idx = idx
	for i in range(_slot_panels.size()):
		var panel: Panel = _slot_panels[i]
		var style := StyleBoxFlat.new()
		if i == idx:
			style.bg_color = Color(0.25, 0.2, 0.05, 0.95)
			style.border_width_left = 2
			style.border_width_right = 2
			style.border_width_top = 2
			style.border_width_bottom = 2
			style.border_color = Color(1.0, 0.85, 0.1)
		else:
			style.bg_color = Color(0.1, 0.08, 0.06, 0.85)
			style.border_width_left = 2
			style.border_width_right = 2
			style.border_width_top = 2
			style.border_width_bottom = 2
			style.border_color = Color(0.4, 0.3, 0.2)
		style.corner_radius_top_left = 4
		style.corner_radius_top_right = 4
		style.corner_radius_bottom_left = 4
		style.corner_radius_bottom_right = 4
		panel.add_theme_stylebox_override("panel", style)

func set_floor(n: int, gold: int) -> void:
	if _floor_label:
		_floor_label.text = "층: %d" % n
	if _gold_label:
		_gold_label.text = "골드: %d" % gold

func set_floor_ref(floor: Floor) -> void:
	_floor_ref = floor

func refresh_minimap() -> void:
	if _floor_ref == null or not is_instance_valid(_floor_ref):
		return
	var positions: Array = _floor_ref.get_minimap_positions()
	var cell: float = 18.0
	# 미니맵 레이아웃 픽셀 좌표 (컨테이너 기준)
	# idx 0: col1 row0 / 1: col0 row1 / 2: col2 row1 / 3: col0 row2 / 4: col2 row2 / 5: col1 row3
	var col_gap: float = 26.0
	var row_gap: float = 26.0
	var ox: float = 35.0
	var oy: float = 5.0
	var pixel_positions: Array = [
		Vector2(ox + col_gap, oy),
		Vector2(ox, oy + row_gap),
		Vector2(ox + col_gap * 2.0, oy + row_gap),
		Vector2(ox, oy + row_gap * 2.0),
		Vector2(ox + col_gap * 2.0, oy + row_gap * 2.0),
		Vector2(ox + col_gap, oy + row_gap * 3.0),
	]

	for i in range(min(positions.size(), _minimap_room_rects.size())):
		var entry: Dictionary = positions[i]
		var room: Room = entry["room"]
		var is_cur: bool = entry["is_current"]
		var px: Vector2 = pixel_positions[i]

		var box_col: Color
		match room.room_type:
			"start":   box_col = Color(0.2, 0.7, 0.2)
			"exit":    box_col = Color(0.8, 0.8, 0.1)
			"chest":   box_col = Color(0.9, 0.7, 0.1)
			"anvil":   box_col = Color(0.6, 0.6, 0.6)
			"combat":  box_col = Color(0.7, 0.2, 0.2)
			_:         box_col = Color(0.4, 0.4, 0.4)
		if not room.cleared and room.room_type == "combat":
			box_col = box_col.darkened(0.4)

		var rect: ColorRect = _minimap_room_rects[i]
		rect.position = px
		rect.size = Vector2(cell, cell)
		rect.color = box_col
		rect.visible = true

		# 현재 방 테두리 (노란색 테두리는 별도 ColorRect 4개로 표현 대신 색 밝게)
		var border: ColorRect = _minimap_line_nodes[i]
		if is_cur:
			border.position = px - Vector2(2.0, 2.0)
			border.size = Vector2(cell + 4.0, cell + 4.0)
			border.color = Color(1.0, 0.9, 0.1, 0.9)
			border.visible = true
			# rect를 border 위에 올리기 위해 z_index 조정
			rect.z_index = 1
		else:
			border.visible = false
			rect.z_index = 0
