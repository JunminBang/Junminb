# GameState.gd
# 런 간 유지되는 메타 상태 (싱글턴 역할, static 변수로 관리)

class_name GameState

static var meta_gold: int = 0
static var unlocked_types: Array = ["slime", "skeleton", "orc", "goblin"]
static var permanent_upgrades: Dictionary = {
	"hp_bonus": 0,      # 각 유닛 최대 HP +10씩
	"atk_bonus": 0,     # 각 유닛 ATK +3씩
	"party_size": 4,    # 시작 파티 크기 (최대 4)
}
