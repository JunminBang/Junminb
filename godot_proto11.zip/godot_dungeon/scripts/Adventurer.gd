# Adventurer.gd
# 던전을 공략하러 오는 모험가 적

class_name Adventurer
extends CharacterBody2D

var adv_type: String = "tank"
var hp: int = 130
var max_hp: int = 130
var atk: int = 14
var speed: float = 70.0
var atk_range: float = 65.0
var def_val: int = 0
var atk_cooldown: float = 1.4
var _atk_timer: float = 0.0
var _target: Node2D = null
var _heal_timer: float = 0.0
var xp_reward: int = 10  # 골드 보상

signal died(gold: int)

const TYPE_COLORS: Dictionary = {
	"tank":   Color(0.3, 0.5, 0.9),
	"dps":    Color(0.95, 0.5, 0.15),
	"healer": Color(0.3, 0.9, 0.5),
}

const TYPE_LABELS: Dictionary = {
	"tank":   "T",
	"dps":    "D",
	"healer": "H",
}

const TYPE_STATS: Dictionary = {
	"tank":   {"hp": 130, "atk": 14, "speed": 70.0,  "range": 65.0, "def": 5,  "reward": 10},
	"dps":    {"hp": 75,  "atk": 28, "speed": 115.0, "range": 220.0, "def": 0,  "reward": 12},
	"healer": {"hp": 55,  "atk": 8,  "speed": 95.0,  "range": 55.0, "def": 0,  "reward": 8},
}

func setup(type: String, floor_num: int) -> void:
	adv_type = type
	var stats: Dictionary = TYPE_STATS[type]
	# 층수 스케일: floor당 +10% HP, +8% ATK
	var hp_scale: float = 1.0 + (floor_num - 1) * 0.10
	var atk_scale: float = 1.0 + (floor_num - 1) * 0.08
	max_hp = int(stats["hp"] * hp_scale)
	hp = max_hp
	atk = int(stats["atk"] * atk_scale)
	speed = stats["speed"]
	atk_range = stats["range"]
	def_val = stats["def"]
	xp_reward = stats["reward"]

func _ready() -> void:
	add_to_group("adventurer")
	collision_layer = 4
	collision_mask = 3  # 1=wall, 2=unit

	var col := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 18.0
	col.shape = shape
	add_child(col)

func _physics_process(delta: float) -> void:
	_atk_timer -= delta
	if _atk_timer < 0.0:
		_atk_timer = 0.0

	# 타겟 유효성 확인
	if _target != null and (not is_instance_valid(_target) or _target.is_queued_for_deletion() or _target.get("state") == Unit.State.DEAD):
		_target = null

	match adv_type:
		"tank":
			_ai_tank()
		"dps":
			_ai_dps()
		"healer":
			_ai_healer(delta)

func _ai_tank() -> void:
	if _target == null or not is_instance_valid(_target):
		_target = _find_nearest_unit()
	if _target != null:
		var dist: float = global_position.distance_to(_target.global_position)
		if dist <= atk_range:
			velocity = Vector2.ZERO
			_do_attack(_target)
		else:
			velocity = (_target.global_position - global_position).normalized() * speed
			move_and_slide()
	else:
		velocity = Vector2.ZERO

func _ai_dps() -> void:
	if _target == null or not is_instance_valid(_target):
		_target = _find_lowest_hp_unit()
	if _target != null:
		var dist: float = global_position.distance_to(_target.global_position)
		if dist <= atk_range:
			velocity = Vector2.ZERO
			_shoot_bullet(_target)
		else:
			velocity = (_target.global_position - global_position).normalized() * speed
			move_and_slide()
	else:
		velocity = Vector2.ZERO

func _ai_healer(delta: float) -> void:
	_heal_timer -= delta
	if _heal_timer < 0.0:
		_heal_timer = 0.0

	var injured: Node2D = _find_injured_ally()
	if injured != null:
		var dist: float = global_position.distance_to(injured.global_position)
		if dist <= atk_range:
			velocity = Vector2.ZERO
			_heal_ally(injured)
		else:
			velocity = (injured.global_position - global_position).normalized() * speed
			move_and_slide()
	else:
		# 아군 부상자 없으면 가장 가까운 유닛 공격
		if _target == null or not is_instance_valid(_target):
			_target = _find_nearest_unit()
		if _target != null:
			var dist: float = global_position.distance_to(_target.global_position)
			if dist <= atk_range:
				velocity = Vector2.ZERO
				_do_attack(_target)
			else:
				velocity = (_target.global_position - global_position).normalized() * speed
				move_and_slide()
		else:
			velocity = Vector2.ZERO

func _do_attack(target: Node2D) -> void:
	if _atk_timer > 0.0:
		return
	_atk_timer = atk_cooldown
	if target.has_method("take_hit"):
		target.take_hit(atk)

func _shoot_bullet(target: Node2D) -> void:
	if _atk_timer > 0.0:
		return
	_atk_timer = atk_cooldown
	var b := Bullet.new()
	b.dmg = atk
	b.vel = (target.global_position - global_position).normalized() * 380.0
	get_parent().add_child(b)
	b.global_position = global_position

func _heal_ally(target: Node2D) -> void:
	if _heal_timer > 0.0:
		return
	_heal_timer = 3.0
	# 체력 30 회복
	if target.has_method("_heal"):
		target._heal(30)
	else:
		# 직접 hp 조작
		target.hp = min(target.hp + 30, target.max_hp)
		if target.has_signal("hp_changed"):
			target.hp_changed.emit(target.hp, target.max_hp)
		target.queue_redraw()

func _find_nearest_unit() -> Node2D:
	var units: Array = get_tree().get_nodes_in_group("unit")
	var nearest: Node2D = null
	var best_dist: float = INF
	for u in units:
		if not is_instance_valid(u) or u.is_queued_for_deletion():
			continue
		if u.get("state") == Unit.State.DEAD:
			continue
		var parent: Node2D = u.get_parent() as Node2D
		if parent == null or not parent.visible:
			continue
		var d: float = global_position.distance_to(u.global_position)
		if d < best_dist:
			best_dist = d
			nearest = u
	return nearest

func _find_lowest_hp_unit() -> Node2D:
	var units: Array = get_tree().get_nodes_in_group("unit")
	var lowest: Node2D = null
	var lowest_hp: float = INF
	for u in units:
		if not is_instance_valid(u) or u.is_queued_for_deletion():
			continue
		if u.get("state") == Unit.State.DEAD:
			continue
		var parent: Node2D = u.get_parent() as Node2D
		if parent == null or not parent.visible:
			continue
		if float(u.get("hp")) < lowest_hp:
			lowest_hp = float(u.get("hp"))
			lowest = u
	return lowest

func _find_injured_ally() -> Node2D:
	var allies: Array = get_tree().get_nodes_in_group("adventurer")
	for a in allies:
		if not is_instance_valid(a) or a == self or a.is_queued_for_deletion():
			continue
		var parent: Node2D = a.get_parent() as Node2D
		if parent == null or not parent.visible:
			continue
		if a.max_hp > 0 and float(a.hp) / float(a.max_hp) <= 0.5:
			return a
	return null

func take_hit(dmg: int) -> void:
	var actual: int = max(1, dmg - def_val)
	hp -= actual
	if hp < 0:
		hp = 0
	queue_redraw()
	# 피격 플래시
	var tween: Tween = create_tween()
	tween.tween_property(self, "modulate", Color(1.0, 0.3, 0.3), 0.05)
	tween.tween_property(self, "modulate", Color(1.0, 1.0, 1.0), 0.10)
	if hp <= 0:
		_die()

func _die() -> void:
	set_physics_process(false)
	remove_from_group("adventurer")
	var tween: Tween = create_tween()
	tween.tween_property(self, "scale", Vector2(0.0, 0.0), 0.25)
	tween.parallel().tween_property(self, "modulate:a", 0.0, 0.25)
	tween.tween_callback(_emit_died)

func _emit_died() -> void:
	died.emit(xp_reward)
	queue_free()

func _draw() -> void:
	var col: Color = TYPE_COLORS.get(adv_type, Color(0.5, 0.5, 0.9))
	draw_circle(Vector2.ZERO, 18.0, col)
	draw_arc(Vector2.ZERO, 18.0, 0.0, TAU, 32, Color(0.0, 0.0, 0.0, 0.6), 2.0)

	# 타입 레이블
	var lbl: String = TYPE_LABELS.get(adv_type, "?")
	# draw_string은 font 필요, 단순 표시는 arc로 대체 — 레이블은 작은 사각형으로 표시
	# 폰트 없이 색상 구분이 주이므로 타입별 내부 도형 추가
	match adv_type:
		"tank":
			draw_rect(Rect2(-6.0, -6.0, 12.0, 12.0), Color(1.0, 1.0, 1.0, 0.5))
		"dps":
			var pts: PackedVector2Array = PackedVector2Array([
				Vector2(0.0, -8.0), Vector2(7.0, 6.0), Vector2(-7.0, 6.0)
			])
			draw_colored_polygon(pts, Color(1.0, 1.0, 1.0, 0.5))
		"healer":
			draw_rect(Rect2(-2.0, -7.0, 4.0, 14.0), Color(1.0, 1.0, 1.0, 0.6))
			draw_rect(Rect2(-7.0, -2.0, 14.0, 4.0), Color(1.0, 1.0, 1.0, 0.6))

	# HP 바
	var bar_w: float = 40.0
	var bar_h: float = 5.0
	var bar_x: float = -bar_w * 0.5
	var bar_y: float = -28.0
	draw_rect(Rect2(bar_x, bar_y, bar_w, bar_h), Color(0.2, 0.1, 0.1))
	var ratio: float = float(hp) / float(max_hp) if max_hp > 0 else 0.0
	var hp_col: Color = Color(0.9, 0.3, 0.3) if ratio > 0.5 else (Color(0.9, 0.6, 0.1) if ratio > 0.25 else Color(0.9, 0.1, 0.1))
	draw_rect(Rect2(bar_x, bar_y, bar_w * ratio, bar_h), hp_col)


# ─── 투사체 내부 클래스 ───────────────────────────────
class Bullet extends Node2D:
	var vel: Vector2 = Vector2.ZERO
	var dmg: int = 0
	var _life: float = 2.0

	func _process(delta: float) -> void:
		position += vel * delta
		_life -= delta
		if _life <= 0.0:
			queue_free()
			return
		for u in get_tree().get_nodes_in_group("unit"):
			if not is_instance_valid(u) or u.is_queued_for_deletion():
				continue
			if u.get("state") == Unit.State.DEAD:
				continue
			if global_position.distance_to(u.global_position) < 18.0:
				u.take_hit(dmg)
				queue_free()
				return

	func _draw() -> void:
		draw_circle(Vector2.ZERO, 6.0, Color(0.95, 0.55, 0.1))
		draw_circle(Vector2.ZERO, 3.0, Color(1.0, 0.95, 0.5))
