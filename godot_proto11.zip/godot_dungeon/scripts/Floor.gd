# Floor.gd
# 한 층 = 6개 방의 그래프

class_name Floor
extends Node2D

var floor_num: int = 1
var rooms: Array = []        # Room 노드들
var current_room: Room = null
var _party: Array = []       # Unit 노드들
var _gold_this_floor: int = 0
var _route_bonus: String = ""  # "gold", "chest", "anvil"

signal floor_completed(gold_earned: int)
signal party_died
signal chest_event_triggered(room: Room)
signal anvil_event_triggered(room: Room)

func setup(fn: int, party_units: Array, route_bonus: String = "") -> void:
	floor_num = fn
	_party = party_units
	_route_bonus = route_bonus

func generate() -> void:
	# 방 그래프:
	# start(0) → room_a(1), room_b(2)
	# room_a(1) → room_c(3)
	# room_b(2) → room_c(3), room_d(4)
	# room_c(3) → exit(5)
	# room_d(4) → exit(5)

	# 먼저 Room 인스턴스 6개 생성 (연결 전)
	var room_nodes: Array = []
	for i in range(6):
		var r := Room.new()
		r.room_id = i
		r.floor_num = floor_num
		r.visible = false
		r.process_mode = Node.PROCESS_MODE_DISABLED  # 진입 전까지 AI/물리 비활성
		room_nodes.append(r)

	# 타입 배정
	room_nodes[0].room_type = "start"
	room_nodes[5].room_type = "exit"

	# 나머지 4개 중 특수방 배정
	var special_indices: Array = [1, 2, 3, 4]
	special_indices.shuffle()

	# 루트 보너스 적용
	var chest_count: int = 1 if _route_bonus != "chest" else 2
	var anvil_count: int = 0 if _route_bonus != "anvil" else 2

	var assigned_count: int = 0
	for idx in special_indices:
		if assigned_count < chest_count - (1 if _route_bonus == "chest" else 0):
			room_nodes[idx].room_type = "chest"
			assigned_count += 1
		elif _route_bonus == "anvil" and assigned_count < chest_count + anvil_count - 1:
			room_nodes[idx].room_type = "anvil"
			assigned_count += 1
		else:
			room_nodes[idx].room_type = "combat"

	# chest/anvil 최소 1개씩 보장 (루트 보너스 없을 때)
	if _route_bonus == "":
		# special_indices[0] = chest, [1] = anvil, 나머지 = combat
		room_nodes[special_indices[0]].room_type = "chest"
		room_nodes[special_indices[1]].room_type = "anvil"
		room_nodes[special_indices[2]].room_type = "combat"
		room_nodes[special_indices[3]].room_type = "combat"
	elif _route_bonus == "chest":
		room_nodes[special_indices[0]].room_type = "chest"
		room_nodes[special_indices[1]].room_type = "chest"
		room_nodes[special_indices[2]].room_type = "combat"
		room_nodes[special_indices[3]].room_type = "combat"
	elif _route_bonus == "anvil":
		room_nodes[special_indices[0]].room_type = "anvil"
		room_nodes[special_indices[1]].room_type = "anvil"
		room_nodes[special_indices[2]].room_type = "combat"
		room_nodes[special_indices[3]].room_type = "combat"

	# 연결 설정
	# start(0) → room_a(1), room_b(2)
	room_nodes[0].connected_rooms = [room_nodes[1], room_nodes[2]]
	# room_a(1) → room_c(3)
	room_nodes[1].connected_rooms = [room_nodes[3]]
	# room_b(2) → room_c(3), room_d(4)
	room_nodes[2].connected_rooms = [room_nodes[3], room_nodes[4]]
	# room_c(3) → exit(5)
	room_nodes[3].connected_rooms = [room_nodes[5]]
	# room_d(4) → exit(5)
	room_nodes[4].connected_rooms = [room_nodes[5]]
	# exit(5) → 없음
	room_nodes[5].connected_rooms = []

	# 방 setup 및 add_child
	for r in room_nodes:
		r.setup(r.room_type, floor_num, r.connected_rooms)
		r.door_entered.connect(_on_door_entered)
		r.gold_earned.connect(_on_gold_earned)
		r.room_cleared.connect(_on_room_cleared.bind(r))
		add_child(r)
		rooms.append(r)

	# 시작 방 진입
	_enter_room(room_nodes[0])

func _enter_room(room: Room) -> void:
	# 이전 방 숨기고 AI/물리 비활성
	if current_room != null:
		current_room.visible = false
		current_room.process_mode = Node.PROCESS_MODE_DISABLED

	current_room = room
	room.visible = true
	room.process_mode = Node.PROCESS_MODE_INHERIT  # 이 방만 활성화

	# 파티 유닛들 방의 왼쪽에 배치
	var unit_count: int = _party.size()
	for i in range(unit_count):
		var unit = _party[i]
		if not is_instance_valid(unit):
			continue
		# 방 자식으로 이동 (아직 없다면)
		if unit.get_parent() != room:
			if unit.get_parent() != null:
				unit.get_parent().remove_child(unit)
			room.add_child(unit)
		# 왼쪽 배치
		var y_step: float = 100.0
		var y_start: float = 200.0 + i * y_step
		y_start = clamp(y_start, 80.0, 620.0)
		unit.global_position = Vector2(120.0, y_start)

	# exit 방이면 층 완료
	if room.room_type == "exit":
		await get_tree().create_timer(0.5).timeout
		floor_completed.emit(_gold_this_floor)

func enter_room(target_room: Room) -> void:
	_enter_room(target_room)

func _on_door_entered(target_room: Room) -> void:
	_enter_room(target_room)

func _on_gold_earned(amount: int) -> void:
	_gold_this_floor += amount

func _on_room_cleared(room: Room) -> void:
	# chest/anvil 이벤트 트리거
	if room.room_type == "chest":
		chest_event_triggered.emit(room)
	elif room.room_type == "anvil":
		anvil_event_triggered.emit(room)

func _process(_delta: float) -> void:
	# 파티 전멸 감지
	var all_dead: bool = true
	for u in _party:
		if is_instance_valid(u) and u.state != Unit.State.DEAD:
			all_dead = false
			break
	if all_dead and _party.size() > 0:
		party_died.emit()
		set_process(false)

# 미니맵 방 위치 (우상단 영역 기준)
func get_minimap_positions() -> Array:
	# 반환: [{room, pos(Vector2), is_current}]
	# 레이아웃:
	#   [0]       row 0, col 1
	# [1] [2]     row 1, col 0 / 2
	# [3] [4]     row 2, col 0 / 2
	#   [5]       row 3, col 1
	var cell: float = 20.0
	var ox: float = 0.0
	var oy: float = 0.0
	var positions: Array = [
		Vector2(ox + cell, oy),
		Vector2(ox, oy + cell),
		Vector2(ox + cell * 2.0, oy + cell),
		Vector2(ox, oy + cell * 2.0),
		Vector2(ox + cell * 2.0, oy + cell * 2.0),
		Vector2(ox + cell, oy + cell * 3.0),
	]
	var result: Array = []
	for i in range(rooms.size()):
		result.append({
			"room": rooms[i],
			"pos": positions[i],
			"is_current": rooms[i] == current_room,
		})
	return result
