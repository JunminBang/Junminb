extends Node2D
## 플레이어 주변 구슬 링.
## 같은 속성이 연속하면 스택(xN) — shoot_front() 가 스택 전체를 소모해 {type, mult} 반환.

const OrbNodeScript := preload("res://scripts/OrbNode.gd")

const MAX_ORBS    := 6
const ORBIT_R     := 72.0
const ORBIT_SPEED := 1.2   # rad/s

var _orbs: Array = []   # [{type:String, mult:int, node:Node2D}]
var _angle := 0.0

signal changed   # HUD 갱신용


func _process(delta: float) -> void:
	_angle += ORBIT_SPEED * delta
	var n := _orbs.size()
	for i in n:
		var a := _angle + TAU * float(i) / float(n)
		var nd: Node2D = _orbs[i]["node"]
		nd.position = Vector2(cos(a), sin(a)) * ORBIT_R


func add_orb(type: String) -> void:
	if _orbs.size() >= MAX_ORBS:
		var nd: Node2D = _orbs[0]["node"]
		nd.queue_free()
		_orbs.remove_at(0)
	var nd: Node2D = OrbNodeScript.new()
	add_child(nd)
	_orbs.append({"type": type, "mult": 1, "node": nd})
	_recalculate()
	changed.emit()


## 앞 구슬과 같은 속성을 링 전체에서 소모 → {type, mult}. 비어있으면 {}
func shoot_front() -> Dictionary:
	if _orbs.is_empty():
		return {}
	var t: String = _orbs[0]["type"]
	var consumed := 0
	var i := _orbs.size() - 1
	while i >= 0:
		if _orbs[i]["type"] == t:
			var nd: Node2D = _orbs[i]["node"]
			nd.queue_free()
			_orbs.remove_at(i)
			consumed += 1
		i -= 1
	_recalculate()
	changed.emit()
	return {"type": t, "mult": consumed}


## 앞 구슬 1개 버리기
func discard_front() -> void:
	if _orbs.is_empty():
		return
	var nd: Node2D = _orbs[0]["node"]
	nd.queue_free()
	_orbs.remove_at(0)
	_recalculate()
	changed.emit()


func front_type() -> String:
	return _orbs[0]["type"] if not _orbs.is_empty() else ""


func front_mult() -> int:
	return int(_orbs[0]["mult"]) if not _orbs.is_empty() else 0


func size() -> int:
	return _orbs.size()


## 그리드 배치 결과로 순서 재정렬 (type 문자열 배열)
func reorder(types: Array) -> void:
	var nodes: Array = _orbs.map(func(e): return e["node"])
	_orbs.clear()
	for i in types.size():
		_orbs.append({"type": str(types[i]), "mult": 1, "node": nodes[i]})
	_recalculate()
	changed.emit()


## 링을 연속 그룹으로 분해해 [{type, mult}] 반환 후 링 전체 비우기
func consume_groups() -> Array:
	var groups: Array = []
	var i := 0
	while i < _orbs.size():
		var t: String = _orbs[i]["type"]
		var j := i
		while j < _orbs.size() and _orbs[j]["type"] == t:
			j += 1
		groups.append({"type": t, "mult": j - i})
		i = j
	for entry in _orbs:
		var nd: Node2D = entry["node"]
		nd.queue_free()
	_orbs.clear()
	changed.emit()
	return groups


func _recalculate() -> void:
	# 링 전체에서 속성별 총 개수를 세어 각 구슬에 배율 반영
	var counts: Dictionary = {}
	for entry in _orbs:
		var t: String = entry["type"]
		counts[t] = int(counts.get(t, 0)) + 1
	for entry in _orbs:
		var t: String = entry["type"]
		var m: int = int(counts[t])
		entry["mult"] = m
		entry["node"].setup(t, m)
