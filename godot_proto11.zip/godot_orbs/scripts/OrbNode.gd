extends Node2D

const OrbTypes := preload("res://scripts/OrbTypes.gd")
const ORB_R := 14.0

var orb_type := "fire"
var mult     := 1
var _lbl: Label


func _ready() -> void:
	_lbl = Label.new()
	_lbl.add_theme_font_size_override("font_size", 11)
	_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_lbl.size = Vector2(28, 14)
	_lbl.position = Vector2(-14, ORB_R + 3)
	add_child(_lbl)


func setup(type: String, m: int) -> void:
	orb_type = type
	mult = m
	queue_redraw()
	if _lbl:
		_lbl.text = "x%d" % m if m > 1 else ""
		_lbl.add_theme_color_override("font_color", OrbTypes.color(type))


func _draw() -> void:
	var col: Color = OrbTypes.color(orb_type)
	var r := ORB_R + (mult - 1) * 3.0
	draw_circle(Vector2.ZERO, r + 5.0, col * Color(1, 1, 1, 0.22))
	draw_circle(Vector2.ZERO, r, col)
	draw_circle(Vector2(-r * 0.3, -r * 0.3), r * 0.35, col.lightened(0.55))
