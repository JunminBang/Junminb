extends Node2D
## 방 하나. 벽 + 출구 문. 웨이브를 소화하면 cleared 시그널.

const EnemyScript := preload("res://scripts/Enemy.gd")

signal cleared

const WALL := 24.0

var size       := Vector2(960.0, 640.0)
var solid_left  := false
var solid_right := false
var waves: Array = []   # [[hp, hp, ...], ...]  — HP 배열
var is_boss     := false

var _started := false
var _done    := false
var _alive: Array = []
var _wave_i  := -1
var _exit_shape: CollisionShape2D
var _exit_rect: ColorRect


func _ready() -> void:
	_build()


func bounds() -> Rect2:
	return Rect2(global_position - size * 0.5, size)


func _build() -> void:
	var hw := size.x * 0.5
	var hh := size.y * 0.5
	var gap := 140.0
	var seg := (size.y - gap) * 0.5

	var floor_cr := ColorRect.new()
	floor_cr.color = Color(0.12, 0.09, 0.14) if is_boss else Color(0.10, 0.11, 0.16)
	floor_cr.size = size - Vector2(WALL, WALL) * 2.0
	floor_cr.position = -floor_cr.size * 0.5
	floor_cr.z_index = -10
	add_child(floor_cr)

	_wall(Vector2(0, -hh + WALL * 0.5), Vector2(size.x, WALL))
	_wall(Vector2(0,  hh - WALL * 0.5), Vector2(size.x, WALL))
	if solid_left:
		_wall(Vector2(-hw + WALL * 0.5, 0), Vector2(WALL, size.y))
	if solid_right:
		_wall(Vector2(hw - WALL * 0.5, 0), Vector2(WALL, size.y))
	else:
		_wall(Vector2(hw - WALL * 0.5, -hh + seg * 0.5), Vector2(WALL, seg))
		_wall(Vector2(hw - WALL * 0.5,  hh - seg * 0.5), Vector2(WALL, seg))
		_build_door(Vector2(hw - WALL * 0.5, 0), Vector2(WALL, gap))


func _wall(c: Vector2, sz: Vector2) -> void:
	var b := StaticBody2D.new()
	b.collision_layer = 1
	b.collision_mask  = 0
	b.position = c
	var cs := CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = sz
	cs.shape = rs
	b.add_child(cs)
	var cr := ColorRect.new()
	cr.color = Color(0.22, 0.20, 0.28)
	cr.size = sz
	cr.position = -sz * 0.5
	b.add_child(cr)
	add_child(b)


func _build_door(c: Vector2, sz: Vector2) -> void:
	var b := StaticBody2D.new()
	b.collision_layer = 1
	b.collision_mask  = 0
	b.position = c
	_exit_shape = CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = sz
	_exit_shape.shape = rs
	b.add_child(_exit_shape)
	_exit_rect = ColorRect.new()
	_exit_rect.color = Color(0.8, 0.65, 0.25)
	_exit_rect.size = sz
	_exit_rect.position = -sz * 0.5
	b.add_child(_exit_rect)
	add_child(b)


func open_exit() -> void:
	if _exit_shape:
		_exit_shape.set_deferred("disabled", true)
		_exit_rect.visible = false


func begin() -> void:
	if _started:
		return
	_started = true
	if waves.is_empty():
		_finish()
		return
	_next_wave()


func _next_wave() -> void:
	_wave_i += 1
	if _wave_i >= waves.size():
		_finish()
		return
	var player: Node2D = get_tree().get_first_node_in_group("player")
	var wave: Array = waves[_wave_i]
	for hp_val in wave:
		var e: CharacterBody2D = EnemyScript.new()
		e.collision_layer = 4
		e.collision_mask  = 1
		e.max_health = int(hp_val)
		e.target = player
		var sp := Vector2(
			randf_range(-size.x * 0.33, size.x * 0.33),
			randf_range(-size.y * 0.33, size.y * 0.33))
		e.position = position + sp
		get_parent().add_child(e)
		_alive.append(e)
		e.died.connect(_on_enemy_died)


func _on_enemy_died(orb_type: String, enemy: Node2D) -> void:
	_alive.erase(enemy)   # queue_free 전에 직접 제거 (is_instance_valid 타이밍 버그 방지)
	var player: Node2D = get_tree().get_first_node_in_group("player")
	if is_instance_valid(player):
		player.orb_ring.add_orb(orb_type)
	if _alive.is_empty():
		_next_wave()


func _finish() -> void:
	if _done:
		return
	_done = true
	open_exit()
	cleared.emit()
