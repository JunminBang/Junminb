extends CharacterBody2D
## 적. 플레이어를 쫓아가 접촉 피해. 처치 시 랜덤 구슬 드롭.

const MOVE_SPD    := 88.0
const CONTACT_DMG := 12
const CONTACT_R   := 30.0
const CONTACT_CD  := 0.7
const ORB_TYPES   := ["fire", "water", "earth", "lightning", "dark", "light"]

signal died(orb_type: String, enemy: CharacterBody2D)

var max_health := 40
var health     := 40
var target: Node2D = null   # add_child 전에 설정

var _contact_cd := 0.0
var _slow       := 1.0
var _slow_t     := 0.0


func _ready() -> void:
	add_to_group("enemy")
	health = max_health
	var col := CollisionShape2D.new()
	var sh  := CircleShape2D.new()
	sh.radius = 16.0
	col.shape = sh
	add_child(col)
	queue_redraw()


func _draw() -> void:
	var pct := float(health) / float(max_health)
	var base := Color(0.78, 0.12, 0.12)
	draw_circle(Vector2.ZERO, 16.0, base)
	draw_circle(Vector2(-4, -4), 5.0, base.lightened(0.4))
	# HP 바
	draw_rect(Rect2(-16, -24, 32, 4), Color(0.2, 0.0, 0.0))
	draw_rect(Rect2(-16, -24, 32.0 * pct, 4), Color(0.9, 0.15, 0.15))


func _physics_process(delta: float) -> void:
	_contact_cd = maxf(0.0, _contact_cd - delta)
	_slow_t = maxf(0.0, _slow_t - delta)
	if _slow_t <= 0.0:
		_slow = 1.0

	if not is_instance_valid(target) or target.dead:
		return

	var to: Vector2 = target.global_position - global_position
	if to.length() > 1.0:
		velocity = to.normalized() * MOVE_SPD * _slow
	else:
		velocity = Vector2.ZERO
	move_and_slide()

	# 접촉 피해
	if _contact_cd <= 0.0 and to.length() < CONTACT_R:
		target.take_hit(CONTACT_DMG)
		_contact_cd = CONTACT_CD


func take_hit(dmg: int, kb: Vector2 = Vector2.ZERO) -> void:
	health -= dmg
	if kb.length() > 0:
		velocity = kb
	queue_redraw()
	if health <= 0:
		died.emit(ORB_TYPES[randi() % ORB_TYPES.size()], self)
		queue_free()


func apply_slow(factor: float, duration: float) -> void:
	_slow = factor
	_slow_t = duration
