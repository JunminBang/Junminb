extends Node2D
## 던전 관리. 방 5개(입구 + 전투 3 + 보스)를 가로로 배치.
## 플레이어가 방에 들어오면 자동으로 begin().

const RoomScript    := preload("res://scripts/Room.gd")
const PlayerScript  := preload("res://scripts/Player.gd")
const HudScript     := preload("res://scripts/Hud.gd")
const OrbGridScript := preload("res://scripts/OrbGrid.gd")
const OrbProjScript := preload("res://scripts/OrbProjectile.gd")

const ROOM_W := 960.0
const ROOM_H := 640.0
const ROOM_N := 5   # 입구(0) + 전투(1~3) + 보스(4)

var rooms: Array = []
var _player: Node2D
var _reached  := 0
var _orb_grid: CanvasLayer = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS  # pause 중에도 _input 수신
	# 플레이어
	_player = PlayerScript.new()
	_player.collision_layer = 2
	_player.collision_mask  = 1   # 벽
	add_child(_player)
	_player.died.connect(_on_player_died)

	# 방 생성
	var x := 0.0
	for i in ROOM_N:
		var r: Node2D = RoomScript.new()
		r.name = "Room%d" % i
		r.size = Vector2(ROOM_W, ROOM_H)
		r.solid_left  = (i == 0)
		r.solid_right = (i == ROOM_N - 1)
		r.is_boss     = (i == ROOM_N - 1)
		r.waves       = _make_waves(i)
		add_child(r)
		r.position = Vector2(x + ROOM_W * 0.5, 0.0)
		r.cleared.connect(_on_cleared.bind(i))
		rooms.append(r)
		x += ROOM_W

	_player.position = rooms[0].position

	# 카메라
	var cam := Camera2D.new()
	_player.add_child(cam)
	cam.make_current()

	# HUD
	var hud: CanvasLayer = HudScript.new()
	add_child(hud)

	# 구슬 그리드
	_orb_grid = OrbGridScript.new()
	add_child(_orb_grid)
	_orb_grid.closed.connect(_on_grid_closed)

	rooms[0].call_deferred("begin")


func _make_waves(room_idx: int) -> Array:
	match room_idx:
		0:   return []                              # 입구
		1:   return [_wave(3, 30), _wave(3, 35)]   # 전투 1
		2:   return [_wave(3, 40), _wave(4, 40)]   # 전투 2
		3:   return [_wave(4, 45), _wave(4, 50)]   # 전투 3
		4:   return [_wave(1, 200)]                 # 보스 (고체력 1마리)
		_:   return []


## hp_val 이 모두 같은 N마리 웨이브
func _wave(count: int, hp_val: int) -> Array:
	var w: Array = []
	for i in count:
		w.append(hp_val)
	return w


func _process(_delta: float) -> void:
	if not is_instance_valid(_player):
		return
	var idx := _room_at(_player.global_position)
	if idx > _reached:
		_reached = idx
		rooms[idx].begin()


func _room_at(gp: Vector2) -> int:
	for i in range(rooms.size() - 1, -1, -1):
		if rooms[i].bounds().has_point(gp):
			return i
	return _reached


func _on_cleared(i: int) -> void:
	if i < rooms.size() - 1:
		rooms[i].open_exit()
	else:
		print("🎉 던전 클리어!")
		# 간단히 씬 리로드
		await get_tree().create_timer(2.0).timeout
		get_tree().reload_current_scene()


func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var ke := event as InputEventKey
		if ke.pressed and ke.physical_keycode == KEY_SPACE:
			if _orb_grid.visible:
				_orb_grid._close()
			elif is_instance_valid(_player) and not _player.dead:
				_open_grid()


func _open_grid() -> void:
	var types: Array = _player.orb_ring._orbs.map(func(e): return str(e["type"]))
	get_tree().paused = true
	_orb_grid.open(types)


func _on_grid_closed(final_orbs: Array) -> void:
	get_tree().paused = false
	# 배치 결과 반영
	_player.orb_ring.reorder(final_orbs)
	# 연속 그룹 자동 발사
	var groups: Array = _player.orb_ring.consume_groups()
	var dir: Vector2 = (_player.get_global_mouse_position() - _player.global_position).normalized()
	for g in groups:
		var proj: Area2D = OrbProjScript.new()
		proj.collision_layer = 8
		proj.collision_mask  = 4
		add_child(proj)
		proj.global_position = _player.global_position
		proj.launch(str(g["type"]), int(g["mult"]), dir)


func _on_player_died() -> void:
	print("💀 사망. 재시작...")
	await get_tree().create_timer(1.5).timeout
	get_tree().reload_current_scene()
