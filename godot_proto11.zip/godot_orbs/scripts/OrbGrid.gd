extends CanvasLayer
## 구슬 배치 그리드 (퍼즐앤드래곤 스타일).
## open(types) 로 열고, Space 로 닫으면 closed(final_orbs) 시그널.
## 드래그 중 다른 칸에 진입하면 자동 스왑.

const OrbTypes := preload("res://scripts/OrbTypes.gd")

signal closed(final_orbs: Array)

const COLS := 3
const ROWS := 2
const CELL := 90
const GAP  := 12

var _orbs: Array = []   # 현재 배열 (type 문자열)
var _drag_idx  := -1
var _drag_pos  := Vector2.ZERO
var _panel: Control


func _ready() -> void:
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS

	_panel = Control.new()
	_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	_panel.draw.connect(_on_draw)
	_panel.gui_input.connect(_on_gui_input)
	add_child(_panel)
	visible = false


func open(orb_types: Array) -> void:
	_orbs     = orb_types.duplicate()
	_drag_idx = -1
	visible   = true
	_panel.queue_redraw()


# ── 드로잉 ──────────────────────────────────────────────────────
func _on_draw() -> void:
	var sz  := _panel.size
	var ori := _origin(sz)
	var font := ThemeDB.fallback_font

	# 반투명 배경
	_panel.draw_rect(Rect2(Vector2.ZERO, sz), Color(0, 0, 0, 0.75))

	# 안내 텍스트
	_panel.draw_string(font,
		Vector2(sz.x * 0.5, ori.y - 24),
		"드래그로 구슬 배치  |  Space: 전투 재개",
		HORIZONTAL_ALIGNMENT_CENTER, -1, 14, Color(0.75, 0.75, 0.75))

	# 셀 (드래그 중인 것 제외)
	for i in _orbs.size():
		if i == _drag_idx:
			continue
		_draw_cell(_orbs[i], _cell_pos(i, ori))

	# 드래그 중인 구슬 (마우스 따라다님)
	if _drag_idx >= 0:
		_draw_cell(_orbs[_drag_idx], _drag_pos - Vector2(CELL, CELL) * 0.5, true)


func _draw_cell(type: String, pos: Vector2, floating := false) -> void:
	var col  := OrbTypes.color(type)
	var font := ThemeDB.fallback_font
	var sz   := Vector2(CELL, CELL)
	var bg   := Color(0.12, 0.12, 0.20) if not floating else Color(0.22, 0.22, 0.32)

	_panel.draw_rect(Rect2(pos, sz), bg)
	_panel.draw_rect(Rect2(pos, sz), col * Color(1, 1, 1, 0.65), false, 2.0)

	var c := pos + sz * 0.5
	var r := CELL * 0.30
	_panel.draw_circle(c, r + 5, col * Color(1, 1, 1, 0.22))
	_panel.draw_circle(c, r, col)
	_panel.draw_circle(c + Vector2(-r * 0.28, -r * 0.28), r * 0.35, col.lightened(0.55))

	_panel.draw_string(font, c + Vector2(0, r + 16),
		OrbTypes.name_kr(type), HORIZONTAL_ALIGNMENT_CENTER, -1, 13, Color.WHITE)


# ── 입력 ────────────────────────────────────────────────────────

func _on_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				var idx := _idx_at(mb.position)
				if idx >= 0:
					_drag_idx = idx
					_drag_pos = mb.position
			else:
				_drag_idx = -1
			_panel.queue_redraw()

	if event is InputEventMouseMotion and _drag_idx >= 0:
		_drag_pos = event.position
		var hover := _idx_at(event.position)
		if hover >= 0 and hover != _drag_idx:
			# PAD 스타일 스왑: 드래그가 지나간 칸과 교환
			var tmp: String   = _orbs[_drag_idx]
			_orbs[_drag_idx]  = _orbs[hover]
			_orbs[hover]      = tmp
			_drag_idx         = hover
		_panel.queue_redraw()


func _close() -> void:
	visible = false
	closed.emit(_orbs)


# ── 헬퍼 ────────────────────────────────────────────────────────
func _origin(sz: Vector2) -> Vector2:
	var w := COLS * (CELL + GAP) - GAP
	var h := ROWS * (CELL + GAP) - GAP
	return (sz - Vector2(w, h)) * 0.5


func _cell_pos(idx: int, ori: Vector2) -> Vector2:
	return ori + Vector2((idx % COLS) * (CELL + GAP), (idx / COLS) * (CELL + GAP))


func _idx_at(pos: Vector2) -> int:
	var ori := _origin(_panel.size)
	for i in _orbs.size():
		if Rect2(_cell_pos(i, ori), Vector2(CELL, CELL)).has_point(pos):
			return i
	return -1
