extends CanvasLayer

const OrbTypes := preload("res://scripts/OrbTypes.gd")

var _player: Node2D = null
var _hp_fill: ColorRect
var _hp_lbl:  Label
var _orb_lbl: Label
var _ring_lbl: Label


func _ready() -> void:
	_player = get_tree().get_first_node_in_group("player")
	_build()


func _build() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.15, 0.0, 0.0)
	bg.size = Vector2(220, 20)
	bg.position = Vector2(16, 16)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	_hp_fill = ColorRect.new()
	_hp_fill.color = Color(0.85, 0.18, 0.18)
	_hp_fill.size = Vector2(220, 20)
	_hp_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.add_child(_hp_fill)

	_hp_lbl = Label.new()
	_hp_lbl.position = Vector2(16, 38)
	_hp_lbl.add_theme_color_override("font_color", Color(0.9, 0.9, 0.9))
	_hp_lbl.add_theme_font_size_override("font_size", 13)
	add_child(_hp_lbl)

	_orb_lbl = Label.new()
	_orb_lbl.position = Vector2(16, 58)
	_orb_lbl.add_theme_font_size_override("font_size", 16)
	add_child(_orb_lbl)

	_ring_lbl = Label.new()
	_ring_lbl.position = Vector2(16, 80)
	_ring_lbl.add_theme_color_override("font_color", Color(0.75, 0.75, 0.75))
	_ring_lbl.add_theme_font_size_override("font_size", 12)
	add_child(_ring_lbl)

	var tip := Label.new()
	tip.text = "좌클릭: 발사   우클릭: 버리기   WASD: 이동"
	tip.position = Vector2(16, 690)
	tip.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	tip.add_theme_font_size_override("font_size", 12)
	add_child(tip)


func _process(_delta: float) -> void:
	if not is_instance_valid(_player):
		return

	var pct := float(_player.hp) / float(_player.max_hp)
	_hp_fill.size.x = 220.0 * maxf(0.0, pct)
	_hp_lbl.text = "HP %d / %d" % [_player.hp, _player.max_hp]

	var ring = _player.orb_ring
	if ring == null:
		return

	var ft: String = ring.front_type()
	var fm: int    = ring.front_mult()
	if ft == "":
		_orb_lbl.text = "구슬 없음"
		_orb_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	else:
		_orb_lbl.text = "[%s  x%d]  →  좌클릭 발사" % [OrbTypes.name_kr(ft), fm]
		_orb_lbl.add_theme_color_override("font_color", OrbTypes.color(ft))

	var parts: Array = []
	for i in ring._orbs.size():
		var entry: Dictionary = ring._orbs[i]
		var t: String = entry["type"]
		parts.append("[%s]" % OrbTypes.name_kr(t) if i == 0 else OrbTypes.name_kr(t))
	_ring_lbl.text = "링: " + "  ".join(parts) if not parts.is_empty() else "링: (비어있음)"
