extends Area2D

const OrbTypes := preload("res://scripts/OrbTypes.gd")

const BASE_DMG := 20
const LIFETIME := 5.0

var orb_type := "fire"
var mult     := 1
var _vel     := Vector2.ZERO
var _life    := LIFETIME
var _hit_set: Array = []


func _ready() -> void:
	var col := CollisionShape2D.new()
	var sh  := CircleShape2D.new()
	sh.radius = 8.0
	col.shape = sh
	add_child(col)
	body_entered.connect(_on_body)


func launch(type: String, m: int, dir: Vector2) -> void:
	orb_type = type
	mult     = m
	_vel     = dir * OrbTypes.speed(type)
	queue_redraw()


func _process(delta: float) -> void:
	_life -= delta
	if _life <= 0.0:
		queue_free()
		return
	_vel = OrbTypes.steer(orb_type, _vel, self, delta)
	global_position += _vel * delta


func _draw() -> void:
	var col: Color = OrbTypes.color(orb_type)
	var r := 8.0 + (mult - 1) * 3.0
	draw_circle(Vector2.ZERO, r + 4.0, col * Color(1, 1, 1, 0.3))
	draw_circle(Vector2.ZERO, r, col)
	draw_circle(Vector2(-r * 0.3, -r * 0.3), r * 0.35, col.lightened(0.55))


func _on_body(body: Node2D) -> void:
	if not body.is_in_group("enemy") or body in _hit_set:
		return
	var destroy: bool = OrbTypes.on_hit(orb_type, body, BASE_DMG * mult, self)
	if destroy:
		queue_free()
	else:
		_hit_set.append(body)
