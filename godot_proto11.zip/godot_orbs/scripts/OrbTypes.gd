extends RefCounted
## 구슬 속성 정의 — 데이터와 동작이 한 파일에.
##
## 밸런싱: DATA 딕셔너리의 숫자 값만 수정.
## 새 속성 추가: DATA 에 항목 추가 → on_hit/steer 에 match 분기 추가.
## OrbProjectile / OrbNode / Hud 는 건드릴 필요 없음.

# ── 속성 데이터 (밸런싱 대상) ─────────────────────────────────
const DATA := {
	"fire": {
		"name_kr": "불",
		"color":   Color(1.0,  0.35, 0.10),
		"speed":   400.0,
		"aoe_r":   90.0,        # 폭발 반경 (픽셀)
	},
	"water": {
		"name_kr":    "물",
		"color":      Color(0.2,  0.55, 1.0),
		"speed":      400.0,
		"slow_fac":   0.45,     # 감속 배율 (낮을수록 강함)
		"slow_dur":   2.0,      # 슬로우 지속 (초)
	},
	"earth": {
		"name_kr":   "흙",
		"color":     Color(0.55, 0.38, 0.12),
		"speed":     220.0,     # 느린 탄속
		"knockback": 580.0,     # 넉백 세기
	},
	"lightning": {
		"name_kr":     "번개",
		"color":       Color(1.0,  0.92, 0.10),
		"speed":       380.0,
		"chain_cnt":   2,       # 연쇄 대상 수
		"chain_r":     220.0,   # 연쇄 탐색 반경 (픽셀)
		"chain_ratio": 0.6,     # 연쇄 피해 배율
	},
	"dark": {
		"name_kr":    "암흑",
		"color":      Color(0.45, 0.10, 0.75),
		"speed":      320.0,
		"steer_rate": 4.0,      # 유도 선회속도 (낮을수록 완만)
	},
	"light": {
		"name_kr": "빛",
		"color":   Color(1.0,  0.97, 0.60),
		"speed":   620.0,       # 고속
		"heal":    5,           # 적중 1회당 회복량
	},
}

const ALL_TYPES := ["fire", "water", "earth", "lightning", "dark", "light"]

# ── 편의 접근자 ───────────────────────────────────────────────
static func color(type: String) -> Color:
	return Color(DATA[type]["color"]) if DATA.has(type) else Color.WHITE

static func name_kr(type: String) -> String:
	return str(DATA[type]["name_kr"]) if DATA.has(type) else type

static func speed(type: String) -> float:
	return float(DATA[type]["speed"]) if DATA.has(type) else 400.0

# ── 매 프레임 속도 수정 ───────────────────────────────────────
static func steer(type: String, vel: Vector2, proj: Area2D, delta: float) -> Vector2:
	match type:
		"dark":
			var nearest: Node2D = _nearest_enemy(proj)
			if nearest:
				var to: Vector2 = (nearest.global_position - proj.global_position).normalized()
				return vel.lerp(to * float(DATA["dark"]["speed"]), float(DATA["dark"]["steer_rate"]) * delta)
	return vel

# ── 충돌 처리. true = 탄 소멸 / false = 관통(계속 진행) ───────
static func on_hit(type: String, body: Node2D, dmg: int, proj: Area2D) -> bool:
	var d: Dictionary = DATA.get(type, {})
	match type:
		"fire":
			var r := float(d["aoe_r"])
			for e in proj.get_tree().get_nodes_in_group("enemy"):
				if is_instance_valid(e) and (e.global_position - proj.global_position).length() < r:
					e.take_hit(dmg, Vector2.ZERO)
			return true

		"water":
			body.take_hit(dmg, Vector2.ZERO)
			body.apply_slow(float(d["slow_fac"]), float(d["slow_dur"]))
			return false   # 관통

		"earth":
			var kb: Vector2 = (body.global_position - proj.global_position).normalized() * float(d["knockback"])
			body.take_hit(dmg, kb)
			return true

		"lightning":
			body.take_hit(dmg, Vector2.ZERO)
			var chained := 0
			for e in proj.get_tree().get_nodes_in_group("enemy"):
				if chained >= int(d["chain_cnt"]): break
				if not is_instance_valid(e) or e == body: continue
				if (e.global_position - proj.global_position).length() < float(d["chain_r"]):
					e.take_hit(int(dmg * float(d["chain_ratio"])), Vector2.ZERO)
					chained += 1
			return true

		"light":
			body.take_hit(dmg, Vector2.ZERO)
			var player: Node2D = proj.get_tree().get_first_node_in_group("player")
			if is_instance_valid(player):
				player.heal(int(d["heal"]))
			return false   # 관통

		_:
			body.take_hit(dmg, Vector2.ZERO)
			return true

# ── 내부 헬퍼 ────────────────────────────────────────────────
static func _nearest_enemy(proj: Area2D) -> Node2D:
	var best: Node2D = null
	var best_d := INF
	for e in proj.get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(e): continue
		var d: float = (e.global_position - proj.global_position).length_squared()
		if d < best_d:
			best_d = d
			best = e
	return best
