extends CharacterBody2D
## 플레이어.
##   WASD          — 이동
##   좌클릭        — 앞 스택 발사
##   우클릭        — 앞 구슬 버리기

const OrbRingScript := preload("res://scripts/OrbRing.gd")
const OrbProjScript := preload("res://scripts/OrbProjectile.gd")
const ORB_TYPES     := ["fire", "water", "earth", "lightning", "dark", "light"]

const MOVE_SPD  := 280.0
const REGEN_T   := 0.5    # 초마다 구슬 자동 생성

signal died

var max_hp := 100
var hp     := 100
var dead   := false
var orb_ring: Node2D = null

var _hurt_t  := 0.0
var _regen_t := 0.0


func _ready() -> void:
	add_to_group("player")
	hp = max_hp

	var col := CollisionShape2D.new()
	var sh  := CircleShape2D.new()
	sh.radius = 18.0
	col.shape = sh
	add_child(col)

	orb_ring = OrbRingScript.new()
	add_child(orb_ring)

	# 초기 구슬 3개
	for i in 3:
		orb_ring.add_orb(ORB_TYPES[randi() % ORB_TYPES.size()])

	queue_redraw()


func _draw() -> void:
	var hurt_flash := _hurt_t > 0.0
	var col := Color(1.0, 0.3, 0.3) if hurt_flash else Color(0.3, 0.65, 1.0)
	draw_circle(Vector2.ZERO, 18.0, col)
	draw_circle(Vector2(-5, -5), 6.0, col.lightened(0.45))


func _physics_process(delta: float) -> void:
	if dead:
		return

	_hurt_t = maxf(0.0, _hurt_t - delta)
	if _hurt_t > 0.0:
		queue_redraw()

	# 이동 (물리 키)
	var dir := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):    dir.y -= 1
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):   dir.y += 1
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):   dir.x -= 1
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):  dir.x += 1
	if dir.length() > 0:
		dir = dir.normalized()
	velocity = dir * MOVE_SPD
	move_and_slide()

	# 구슬 자동 리젠 (최대치 미만일 때만)
	if orb_ring.size() < OrbRingScript.MAX_ORBS:
		_regen_t += delta
		if _regen_t >= REGEN_T:
			_regen_t = 0.0
			orb_ring.add_orb(ORB_TYPES[randi() % ORB_TYPES.size()])


func _input(event: InputEvent) -> void:
	if dead:
		return
	if event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		if not mb.pressed:
			return
		if mb.button_index == MOUSE_BUTTON_LEFT:
			_shoot()
		elif mb.button_index == MOUSE_BUTTON_RIGHT:
			orb_ring.discard_front()


func _shoot() -> void:
	var result: Dictionary = orb_ring.shoot_front()
	if result.is_empty():
		return
	var proj: Area2D = OrbProjScript.new()
	proj.collision_layer = 8
	proj.collision_mask  = 4   # 적 레이어
	get_parent().add_child(proj)
	proj.global_position = global_position
	var dir: Vector2 = (get_global_mouse_position() - global_position).normalized()
	proj.launch(result["type"], result["mult"], dir)


func take_hit(dmg: int) -> void:
	if _hurt_t > 0.0 or dead:
		return
	hp -= dmg
	_hurt_t = 0.5
	queue_redraw()
	if hp <= 0:
		hp = 0
		dead = true
		died.emit()


func heal(amount: int) -> void:
	hp = mini(hp + amount, max_hp)
