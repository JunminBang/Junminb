extends Area2D
## 일반 적기. 패턴 3종: DIVE / ZIGZAG / SHOOTER

const BulletScript := preload("res://scripts/Bullet.gd")

const W := 480.0
const H := 640.0

enum Pattern { DIVE, ZIGZAG, SHOOTER }

signal died(score_val: int)

var hp        := 30
var score_val := 100
var pattern   := Pattern.DIVE
var _player: Node2D = null

var _time    := 0.0
var _fire_t  := 0.0
var _start_x := 0.0
var _fire_rate := 1.6


func _ready() -> void:
	collision_layer = 8
	collision_mask  = 4   # 플레이어 탄환
	add_to_group("enemy")
	var col := CollisionShape2D.new()
	var sh  := CircleShape2D.new()
	sh.radius = 15.0
	col.shape = sh
	add_child(col)


func setup(pat: int, hp_val: int, score: int, player: Node2D) -> void:
	pattern   = pat
	hp        = hp_val
	score_val = score
	_player   = player
	_start_x  = position.x
	_fire_rate = 1.8 if pat != Pattern.SHOOTER else 1.0


func _process(delta: float) -> void:
	_time += delta
	_move(delta)

	if is_instance_valid(_player):
		_fire_t -= delta
		if _fire_t <= 0.0:
			_fire_t = _fire_rate
			_shoot()

	if position.y > H + 50:
		queue_free()
	queue_redraw()


func _move(delta: float) -> void:
	match pattern:
		Pattern.DIVE:
			position.y += 160.0 * delta
		Pattern.ZIGZAG:
			position.y += 130.0 * delta
			position.x = _start_x + sin(_time * 3.2) * 65.0
		Pattern.SHOOTER:
			if _time < 1.2:
				position.y += 90.0 * delta   # 진입 후 정지


func _shoot() -> void:
	if not is_instance_valid(_player):
		return
	var dir: Vector2 = (_player.global_position - global_position).normalized()
	var b: Area2D = BulletScript.new()
	get_parent().add_child(b)
	b.global_position = global_position
	b.setup(dir, 175.0, 10, false)


func take_hit(dmg: int) -> void:
	hp -= dmg
	if hp <= 0:
		died.emit(score_val)
		queue_free()


func _draw() -> void:
	var col := Color(0.85, 0.15, 0.15)
	draw_circle(Vector2.ZERO, 15.0, col)
	draw_circle(Vector2.ZERO, 8.0, Color(1.0, 0.45, 0.1))
	draw_circle(Vector2(-5, -4), 3.5, Color.WHITE)
	draw_circle(Vector2( 5, -4), 3.5, Color.WHITE)
	draw_circle(Vector2(-5, -4), 1.5, Color.BLACK)
	draw_circle(Vector2( 5, -4), 1.5, Color.BLACK)
