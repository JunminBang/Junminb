extends CanvasLayer
## HUD: 점수 / 기체 / 봄버 / 보스 HP바

var _score_lbl:  Label
var _lives_lbl:  Label
var _bombs_lbl:  Label
var _boss_bar:   Control
var _boss_fill:  ColorRect
var _msg_lbl:    Label


func _ready() -> void:
	layer = 10
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	_score_lbl = _make_label(root, Vector2(8, 6),  Color.WHITE)
	_lives_lbl = _make_label(root, Vector2(8, 26), Color(1.0, 0.55, 0.55))
	_bombs_lbl = _make_label(root, Vector2(8, 46), Color(0.55, 0.85, 1.0))

	# 보스 HP바
	_boss_bar = Control.new()
	_boss_bar.position = Vector2(10, 610)
	_boss_bar.size     = Vector2(460, 14)
	_boss_bar.visible  = false
	_boss_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_boss_bar)

	var bg := ColorRect.new()
	bg.size  = Vector2(460, 14)
	bg.color = Color(0.15, 0.0, 0.2)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss_bar.add_child(bg)

	_boss_fill = ColorRect.new()
	_boss_fill.size  = Vector2(460, 14)
	_boss_fill.color = Color(0.85, 0.1, 0.9)
	_boss_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss_bar.add_child(_boss_fill)

	# 중앙 메시지 (클리어/게임오버)
	_msg_lbl = _make_label(root, Vector2(0, 290), Color.YELLOW)
	_msg_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_msg_lbl.size = Vector2(480, 40)
	_msg_lbl.add_theme_font_size_override("font_size", 28)
	_msg_lbl.visible = false

	update_score(0)
	update_lives(3)
	update_bombs(3)


func _make_label(parent: Control, pos: Vector2, col: Color) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_color_override("font_color", col)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(l)
	return l


func update_score(v: int)  -> void: _score_lbl.text = "SCORE  %07d" % v
func update_lives(v: int)  -> void: _lives_lbl.text = "SHIP   " + "[ ] ".repeat(v).strip_edges()
func update_bombs(v: int)  -> void: _bombs_lbl.text = "BOMB   " + "[Z] ".repeat(v).strip_edges()

func show_boss_bar()                        -> void: _boss_bar.visible = true
func hide_boss_bar()                        -> void: _boss_bar.visible = false
func update_boss_hp(cur: int, mx: int)      -> void:
	_boss_fill.size.x = 460.0 * float(cur) / float(mx)

func show_message(msg: String) -> void:
	_msg_lbl.text    = msg
	_msg_lbl.visible = true
