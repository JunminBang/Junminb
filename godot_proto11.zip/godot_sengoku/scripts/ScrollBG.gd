extends Node2D
## 별이 흘러내리는 배경

const W := 480.0
const H := 640.0
const STAR_N := 90

var _stars: Array = []  # [{x,y,r,bright,spd}]


func _ready() -> void:
	randomize()
	for i in STAR_N:
		_stars.append({
			"x": randf() * W,
			"y": randf() * H,
			"r": randf_range(0.5, 2.2),
			"bright": randf_range(0.35, 1.0),
			"spd": randf_range(0.4, 1.6),
		})


func _process(delta: float) -> void:
	for s in _stars:
		s["y"] += 90.0 * s["spd"] * delta
		if s["y"] > H:
			s["y"] -= H
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, Vector2(W, H)), Color(0.02, 0.02, 0.10))
	for s in _stars:
		var b: float = s["bright"]
		draw_circle(Vector2(s["x"], s["y"]), s["r"], Color(b, b, b))
