extends Area2D
## 2페이즈 보스
##   페이즈1 (HP > 40%) — 부채꼴 5방향탄
##   페이즈2 (HP ≤ 40%) — 방사형 12방향탄 + 속도 증가

const BulletScript := preload("res://scripts/Bullet.gd")

const W := 480.0

signal hp_changed(cur: int, max_hp: int)
signal died

var max_hp  := 1200
var hp      := 1200
var _phase  := 1
var _time   := 0.0
var _atk_t  := 0.0
var _player: Node2D = null
var _ready_done := false


func _ready() -> void:
	collision_layer = 8
	collision_mask  = 4
	add_to_group("enemy")
	var col := CollisionShape2D.new()
	var sh  := RectangleShape2D.new()
	sh.size = Vector2(90, 55)
	col.shape = sh
	add_child(col)
	position = Vector2(W * 0.5, -70.0)


func setup(player: Node2D) -> void:
	_player = player


func _process(delta: float) -> void:
	_time += delta

	# 입장 이동
	if position.y < 110.0:
		position.y = minf(position.y + 180.0 * delta, 110.0)
		queue_redraw()
		return

	# 좌우 호버
	position.x = W * 0.5 + sin(_time * 0.7) * 130.0

	# 페이즈 전환
	if _phase == 1 and hp <= max_hp * 0.4:
		_phase = 2

	# 공격
	_atk_t -= delta
	if _atk_t <= 0.0:
		if _phase == 1:
			_attack_spread(5, 28.0, 155.0)
			_atk_t = 1.1
		else:
			_attack_spread(7, 22.0, 175.0)
			_atk_t = 0.08   # 짧게 연속 발사 → 잠깐 후 방사
			_attack_ring(14, 145.0)
			_atk_t = 0.75

	queue_redraw()


func _attack_spread(count: int, half_deg: float, speed: float) -> void:
	if not is_instance_valid(_player):
		return
	var base: Vector2 = (_player.global_position - global_position).normalized()
	for i in count:
		var t := float(i) / float(count - 1) - 0.5   # -0.5 ~ 0.5
		var dir := base.rotated(deg_to_rad(t * half_deg * 2.0))
		_fire(dir, speed)


func _attack_ring(count: int, speed: float) -> void:
	for i in count:
		var dir := Vector2.DOWN.rotated(TAU * float(i) / float(count))
		_fire(dir, speed)


func _fire(dir: Vector2, speed: float) -> void:
	var b: Area2D = BulletScript.new()
	get_parent().add_child(b)
	b.global_position = global_position
	b.setup(dir, speed, 15, false)


func take_hit(dmg: int) -> void:
	hp = maxi(hp - dmg, 0)
	hp_changed.emit(hp, max_hp)
	if hp <= 0:
		died.emit()
		queue_free()


func _draw() -> void:
	var body_col := Color(0.55, 0.05, 0.75) if _phase == 1 else Color(0.85, 0.1, 0.3)
	draw_rect(Rect2(Vector2(-45, -27), Vector2(90, 55)), body_col)
	draw_rect(Rect2(Vector2(-45, -27), Vector2(90, 55)), Color.WHITE, false, 2.0)
	# 코어
	var core_col := Color(1.0, 0.4, 1.0) if _phase == 1 else Color(1.0, 0.8, 0.1)
	draw_circle(Vector2(0, 0), 16.0, core_col)
	draw_circle(Vector2(0, 0), 8.0, Color.WHITE)
	# 눈
	draw_circle(Vector2(-14, -10), 6.0, Color(1.0, 0.85, 0.0))
	draw_circle(Vector2( 14, -10), 6.0, Color(1.0, 0.85, 0.0))
	draw_circle(Vector2(-14, -10), 2.5, Color.BLACK)
	draw_circle(Vector2( 14, -10), 2.5, Color.BLACK)
