extends Node2D
## 스테이지 디렉터. 웨이브 → 보스 → 클리어 루프.

const ScrollBGScript := preload("res://scripts/ScrollBG.gd")
const PlayerScript   := preload("res://scripts/Player.gd")
const EnemyScript    := preload("res://scripts/Enemy.gd")
const BossScript     := preload("res://scripts/Boss.gd")
const HudScript      := preload("res://scripts/Hud.gd")

enum State { PLAY, BOSS, CLEAR, GAMEOVER }

# 웨이브 정의: [대기시간, 패턴(0=DIVE 1=ZIGZAG 2=SHOOTER, -1=보스), 수, HP, 점수]
const WAVES: Array = [
	[2.0,  0, 4,  30,  100],
	[4.5,  1, 3,  40,  150],
	[4.0,  0, 5,  30,  100],
	[5.0,  2, 2,  70,  250],
	[5.0,  1, 5,  40,  150],
	[4.5,  0, 6,  30,  100],
	[6.0,  2, 3,  90,  350],
	[5.0,  1, 4,  50,  200],
	[8.0, -1, 0,   0,    0],   # 보스 등장
]

var _state    := State.PLAY
var _score    := 0
var _wave_idx := 0
var _wave_t   := 0.0

var _player: Node2D      = null
var _hud:    CanvasLayer = null


func _ready() -> void:
	add_child(ScrollBGScript.new())

	_player = PlayerScript.new()
	add_child(_player)
	_player.died.connect(_on_player_died)
	_player.lives_changed.connect(func(v: int): _hud.update_lives(v))
	_player.bombs_changed.connect(func(v: int): _hud.update_bombs(v))

	_hud = HudScript.new()
	add_child(_hud)

	_wave_t = WAVES[0][0]


func _process(delta: float) -> void:
	if _state != State.PLAY:
		return
	_wave_t -= delta
	if _wave_t > 0.0 or _wave_idx >= WAVES.size():
		return

	var w: Array = WAVES[_wave_idx]
	_wave_idx += 1
	if _wave_idx < WAVES.size():
		_wave_t = WAVES[_wave_idx][0]

	var pat: int = int(w[1])
	if pat == -1:
		_spawn_boss()
	else:
		_spawn_wave(pat, int(w[2]), int(w[3]), int(w[4]))


func _spawn_wave(pat: int, count: int, hp_val: int, score_each: int) -> void:
	var step := 480.0 / float(count + 1)
	for i in count:
		var e: Area2D = EnemyScript.new()
		add_child(e)
		e.position = Vector2(step * (i + 1), -35.0)
		e.setup(pat, hp_val, score_each, _player)
		e.died.connect(func(val: int): _add_score(val))


func _spawn_boss() -> void:
	_state = State.BOSS
	var boss: Area2D = BossScript.new()
	add_child(boss)
	boss.setup(_player)
	boss.hp_changed.connect(_hud.update_boss_hp)
	boss.died.connect(_on_boss_died)
	_hud.show_boss_bar()


func _on_boss_died() -> void:
	_state = State.CLEAR
	_hud.hide_boss_bar()
	_add_score(8000)
	_hud.show_message("STAGE CLEAR!")
	await get_tree().create_timer(3.0).timeout
	get_tree().reload_current_scene()


func _on_player_died() -> void:
	_state = State.GAMEOVER
	_hud.show_message("GAME OVER")
	await get_tree().create_timer(2.5).timeout
	get_tree().reload_current_scene()


func _add_score(val: int) -> void:
	_score += val
	_hud.update_score(_score)
