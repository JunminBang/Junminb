extends Area2D
## 플레이어/적 공용 탄환
## setup() 호출 후 부모에 add_child

const W := 480.0
const H := 640.0

var vel    := Vector2.ZERO
var damage := 10
var _hit   := false   # 중복 적중 방지


func _ready() -> void:
	var col := CollisionShape2D.new()
	var sh  := CircleShape2D.new()
	sh.radius = 5.0
	col.shape = sh
	add_child(col)
	area_entered.connect(_on_hit_area)
	body_entered.connect(_on_hit_body)


func setup(dir: Vector2, speed: float, dmg: int, friendly: bool) -> void:
	vel    = dir.normalized() * speed
	damage = dmg
	if friendly:
		collision_layer = 4
		collision_mask  = 8   # 적 레이어
	else:
		collision_layer = 16
		collision_mask  = 2   # 플레이어 레이어
		add_to_group("enemy_bullet")


func _process(delta: float) -> void:
	position += vel * delta
	if position.y < -30 or position.y > H + 30 or position.x < -30 or position.x > W + 30:
		queue_free()
	queue_redraw()


func _draw() -> void:
	var col := Color(1.0, 0.95, 0.2) if collision_layer == 4 else Color(1.0, 0.15, 0.15)
	draw_circle(Vector2.ZERO, 5.0, col)
	draw_circle(Vector2.ZERO, 2.5, Color.WHITE)


func _on_hit_area(area: Area2D) -> void:
	if _hit:
		return
	if area.has_method("take_hit"):
		_hit = true
		area.take_hit(damage)
		queue_free()


func _on_hit_body(body: Node2D) -> void:
	if _hit:
		return
	if body.has_method("take_hit"):
		_hit = true
		body.take_hit(damage)
		queue_free()
