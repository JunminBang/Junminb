extends CharacterBody2D
## 플레이어 기체
##   WASD / 방향키 — 이동
##   Z               — 봄버 (전체 적탄 소거 + 광역 데미지)

const BulletScript := preload("res://scripts/Bullet.gd")

const W        := 480.0
const H        := 640.0
const SPEED    := 260.0
const FIRE_T   := 0.10   # 연사 간격
const BOMB_MAX := 3

signal died
signal lives_changed(v: int)
signal bombs_changed(v: int)

var lives := 3
var bombs := BOMB_MAX
var dead  := false

var _fire_t := 0.0
var _inv_t  := 0.0   # 무적 시간


func _ready() -> void:
	collision_layer = 2
	collision_mask  = 16   # 적 탄환
	var col := CollisionShape2D.new()
	var sh  := CircleShape2D.new()
	sh.radius = 7.0
	col.shape = sh
	add_child(col)
	position = Vector2(W * 0.5, H * 0.80)


func _draw() -> void:
	if _inv_t > 0.0 and fmod(_inv_t, 0.12) > 0.06:
		return
	draw_colored_polygon(PackedVector2Array([
		Vector2(0, -18), Vector2(-14, 8), Vector2(0, 2), Vector2(14, 8)
	]), Color(0.25, 0.65, 1.0))
	draw_colored_polygon(PackedVector2Array([
		Vector2(-14, 8), Vector2(-22, 14), Vector2(-10, 10)
	]), Color(0.15, 0.45, 0.85))
	draw_colored_polygon(PackedVector2Array([
		Vector2(14, 8), Vector2(22, 14), Vector2(10, 10)
	]), Color(0.15, 0.45, 0.85))
	draw_circle(Vector2(0, -10), 5.0, Color(0.8, 0.95, 1.0))


func _physics_process(delta: float) -> void:
	if dead:
		return
	_inv_t = maxf(0.0, _inv_t - delta)
	if _inv_t > 0.0:
		queue_redraw()

	var dir := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_LEFT)  or Input.is_physical_key_pressed(KEY_A): dir.x -= 1
	if Input.is_physical_key_pressed(KEY_RIGHT) or Input.is_physical_key_pressed(KEY_D): dir.x += 1
	if Input.is_physical_key_pressed(KEY_UP)    or Input.is_physical_key_pressed(KEY_W): dir.y -= 1
	if Input.is_physical_key_pressed(KEY_DOWN)  or Input.is_physical_key_pressed(KEY_S): dir.y += 1
	if dir.length() > 0:
		dir = dir.normalized()
	velocity = dir * SPEED
	move_and_slide()
	position.x = clampf(position.x, 12, W - 12)
	position.y = clampf(position.y, 12, H - 12)

	_fire_t -= delta
	if _fire_t <= 0.0:
		_fire_t = FIRE_T
		_fire()


func _input(event: InputEvent) -> void:
	if dead:
		return
	if event is InputEventKey:
		var ke := event as InputEventKey
		if ke.pressed and not ke.echo and ke.physical_keycode == KEY_Z:
			_bomb()


func _fire() -> void:
	var parent := get_parent()
	for ox in [-10, 0, 10]:
		var b: Area2D = BulletScript.new()
		parent.add_child(b)
		b.global_position = global_position + Vector2(ox, -18)
		b.setup(Vector2.UP, 620.0, 12, true)


func _bomb() -> void:
	if bombs <= 0 or dead:
		return
	bombs -= 1
	bombs_changed.emit(bombs)
	# 적탄 전체 소거
	for node in get_tree().get_nodes_in_group("enemy_bullet"):
		node.queue_free()
	# 적 전체 피해
	for node in get_tree().get_nodes_in_group("enemy"):
		if node.has_method("take_hit"):
			node.take_hit(500)
	_inv_t = 1.8
	queue_redraw()


func take_hit(dmg: int) -> void:
	if _inv_t > 0.0 or dead:
		return
	lives -= 1
	lives_changed.emit(lives)
	_inv_t = 2.2
	queue_redraw()
	if lives <= 0:
		dead = true
		died.emit()
