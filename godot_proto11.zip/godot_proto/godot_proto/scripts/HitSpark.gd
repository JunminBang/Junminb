extends Node2D
## 피격 순간 이펙트: 확장하는 링 + 방사형 파편선. 짧게 터지고 스스로 사라진다.
## 컬트 오브 더 램식 "즉각 반응"을 최소 비용으로 강조하기 위한 용도. 별도 에셋 없이 _draw.

var _color: Color = Color(1, 1, 1)
var _size: float = 26.0
var _life: float = 0.15
var _t: float = 0.0
var _rays: Array[float] = []


func setup(color: Color = Color(1, 1, 1), size: float = 26.0) -> void:
	_color = color
	_size = size


func _ready() -> void:
	for i in range(randi_range(4, 6)):
		_rays.append(randf() * TAU)


func _process(delta: float) -> void:
	_t += delta
	if _t >= _life:
		queue_free()
		return
	queue_redraw()


func _draw() -> void:
	var k: float = clampf(_t / _life, 0.0, 1.0)
	var col: Color = _color
	col.a = 1.0 - k
	var r: float = _size * (0.3 + k)
	draw_arc(Vector2.ZERO, r, 0.0, TAU, 20, col, 2.0, true)
	for ang in _rays:
		var d: Vector2 = Vector2(cos(ang), sin(ang))
		draw_line(d * r * 0.5, d * (r + _size * 0.5), col, 2.0)
