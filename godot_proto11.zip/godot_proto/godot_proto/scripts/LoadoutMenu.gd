extends CanvasLayer
## 무공소 — 4개 콤보 체인(L/R/E/U)의 슬롯에 무공을 배치. Research 로 해금된 무공만 후보.
## 슬롯 버튼을 누르면 다음 후보 무공으로 순환.

const Moves := preload("res://scripts/Moves.gd")

var _grace := 0.0
var _overlay: ColorRect
var _list: VBoxContainer


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _process(delta: float) -> void:
	if _grace > 0.0:
		_grace = maxf(0.0, _grace - delta)


func _build() -> void:
	_overlay = ColorRect.new()
	_overlay.color = Color(0, 0, 0, 0.94)
	_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_overlay)

	var box := VBoxContainer.new()
	box.anchor_left = 0.5
	box.anchor_top = 0.5
	box.anchor_right = 0.5
	box.anchor_bottom = 0.5
	box.offset_left = -430.0
	box.offset_right = 430.0
	box.offset_top = -230.0
	box.offset_bottom = 230.0
	box.add_theme_constant_override("separation", 8)
	_overlay.add_child(box)

	var title := Label.new()
	title.text = "무공소"
	title.add_theme_font_size_override("font_size", 48)
	title.add_theme_color_override("font_color", Color(0.9, 0.68, 0.4))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)

	var sub := Label.new()
	sub.text = "슬롯을 눌러 무공 교체 (연구로 후보 확장).  (F / Esc 로 닫기)"
	sub.add_theme_color_override("font_color", Color(0.6, 0.6, 0.62))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(sub)

	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 12)
	box.add_child(gap)

	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 6)
	box.add_child(_list)

	var gap2 := Control.new()
	gap2.custom_minimum_size = Vector2(0, 12)
	box.add_child(gap2)

	var close := Button.new()
	close.text = "닫기   [F]"
	close.pressed.connect(_close)
	box.add_child(close)


func open_menu() -> void:
	if visible:
		return
	_refresh()
	visible = true
	_grace = 0.35
	get_tree().paused = true


func _close() -> void:
	visible = false
	get_tree().paused = false


func _refresh() -> void:
	for c in _list.get_children():
		c.queue_free()
	var chains := Loadout.get_chains()
	for ch in Loadout.CHAIN_ORDER:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		var lbl := Label.new()
		lbl.text = Loadout.CHAIN_NAME[ch]
		lbl.custom_minimum_size = Vector2(150, 0)
		row.add_child(lbl)
		for i in range(int(Loadout.SLOTS[ch])):
			var b := Button.new()
			b.custom_minimum_size = Vector2(160, 0)
			b.text = "%d. %s" % [i + 1, Moves.name_of(chains[ch][i])]
			b.disabled = Loadout.pool_for(ch).size() < 2
			b.pressed.connect(_cycle.bind(ch, i))
			row.add_child(b)
		_list.add_child(row)


func _cycle(ch: String, i: int) -> void:
	var pool: Array = Loadout.pool_for(ch)
	if pool.size() < 2:
		return
	var cur: String = Loadout.get_chains()[ch][i]
	var idx: int = pool.find(cur)
	Loadout.set_slot(ch, i, pool[(idx + 1) % pool.size()])
	Sfx.play("soul")
	_refresh()


func _unhandled_input(e: InputEvent) -> void:
	if _grace > 0.0 or not visible:
		return
	if e is InputEventKey and e.pressed and not e.echo and (e.keycode == KEY_F or e.keycode == KEY_ESCAPE):
		_close()
