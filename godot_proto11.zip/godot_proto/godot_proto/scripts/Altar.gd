extends CanvasLayer
## 영혼 제단 = 강화 화면. Tab / Esc 로 아무 때나 열고 닫는다 (게임 일시정지).
## 3개의 랜덤 강화 중 골라 구매(비용 = Meta.cost, 레벨마다 증가). 리롤은 영혼 소비
## (열 때마다 비용 초기화, 리롤할수록 6 → 10 → 14 …). 구매한 슬롯은 다른 랜덤으로 교체.

const REROLL_BASE := 6
const REROLL_STEP := 4

var _rerolls := 0
var _grace := 0.0   # 뜬 직후 잠깐 입력 무시 (연타로 즉시 닫힘 방지)

var _overlay: ColorRect
var _souls: Label
var _list: VBoxContainer
var _reroll_btn: Button


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _process(delta: float) -> void:
	if _grace > 0.0:
		_grace = maxf(0.0, _grace - delta)


func _build() -> void:
	_overlay = ColorRect.new()
	_overlay.color = Color(0, 0, 0, 0.93)
	_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_overlay)

	var box := VBoxContainer.new()
	box.anchor_left = 0.5
	box.anchor_top = 0.5
	box.anchor_right = 0.5
	box.anchor_bottom = 0.5
	box.offset_left = -300.0
	box.offset_right = 300.0
	box.offset_top = -200.0
	box.offset_bottom = 200.0
	box.add_theme_constant_override("separation", 10)
	_overlay.add_child(box)

	var title := Label.new()
	title.text = "영혼 제단"
	title.add_theme_font_size_override("font_size", 52)
	title.add_theme_color_override("font_color", Color(0.85, 0.8, 0.55))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)

	var sub := Label.new()
	sub.text = "강화 하나를 고르거나 리롤.  (Tab / Esc 로 닫기)"
	sub.add_theme_color_override("font_color", Color(0.6, 0.6, 0.62))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(sub)

	_souls = Label.new()
	_souls.add_theme_color_override("font_color", Color(0.92, 0.85, 0.5))
	_souls.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_souls)

	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 12)
	box.add_child(gap)

	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 4)
	box.add_child(_list)

	_reroll_btn = Button.new()
	_reroll_btn.pressed.connect(_do_reroll)
	box.add_child(_reroll_btn)

	var gap2 := Control.new()
	gap2.custom_minimum_size = Vector2(0, 8)
	box.add_child(gap2)

	var close := Button.new()
	close.text = "닫기   [Tab]"
	close.pressed.connect(_close_shop)
	box.add_child(close)


func open_shop() -> void:
	if visible:
		return
	if Meta.offer.is_empty():
		Meta.roll_offer()
	_rerolls = 0
	_refresh()
	visible = true
	_grace = 0.4
	get_tree().paused = true


func _close_shop() -> void:
	visible = false
	get_tree().paused = false


func _reroll_cost() -> int:
	return REROLL_BASE + _rerolls * REROLL_STEP


func _refresh() -> void:
	_souls.text = "보유 영혼   %d" % Meta.souls

	for c in _list.get_children():
		c.queue_free()

	if Meta.offer.is_empty():
		var done := Label.new()
		done.text = "모든 강화를 최대치로 올렸다."
		done.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_list.add_child(done)
	else:
		for id in Meta.offer:
			var u: Dictionary = Meta.UPGRADES[id]
			var lv: int = Meta.level(id)
			var b := Button.new()
			if int(u["max"]) == 1:
				b.text = "★ %s    [%d 영혼]    %s" % [u["name"], Meta.cost(id), u["unit"]]
			else:
				b.text = "%s  Lv.%d→%d    [%d 영혼]    %s" % [u["name"], lv, lv + 1, Meta.cost(id), u["unit"]]
			b.disabled = not Meta.can_buy(id)
			b.pressed.connect(_buy.bind(id))
			_list.add_child(b)

	var rc := _reroll_cost()
	_reroll_btn.text = "리롤   [%d 영혼]" % rc
	_reroll_btn.disabled = Meta.souls < rc or Meta.offer.size() < 2


func _buy(id: String) -> void:
	if Meta.buy(id):
		Sfx.play("soul")
		Meta.consume_offer(id)
		_refresh()


func _do_reroll() -> void:
	var rc := _reroll_cost()
	if Meta.offer.size() < 2 or not Meta.spend(rc):
		return
	_rerolls += 1
	Meta.roll_offer()
	Sfx.play("whoosh")
	_refresh()


func _unhandled_input(e: InputEvent) -> void:
	if _grace > 0.0:
		return
	if not (e is InputEventKey and e.pressed and not e.echo):
		return
	if visible:
		if e.keycode == KEY_TAB or e.keycode == KEY_ESCAPE:
			_close_shop()
	elif e.keycode == KEY_TAB:
		open_shop()
