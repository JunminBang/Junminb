extends Node2D
## 젤리 스쿼시-스트레치 (컬트 오브 더 램식 과장 디폼).
## 부모 CharacterBody2D 의 속도를 읽어 진행 방향으로 늘어나고 직교 방향으로 눌린다.
## 걸을 때 통통 튀고, poke()/poke_dir() 로 피격·대시·착지 같은 순간 변형을 준다.
## 스프링 감쇠라 목표를 지나쳤다가 "띠용" 하고 되돌아온다.
##
## 이 노드에 스프라이트(ColorRect 등)를 자식으로 두고, 이 노드의 scale/rotation 만 건드린다.
## 콜리전/체력바는 이 노드 밖(본체 직속)에 둬서 안 흔들리게 한다.

@export var body_path: NodePath = ^".."
@export var stiffness := 190.0        # 스프링 강성 (클수록 빨리 제자리)
@export var damping := 12.0           # 감쇠 (작을수록 더 오래 출렁)
@export var speed_stretch := 0.0011   # 속도 1당 늘어나는 양
@export var max_stretch := 0.45
@export var walk_bounce := 0.16       # 걸을 때 통통 튀는 세기
@export var walk_freq := 13.0         # 기본 걸음 주기 (속도에 비례해 빨라짐)
@export var tilt := 0.10              # 진행 방향으로 기우는 각(rad)
@export var breathe := 0.02           # 정지 시 숨쉬는 미세 변형

var _body: Node2D
var _scale: Vector2 = Vector2.ONE
var _sv: Vector2 = Vector2.ZERO        # 스케일 속도 (스프링 상태)
var _phase := 0.0
var _extra: Vector2 = Vector2.ZERO     # poke 여파 (스스로 0으로 감쇠)
var _dirx := 0.0
var _time := 0.0


func _ready() -> void:
	_body = get_node_or_null(body_path)


func _process(delta: float) -> void:
	_time += delta
	var vel: Vector2 = Vector2.ZERO
	if is_instance_valid(_body) and "velocity" in _body:
		vel = _body.velocity   # StaticBody2D 등 velocity 없는 부모면 정지로 취급
	var spd := vel.length()

	var target := Vector2.ONE

	# 이동: 진행 방향축으로 +, 직교축으로 - (부피 보존 느낌)
	if spd > 5.0:
		var s: float = clampf(spd * speed_stretch, 0.0, max_stretch)
		var d := vel / spd
		target.x += (absf(d.x) - absf(d.y)) * s
		target.y += (absf(d.y) - absf(d.x)) * s
		_dirx = lerpf(_dirx, d.x, 0.2)
	else:
		_dirx = lerpf(_dirx, 0.0, 0.2)

	# 걷기 바운스 (세로로 통통)
	if spd > 20.0:
		_phase += delta * (walk_freq + spd * 0.03)
		var b := sin(_phase) * walk_bounce
		target.y += b
		target.x -= b * 0.7
	else:
		_phase = lerpf(_phase, 0.0, 0.1)
		target.y += sin(_time * 2.2) * breathe   # 숨쉬기

	# poke 여파
	target += _extra
	_extra = _extra.move_toward(Vector2.ZERO, delta * 5.0)

	# 스프링 적분
	var accel := (target - _scale) * stiffness - _sv * damping
	_sv += accel * delta
	_scale += _sv * delta
	_scale = _scale.clamp(Vector2(0.4, 0.4), Vector2(2.0, 2.0))

	scale = _scale
	rotation = -_dirx * tilt + sin(_phase) * 0.025


## 즉시 스케일 킥 + 잠깐 목표를 밀어줌. (stretch_x, stretch_y = 각 축 변형량, 음수면 눌림)
func poke(stretch_x: float, stretch_y: float) -> void:
	_sv += Vector2(stretch_x, stretch_y) * 16.0
	_extra += Vector2(stretch_x, stretch_y) * 0.5


## 방향 dir 로 늘리고 직교로 누른다. (대시/돌진/넉백에 사용)
func poke_dir(dir: Vector2, amount: float) -> void:
	if dir.length() < 0.01:
		poke(0.0, amount)
		return
	var d := dir.normalized()
	poke((absf(d.x) - absf(d.y)) * amount, (absf(d.y) - absf(d.x)) * amount)
