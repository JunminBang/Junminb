extends StaticBody2D
## 채집 자원 노드 — AI 없는 파괴 가능 오브젝트. 공격으로 부수면 자원(Pickup) 드랍.
## 플레이어 _resolve_hit 이 "harvestable" 그룹도 타격 대상에 포함한다. 방 클리어 판정엔 무관.

const Pickup := preload("res://scripts/Pickup.gd")
const HitSpark := preload("res://scripts/HitSpark.gd")

@export var kind := "wood"          # wood / stone / herb / ore
var max_health := 18
var yield_amount := 6
var health := 0

@onready var sprite: ColorRect = $Vis/Sprite
@onready var jelly: Node2D = $Vis
@onready var hpbar: ProgressBar = $HpBar
@onready var col_shape: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	add_to_group("harvestable")
	_apply_kind()
	health = max_health
	hpbar.max_value = max_health
	hpbar.value = health


func _apply_kind() -> void:
	var r := 15.0
	match kind:
		"herb":
			max_health = 10; yield_amount = 4; r = 12.0
		"stone":
			max_health = 32; yield_amount = 7; r = 19.0
		"ore":
			max_health = 42; yield_amount = 5; r = 18.0
		_:  # wood
			max_health = 18; yield_amount = 6; r = 15.0
	var c: Color = Inventory.KINDS.get(kind, {}).get("color", Color(0.6, 0.6, 0.6))
	sprite.color = c.darkened(0.12)
	sprite.offset_left = -r
	sprite.offset_top = -r
	sprite.offset_right = r
	sprite.offset_bottom = r
	var shape := CircleShape2D.new()
	shape.radius = r * 0.7
	col_shape.shape = shape
	hpbar.offset_left = -r - 3
	hpbar.offset_right = r + 3
	hpbar.offset_top = -r - 14
	hpbar.offset_bottom = -r - 8


func take_hit(damage: int, _dir: Vector2, _knockback: float) -> void:
	health -= damage
	hpbar.value = health
	jelly.poke(-0.3, 0.35)
	_flash()
	Sfx.play("hit_light")
	if health <= 0:
		var s := HitSpark.new()
		get_parent().add_child(s)
		s.global_position = global_position
		s.setup(sprite.color.lightened(0.3), 30.0)
		Pickup.drop(get_parent(), global_position, kind, yield_amount)
		queue_free()


func _flash() -> void:
	var base: Color = sprite.color
	sprite.color = Color(1, 1, 1)
	create_tween().tween_property(sprite, "color", base, 0.12)
