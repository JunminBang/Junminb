extends CanvasLayer
## 거점 NPC 한 줄 대사 오버레이. F / 클릭 / ESC 로 닫는다.
## 여러 줄 대화 흐름은 생략 — 상호작용 1회 = 대사 1줄 (Lore.next_line).

var _grace := 0.0
var _panel: PanelContainer
var _name: Label
var _line: Label


func _ready() -> void:
	layer = 95
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _process(delta: float) -> void:
	if _grace > 0.0:
		_grace = maxf(0.0, _grace - delta)


func _build() -> void:
	var overlay := ColorRect.new()
	overlay.color = Color(0, 0, 0, 0.55)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.gui_input.connect(func(e):
		if e is InputEventMouseButton and e.pressed:
			_close())
	add_child(overlay)

	_panel = PanelContainer.new()
	_panel.anchor_left = 0.5
	_panel.anchor_right = 0.5
	_panel.anchor_top = 1.0
	_panel.anchor_bottom = 1.0
	_panel.offset_left = -380.0
	_panel.offset_right = 380.0
	_panel.offset_top = -190.0
	_panel.offset_bottom = -60.0
	overlay.add_child(_panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	_panel.add_child(vb)

	_name = Label.new()
	_name.add_theme_font_size_override("font_size", 24)
	vb.add_child(_name)

	_line = Label.new()
	_line.add_theme_font_size_override("font_size", 20)
	_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_line.custom_minimum_size = Vector2(720, 0)
	vb.add_child(_line)

	var hint := Label.new()
	hint.text = "[F] 닫기"
	hint.add_theme_color_override("font_color", Color(0.6, 0.6, 0.62))
	vb.add_child(hint)


func show_line(npc_name: String, line: String, tint: Color) -> void:
	_name.text = npc_name
	_name.add_theme_color_override("font_color", tint)
	_line.text = line
	visible = true
	_grace = 0.3
	get_tree().paused = true


func _close() -> void:
	if not visible:
		return
	visible = false
	get_tree().paused = false


func _unhandled_input(e: InputEvent) -> void:
	if _grace > 0.0 or not visible:
		return
	if e is InputEventKey and e.pressed and not e.echo and (e.keycode == KEY_F or e.keycode == KEY_ESCAPE):
		_close()
