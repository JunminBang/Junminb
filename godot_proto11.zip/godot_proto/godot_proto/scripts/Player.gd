extends CharacterBody2D
## 플레이어 전투 컨트롤러 — WASD 이동 + 마우스 조준 + 4버튼 콤보 체인.
##
## 조작:
##   WASD          - 이동
##   마우스        - 조준 (공격은 커서 방향으로 나감)
##   Shift         - 대시 (짧은 무적)
##   좌클릭 (L)    - 경공격 스트링 (연타 시 l1→l2→l3)
##   우클릭 (R)    - 강공격 스트링 (r1→r2)
##   E     (E)     - 기동기 (쿨다운, 무적)
##   R키   (U)     - 필살 (게이지 100%)
##
## 콤보: 같은 버튼 연타로 그 체인을 진행. 다른 버튼을 후딜 중(cancel_at 이후) 입력하면
##       그 체인으로 크로스 캔슬. 0.7초간 입력 없으면 모든 체인 리셋.
## 무공 구성은 Loadout 오토로드에서 (거점 무공소). 무적 프레임으로 패턴 회피.

const Moves := preload("res://scripts/Moves.gd")
const SlashEffect := preload("res://scripts/SlashEffect.gd")
const HitSpark := preload("res://scripts/HitSpark.gd")

# --- 인스펙터 튜닝 ---
@export var move_speed := 300.0
@export var dash_speed := 660.0
@export var dash_time := 0.14
@export var dash_cooldown := 0.4
@export var dash_cancel_window := 0.22   # 대시 종료 후 이 시간 안에 입력 시 후딜 스킵
@export var max_hp := 100
@export var hurt_time := 0.35

const CHAIN_RESET := 0.7
const INPUT_BUFFER := 0.22
const ARRIVE_DIST := 6.0
const GAUGE_MAX := 100.0
const GAUGE_PER_HIT := 6.0
const GAUGE_PER_DMG := 0.9

signal died

enum State { IDLE, DASH, ACT, RECOVER }

var state: State = State.IDLE
var facing: Vector2 = Vector2.RIGHT
var _last_move_dir: Vector2 = Vector2.RIGHT   # 마지막 이동 입력 방향 (대시에 사용)
var dead := false

# 메타/연구 반영
var _damage_mult := 1.0
var _lifesteal := 0.0
var _armor := 0
var _recover_mult := 1.0
var _gauge_cap := 100.0
var _gauge_gain := 1.0
var _dash_slash := false
var _combo_blast := false
var _berserk := false
var _awakened: Array = []   # 각성한 태그 (offense/defense/mobility/sustain)
var _base_color := Color(0.25, 0.6, 1.0)   # 스프라이트 기본색 (각성 시 변함, _flash 가 복귀 대상으로 씀)

# 봇/스크립트용 이동 오버라이드 (사람은 WASD)
var move_target: Vector2 = Vector2.ZERO
var has_move_target := false

# 콤보 체인 상태
var chains := {}                                  # {"L":["l1",...], ...}  Loadout 에서
var chain_ptr := {"L": 0, "R": 0, "E": 0, "U": 0}
var chain_reset_timer := 0.0
var _active_chain := ""

var dash_cd_timer := 0.0
var cancel_timer := 0.0
var e_cd_timer := 0.0        # E 체인 쿨다운
var act_timer := 0.0
var _recover_total := 0.0
var invulnerable := false

var hp: int
var hurt_timer := 0.0
var knockback_vel: Vector2 = Vector2.ZERO
var ultimate_gauge := 0.0

var current: Dictionary = {}
var _current_is_last := false   # 지금 무공이 체인의 마지막 칸인가 (combo_blast 용)

var _buffered := ""
var _buffer_timer := 0.0
var _script_aim_cool := 0.0   # 봇이 aim_at 쓰면 잠깐 커서추적 억제

# 하위호환 (테스트/HUD 가 참조)
var cooldowns := {"E": 0.0}

@onready var sprite: ColorRect = $Vis/Sprite
@onready var jelly: Node2D = $Vis


func _ready() -> void:
	add_to_group("player")
	chains = Loadout.get_chains()
	_apply_meta()
	hp = max_hp
	_ensure_actions()


func _apply_meta() -> void:
	max_hp += int(Meta.bonus("max_hp")) + int(Research.passive("max_hp"))
	_armor = int(Meta.bonus("armor")) + int(Research.passive("armor"))
	_damage_mult = 1.0 + Meta.bonus("damage") + Research.passive("damage")
	_lifesteal = Meta.bonus("lifesteal")
	_recover_mult = maxf(0.55, 1.0 - Meta.bonus("haste"))       # 속공 = 후딜 감소
	dash_cooldown = maxf(0.14, dash_cooldown - Meta.bonus("swift"))
	dash_time += Meta.bonus("iframe")
	hurt_time += Meta.bonus("vigor")
	_dash_slash = Meta.has("dash_slash")
	_combo_blast = Meta.has("combo_blast")
	_berserk = Meta.has("berserk")
	_gauge_cap = 200.0 if Meta.has("ult_double") else 100.0
	_gauge_gain = 1.5 if Meta.has("ult_double") else 1.0

	# 각성 — 같은 성향에 4레벨 이상 투자 시 추가 효과 + 시각 변화
	_awakened = Meta.awakened_tags()
	if "offense" in _awakened:
		_damage_mult += 0.25
	if "defense" in _awakened:
		_armor += 2
		max_hp += 15
	if "mobility" in _awakened:
		dash_cooldown = maxf(0.12, dash_cooldown * 0.7)
		dash_time += 0.03
	if "sustain" in _awakened:
		_lifesteal += 0.05

	# 계약 — 런 시작 시 고른 불리한 조건
	_damage_mult = maxf(0.1, _damage_mult + Meta.cmod("player_damage"))
	max_hp = maxi(10, int(round(max_hp * (1.0 + Meta.cmod("hp_mult")))))

	_tint_for_awakening()


func _tint_for_awakening() -> void:
	# 각성 성향에 따라 스프라이트 색을 바꿔 "빌드가 완성됐다"를 눈으로 보여준다
	if _awakened.is_empty():
		return
	var t := {"offense": Color(1.0, 0.55, 0.4), "defense": Color(0.5, 0.75, 1.0),
		"mobility": Color(0.6, 1.0, 0.75), "sustain": Color(1.0, 0.5, 0.75)}
	var c := Color(0, 0, 0)
	for tag in _awakened:
		c += t.get(tag, Color(0, 0, 0))
	c /= float(_awakened.size())
	_base_color = c
	sprite.color = c


func _berserk_on() -> bool:
	return _berserk and hp < max_hp * 0.4


# --- 입력 액션 등록 ---
func _ensure_actions() -> void:
	_bind(&"move_up", _kb(KEY_W))
	_bind(&"move_down", _kb(KEY_S))
	_bind(&"move_left", _kb(KEY_A))
	_bind(&"move_right", _kb(KEY_D))
	_bind(&"chain_l", _mb(MOUSE_BUTTON_LEFT))
	_bind(&"chain_r", _mb(MOUSE_BUTTON_RIGHT))
	_bind(&"chain_e", _kb(KEY_E))
	_bind(&"chain_u", _kb(KEY_R))
	_bind(&"dash", _kb(KEY_SPACE))
	_bind(&"interact", _kb(KEY_F))


func _bind(action: StringName, ev: InputEvent) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	else:
		InputMap.action_erase_events(action)
	InputMap.action_add_event(action, ev)


func _kb(k: Key) -> InputEventKey:
	var e := InputEventKey.new()
	e.physical_keycode = k
	return e


func _mb(b: MouseButton) -> InputEventMouseButton:
	var e := InputEventMouseButton.new()
	e.button_index = b
	return e


func _input(event: InputEvent) -> void:
	if dead:
		return
	if event.is_action_pressed(&"chain_l"):
		_buffer("L")
	elif event.is_action_pressed(&"chain_r"):
		_buffer("R")
	elif event.is_action_pressed(&"chain_e"):
		_buffer("E")
	elif event.is_action_pressed(&"chain_u"):
		_buffer("U")
	elif event.is_action_pressed(&"dash"):
		_buffer("DASH")


func _buffer(a: String) -> void:
	_buffered = a
	_buffer_timer = INPUT_BUFFER


## 봇/스크립트: 커서 대신 목표를 조준
func aim_at(pos: Vector2) -> void:
	var d := pos - global_position
	if d.length() > 1.0:
		facing = d.normalized()
	_script_aim_cool = 0.3


func _physics_process(delta: float) -> void:
	if dead:
		velocity = Vector2.ZERO
		return

	dash_cd_timer = maxf(0.0, dash_cd_timer - delta)
	e_cd_timer = maxf(0.0, e_cd_timer - delta)
	cooldowns["E"] = e_cd_timer
	cancel_timer = maxf(0.0, cancel_timer - delta)
	chain_reset_timer = maxf(0.0, chain_reset_timer - delta)
	_buffer_timer = maxf(0.0, _buffer_timer - delta)
	hurt_timer = maxf(0.0, hurt_timer - delta)
	_script_aim_cool = maxf(0.0, _script_aim_cool - delta)
	if _buffer_timer <= 0.0:
		_buffered = ""
	if chain_reset_timer <= 0.0:
		_reset_chains()

	knockback_vel = knockback_vel.move_toward(Vector2.ZERO, 1400.0 * delta)

	# 피격 경직
	if hurt_timer > 0.0:
		velocity = knockback_vel
		move_and_slide()
		return

	# 조준 — 시전/대시 중이 아니고, 봇이 조준/이동을 몰지 않을 때만 커서 추적
	if state != State.ACT and state != State.DASH and not has_move_target and _script_aim_cool <= 0.0:
		var to_mouse := get_global_mouse_position() - global_position
		if to_mouse.length() > 4.0:
			facing = to_mouse.normalized()

	match state:
		State.IDLE:
			_free_move()
			_try_consume_buffer(true)
		State.DASH:
			_do_dash(delta)
		State.ACT:
			_do_act(delta)
		State.RECOVER:
			_do_recover(delta)

	velocity += knockback_vel
	move_and_slide()


func _reset_chains() -> void:
	for k in chain_ptr:
		chain_ptr[k] = 0


func _free_move() -> void:
	var dir: Vector2
	if has_move_target:
		var to := move_target - global_position
		if to.length() <= ARRIVE_DIST:
			has_move_target = false
			dir = Vector2.ZERO
		else:
			dir = to.normalized()
			facing = dir
	else:
		dir = Input.get_vector(&"move_left", &"move_right", &"move_up", &"move_down")
		if dir.length() > 0.1:
			_last_move_dir = dir.normalized()
	velocity = dir * move_speed * (1.25 if _berserk_on() else 1.0)


func _try_consume_buffer(_allow_dash: bool) -> bool:
	if _buffered == "":
		return false
	var a := _buffered

	if a == "DASH":
		if dash_cd_timer <= 0.0:
			_buffered = ""
			_start_dash()
			return true
		return false

	# 콤보 체인 (L / R / E / U)
	if not chains.has(a):
		_buffered = ""
		return false
	if a == "E" and e_cd_timer > 0.0:
		return false
	if a == "U" and ultimate_gauge < GAUGE_MAX:
		return false

	var seq: Array = chains[a]
	if seq.is_empty():
		_buffered = ""
		return false
	var ptr: int = mini(chain_ptr[a], seq.size() - 1)
	var mv := Moves.get_move(seq[ptr])

	_buffered = ""
	if a == "E":
		e_cd_timer = float(mv.get("cooldown", 3.2))
	elif a == "U":
		ultimate_gauge -= GAUGE_MAX

	chain_ptr[a] = ptr + 1
	chain_reset_timer = CHAIN_RESET
	_active_chain = a
	_current_is_last = ptr >= seq.size() - 1
	_start_act(mv)
	return true


func _start_dash() -> void:
	state = State.DASH
	act_timer = dash_time
	dash_cd_timer = dash_cooldown
	invulnerable = true
	has_move_target = false
	collision_mask = 1   # 대시 중 적 레이어(2) 제외 → 통과하며 달라붙지 않음
	# 대시 방향: 현재 이동 입력 > 마지막 이동 방향 > 봇 조준
	var mv := Input.get_vector(&"move_left", &"move_right", &"move_up", &"move_down")
	if mv.length() > 0.1:
		facing = mv.normalized()
	elif not has_move_target:
		facing = _last_move_dir
	jelly.poke_dir(facing, 0.7)
	Sfx.play("dash")


func _do_dash(delta: float) -> void:
	velocity = facing * dash_speed
	act_timer -= delta
	if act_timer <= 0.0:
		collision_mask = 3   # 적 레이어 복원
		invulnerable = false
		cancel_timer = dash_cancel_window
		state = State.IDLE
		if _dash_slash:
			_dash_slash_hit()


func _hit_targets() -> Array:
	return get_tree().get_nodes_in_group("enemy")


func _dash_slash_hit() -> void:
	var col := Color(0.75, 0.88, 1.0)
	var fx := SlashEffect.new()
	add_child(fx)
	fx.setup(facing, 92.0, 0.95, col, 0.16)
	Sfx.play("whoosh")
	var hits := 0
	for e in _hit_targets():
		if not is_instance_valid(e) or not e.has_method("take_hit"):
			continue
		var to_e: Vector2 = e.global_position - global_position
		if to_e.length() > 92.0 or (to_e.length() > 1.0 and absf(facing.angle_to(to_e)) > 0.95):
			continue
		e.take_hit(maxi(1, int(round(15 * _damage_mult))), to_e.normalized(), 220.0)
		_spawn_spark(e.global_position, col)
		hits += 1
	if hits > 0:
		Hitstop.hitstop(0.05, 0.06)
		_shake_camera(4.0)


func _start_act(data: Dictionary) -> void:
	current = data
	# combo_blast: L 체인 마지막 무공을 전방위 폭발로
	if _combo_blast and _active_chain == "L" and _current_is_last:
		current = current.duplicate()
		current["half_angle"] = PI
		current["range"] = maxf(float(current["range"]), 96.0)
		current["knockback"] = float(current["knockback"]) + 80.0
	state = State.ACT
	act_timer = float(data["windup"])
	invulnerable = bool(data.get("iframe", false))
	has_move_target = false
	var to_mouse := get_global_mouse_position() - global_position
	if to_mouse.length() > 1.0 and _script_aim_cool <= 0.0 and not has_move_target:
		facing = to_mouse.normalized()
	jelly.poke_dir(facing, 0.28)


func _do_act(delta: float) -> void:
	var lunge: float = float(current.get("lunge", 0.0))
	if lunge > 0.0:
		velocity = facing * lunge
	else:
		velocity = velocity.move_toward(Vector2.ZERO, move_speed * 5.0 * delta)
	act_timer -= delta
	if act_timer <= 0.0:
		_resolve_hit()
		invulnerable = false
		state = State.RECOVER
		_recover_total = float(current["recover"]) * _recover_mult
		act_timer = _recover_total


func _do_recover(delta: float) -> void:
	velocity = velocity.move_toward(Vector2.ZERO, move_speed * 6.0 * delta)

	if _buffered == "DASH" and dash_cd_timer <= 0.0:
		_buffered = ""
		_start_dash()
		return

	# 크로스 캔슬 / 콤보 진행: cancel_at 지났거나 대시 직후면 다음 입력 소비
	if _buffered != "" and _buffered != "DASH":
		var elapsed := _recover_total - act_timer
		if elapsed >= float(current.get("cancel_at", 0.15)) or cancel_timer > 0.0:
			if _try_consume_buffer(false):
				return

	act_timer -= delta
	if act_timer <= 0.0:
		state = State.IDLE


func _resolve_hit() -> void:
	var rng: float = float(current["range"])
	var half: float = float(current["half_angle"])
	var col: Color = current["color"]
	var mult := _damage_mult * (1.4 if _berserk_on() else 1.0)
	var dmg: int = maxi(1, int(round(float(current["damage"]) * mult)))

	var fx := SlashEffect.new()
	add_child(fx)
	fx.setup(facing, rng, half, col, 0.22 if half >= PI else 0.16)
	Sfx.play("whoosh")

	var origin := global_position
	var hits := 0
	for e in _hit_targets():
		if not is_instance_valid(e) or not e.has_method("take_hit"):
			continue
		var to_e: Vector2 = e.global_position - origin
		var dist := to_e.length()
		if dist > rng:
			continue
		if half < PI and dist > 1.0 and absf(facing.angle_to(to_e)) > half:
			continue
		var kb_dir := to_e.normalized() if dist > 1.0 else facing
		e.take_hit(dmg, kb_dir, float(current["knockback"]))
		_spawn_spark(e.global_position, col)
		ultimate_gauge = minf(_gauge_cap, ultimate_gauge + GAUGE_PER_HIT * _gauge_gain)
		if _lifesteal > 0.0:
			hp = mini(max_hp, hp + maxi(1, int(dmg * _lifesteal)))
		hits += 1

	var slow: bool = bool(current.get("slow", false))
	if hits > 0:
		Hitstop.hitstop(float(current["hitstop"]), 0.10 if slow else 0.06)
		_shake_camera(float(current["shake"]))
		jelly.poke_dir(facing, 0.2)
		if dmg >= 40:
			Sfx.play("hit_crit")
		elif dmg >= 20:
			Sfx.play("hit_heavy")
		else:
			Sfx.play("hit_light")
	elif slow:
		Hitstop.hitstop(float(current["hitstop"]), 0.10)
		_shake_camera(float(current["shake"]))


func take_hit(damage: int, dir: Vector2, knockback: float) -> void:
	if dead or invulnerable or hurt_timer > 0.0:
		return
	var taken := maxi(1, damage - _armor)
	hp -= taken
	ultimate_gauge = minf(_gauge_cap, ultimate_gauge + taken * GAUGE_PER_DMG * _gauge_gain)
	knockback_vel = dir.normalized() * knockback
	hurt_timer = hurt_time
	_buffered = ""
	jelly.poke(-0.32, 0.55)
	Sfx.play("hurt")
	_shake_camera(7.0)
	_flash(Color(1.0, 0.35, 0.35))
	if hp <= 0:
		_down()


func _down() -> void:
	if dead:
		return
	dead = true
	hp = 0
	velocity = Vector2.ZERO
	knockback_vel = Vector2.ZERO
	jelly.poke(0.9, -0.65)
	Sfx.play("death")
	Hitstop.hitstop(0.2, 0.05)
	_shake_camera(20.0)
	_flash(Color(0.9, 0.2, 0.2))
	died.emit()


func _flash(c: Color) -> void:
	sprite.color = c
	var tw := create_tween()
	tw.tween_property(sprite, "color", _base_color, 0.18)


func pop_soul() -> void:
	jelly.poke(0.13, 0.16)


func _spawn_spark(pos: Vector2, col: Color) -> void:
	var s := HitSpark.new()
	get_parent().add_child(s)
	s.global_position = pos
	s.setup(col.lerp(Color.WHITE, 0.5), 28.0)


func _shake_camera(strength: float) -> void:
	Hitstop.shake(strength)
