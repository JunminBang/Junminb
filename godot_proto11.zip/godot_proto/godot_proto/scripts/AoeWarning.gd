extends Node2D
## 예고형 장판. tele 초 동안 빨간 경고를 그린 뒤 폭발하며, 그 순간 범위 안 플레이어를 때린다.
## damage <= 0 이면 경고만 하고 피해는 없다 (돌진 경로 표시 등).
## shape: "circle"(radius) / "donut"(radius,thickness) / "cross"(length,thickness) / "cone"(radius,half_angle,aim)

const HitSpark := preload("res://scripts/HitSpark.gd")
const _Self := preload("res://scripts/AoeWarning.gd")

var shape := "circle"
var radius := 120.0
var thickness := 40.0
var length := 400.0
var half_angle := 0.6
var aim: Vector2 = Vector2.RIGHT
var tele := 0.8
var damage := 18
var knockback := 380.0
var color := Color(1.0, 0.3, 0.25)
var _t := 0.0
var _done := false


## parent 아래 at 위치에 예고 장판을 띄운다. dmg<=0 이면 경고 표시만.
static func spawn(parent: Node, at: Vector2, shape_: String, params: Dictionary, dmg: int, tele_: float) -> Node2D:
	var a: Node2D = _Self.new()
	a.shape = shape_
	a.damage = dmg
	a.tele = tele_
	for k in params:
		a.set(k, params[k])
	parent.add_child(a)
	a.global_position = at
	return a


func _ready() -> void:
	add_to_group("hazard")


func _physics_process(delta: float) -> void:
	_t += delta
	queue_redraw()
	if not _done and _t >= tele:
		_done = true
		_detonate()


func _detonate() -> void:
	if damage > 0:
		Sfx.play("hit_heavy")
		Hitstop.hitstop(0.05, 0.09)
		var p := get_tree().get_first_node_in_group("player")
		if is_instance_valid(p) and p.has_method("take_hit") and _contains(p.global_position):
			var dir: Vector2 = p.global_position - global_position
			p.take_hit(damage, dir if dir.length() > 1.0 else aim, knockback)
		var s := HitSpark.new()
		get_parent().add_child(s)
		s.global_position = global_position
		s.setup(Color(1.0, 0.6, 0.4), radius * 0.5)
	await get_tree().create_timer(0.12).timeout
	queue_free()


func _contains(gp: Vector2) -> bool:
	var v := gp - global_position
	match shape:
		"circle":
			return v.length() <= radius
		"donut":
			return absf(v.length() - radius) <= thickness
		"cone":
			return v.length() <= radius and absf(aim.angle_to(v)) <= half_angle
		"cross":
			var loc := v.rotated(-aim.angle())
			return (absf(loc.y) <= thickness and absf(loc.x) <= length) \
				or (absf(loc.x) <= thickness and absf(loc.y) <= length)
	return false


func _draw() -> void:
	var prog := clampf(_t / tele, 0.0, 1.0)
	var a := 0.12 + 0.4 * prog + (0.45 if _done else 0.0)
	var c := Color(color.r, color.g, color.b, a)
	var fill := Color(color.r, color.g, color.b, a * 0.35)
	match shape:
		"circle":
			draw_circle(Vector2.ZERO, radius, fill)
			draw_arc(Vector2.ZERO, radius, 0.0, TAU, 40, c, 3.0)
		"donut":
			draw_arc(Vector2.ZERO, radius, 0.0, TAU, 48, c, thickness * 2.0)
		"cone":
			var pts := PackedVector2Array([Vector2.ZERO])
			for i in range(17):
				var ang := aim.angle() - half_angle + 2.0 * half_angle * i / 16.0
				pts.append(Vector2(cos(ang), sin(ang)) * radius)
			draw_colored_polygon(pts, fill)
			draw_polyline(pts, c, 2.0)
		"cross":
			_band(aim.angle(), c, fill)
			_band(aim.angle() + PI * 0.5, c, fill)


func _band(rot: float, c: Color, fill: Color) -> void:
	var r := Rect2(-length, -thickness, length * 2.0, thickness * 2.0)
	draw_set_transform(Vector2.ZERO, rot, Vector2.ONE)
	draw_rect(r, fill)
	draw_rect(r, c, false, 2.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
