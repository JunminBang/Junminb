extends Node
## 전역 히트스탑 매니저 (오토로드 싱글톤: Hitstop)
##
## 타격 순간 Engine.time_scale 을 잠깐 낮춰서 "때렸다"는 임팩트를 과장한다.
## 로스트아크의 강타 정지 연출을 경량화한 버전.
##
## 사용법: Hitstop.hitstop(0.05)  # 일반 타격
##        Hitstop.hitstop(0.08, 0.03)  # 강공격/필살기용, 더 느리고 길게

var _active: bool = false
var _shake_tw: Tween

## 현재 활성 카메라를 잠깐 흔든다. (Player / Boss / 장판 등 어디서든 Hitstop.shake(강도))
func shake(strength: float, dur: float = 0.26) -> void:
	var cam := get_viewport().get_camera_2d()
	if cam == null:
		return
	if _shake_tw and _shake_tw.is_valid():
		_shake_tw.kill()
	_shake_tw = cam.create_tween()
	for i in range(6):
		var o := Vector2(randf_range(-strength, strength), randf_range(-strength, strength))
		_shake_tw.tween_property(cam, "offset", o, dur / 7.0)
	_shake_tw.tween_property(cam, "offset", Vector2.ZERO, dur / 7.0)


func hitstop(duration: float = 0.05, time_scale: float = 0.05) -> void:
	# 이미 히트스탑 중이면 더 강한 쪽으로 갱신만 하고 중첩 실행은 막는다.
	if _active:
		return
	_active = true
	Engine.time_scale = time_scale
	# ignore_time_scale=true 로 생성해야 time_scale 을 낮춘 상태에서도
	# 이 타이머 자체는 "실제 시간" 기준으로 정확히 duration 만큼만 기다린다.
	await get_tree().create_timer(duration, true, false, true).timeout
	Engine.time_scale = 1.0
	_active = false
