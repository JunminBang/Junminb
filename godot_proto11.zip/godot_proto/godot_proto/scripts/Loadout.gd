extends Node
## 무공 로드아웃 (오토로드 Loadout). 4개 콤보 체인(L/R/E/U)에 어떤 무공을 넣을지.
##   L = 좌클릭 경공격 (3칸)   R = 우클릭 강공격 (2칸)
##   E = E키 기동기 (1칸, 쿨다운)  U = R키 필살 (1칸, 게이지)
## 슬롯 후보(POOL)는 Research 로 확장. user://mabi_proto_loadout.cfg 저장.

const SAVE_PATH := "user://mabi_proto_loadout.cfg"

const SLOTS := {"L": 3, "R": 2, "E": 1, "U": 1}
const CHAIN_ORDER := ["L", "R", "E", "U"]
const CHAIN_NAME := {"L": "좌클릭", "R": "우클릭", "E": "E", "U": "R키(필살)"}

const DEFAULT := {"L": ["l1", "l2", "l3"], "R": ["r1", "r2"], "E": ["e1"], "U": ["u1"]}

# 슬롯에 넣을 수 있는 무공 후보. 기본분은 항상, 나머지는 Research.is_move_unlocked 통과 시.
const POOL := {
	"L": ["l1", "l2", "l3", "thrust", "cleave", "bolt", "spin"],
	"R": ["r1", "r2", "cleave", "shockwave", "spin"],
	"E": ["e1", "thrust", "lunge_pierce"],
	"U": ["u1", "shockwave", "spin"],
}
const ALWAYS := ["l1", "l2", "l3", "r1", "r2", "e1", "u1"]

var chains: Dictionary = {}


func _ready() -> void:
	load_loadout()


func get_chains() -> Dictionary:
	return chains.duplicate(true)


## 슬롯에 넣을 수 있는(해금된) 무공 목록
func pool_for(ch: String) -> Array:
	return POOL.get(ch, []).filter(func(m): return ALWAYS.has(m) or Research.is_move_unlocked(m))


func set_slot(ch: String, idx: int, move_id: String) -> void:
	if not chains.has(ch) or idx < 0 or idx >= chains[ch].size():
		return
	if not pool_for(ch).has(move_id):
		return
	chains[ch][idx] = move_id
	save_loadout()


func reset() -> void:
	chains = DEFAULT.duplicate(true)
	save_loadout()


func save_loadout() -> void:
	var cf := ConfigFile.new()
	cf.set_value("loadout", "chains", chains)
	cf.save(SAVE_PATH)


func load_loadout() -> void:
	chains = DEFAULT.duplicate(true)
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		var saved = cf.get_value("loadout", "chains", {})
		for ch in CHAIN_ORDER:
			if saved.has(ch) and saved[ch] is Array and saved[ch].size() == SLOTS[ch]:
				for i in range(SLOTS[ch]):
					if POOL[ch].has(saved[ch][i]):
						chains[ch][i] = saved[ch][i]
