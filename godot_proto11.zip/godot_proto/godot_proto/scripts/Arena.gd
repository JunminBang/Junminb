extends Node2D
## 방을 가로로 이어 붙이고 진행을 관리한다.
## ① 장애물 프리셋 — OBS 딕셔너리로 방마다 다른 지형.
## ② 분기 경로 — 방 2 클리어 후 플레이어가 다음 경로를 선택.
## ③ 웨이브 풀 셔플 — 런마다 다른 적 조합.

const RoomScript := preload("res://scripts/Room.gd")

const ROOM_W := 980.0
const ROOM_H := 660.0

signal run_ended(cleared: bool)

var rooms: Array = []
var _reached := 0
var _boss_dead := false
var _ended := false
var boss_min_hp_pct := 100.0

@onready var player: Node2D = $Player

# ① 장애물 프리셋 (방 중심 기준 상대 좌표)
const OBS := {
	"none": [],
	"pillars2": [
		{"pos": Vector2(-200, -110), "size": Vector2(44, 44)},
		{"pos": Vector2(180,  110), "size": Vector2(44, 44)},
	],
	"pillars4": [
		{"pos": Vector2(-210, -110), "size": Vector2(44, 44)},
		{"pos": Vector2(-210,  110), "size": Vector2(44, 44)},
		{"pos": Vector2( 170, -110), "size": Vector2(44, 44)},
		{"pos": Vector2( 170,  110), "size": Vector2(44, 44)},
	],
	"walls_v": [
		{"pos": Vector2(-165,   0), "size": Vector2(16, 200)},
		{"pos": Vector2( 125,   0), "size": Vector2(16, 200)},
	],
	"wall_h": [
		{"pos": Vector2(-55, -135), "size": Vector2(220, 16)},
		{"pos": Vector2(-55,  135), "size": Vector2(220, 16)},
	],
	"pillar_c": [
		{"pos": Vector2(0, 0), "size": Vector2(64, 64)},
	],
}

# ③ 웨이브 풀 (티어별) — 런마다 셔플해서 3개 추출
const WAVE_POOL_T1 := [
	[0, 0], [0, 0, 3], [0, 1, 3], [0, 0, 0], [0, 0, 3, 3],
]
const WAVE_POOL_T2 := [
	[0, 0, 1], [0, 1, 3], [1, 1, 3, 3], [0, 0, 1, 3], [1, 3, 3],
]
const WAVE_POOL_T3 := [
	[0, 1, 3, 3], [0, 1, 1, 3], [1, 1, 2, 3, 3], [1, 2, 3, 3], [0, 1, 3, 3, 3],
]

# ② 분기 — _branch_pending_from >= 0 이면 선택 대기 중
var _branch_pending_from := -1
var _branch_pending_options: Array = []
var _branch_overlay: CanvasLayer = null


func _ready() -> void:
	# ③ 웨이브 셔플
	var t1 := _pick_waves(WAVE_POOL_T1, 3)
	var t2 := _pick_waves(WAVE_POOL_T2, 3)
	var ta := _pick_waves(WAVE_POOL_T3, 3)   # 분기 A (쇄도의 길)
	var t4 := _pick_waves(WAVE_POOL_T3, 3)   # 방 4

	# ① 방 정의 (장애물 포함)
	var defs := [
		{"solid_left": true, "waves": [], "obs": "none"},
		{"waves": t1, "obs": _rand_obs(["none", "pillars2"])},
		{"waves": t2, "obs": _rand_obs(["pillars2", "wall_h"])},
		{"waves": [],  "obs": "none"},   # 분기 선택 후 채워짐 (placeholder)
		{"waves": t4,  "obs": _rand_obs(["pillars4", "walls_v"])},
		{"boss": true, "solid_right": true, "waves": []},
	]

	# ② 분기 옵션 (방 2 클리어 → 방 3 선택)
	var branch_options := [
		{"label": "쇄도의 길", "desc": "경량·원거리 위주 — 속도전",
		 "waves": ta, "obs": _rand_obs(["pillars4", "none"])},
		{"label": "중압의 길", "desc": "중량·고정형 위주 — 지구전",
		 "waves": [[1, 2], [1, 2, 1], [1, 2, 2]], "obs": "walls_v"},
	]

	var x := 0.0
	for i in defs.size():
		var d: Dictionary = defs[i]
		var r := Node2D.new()
		r.set_script(RoomScript)
		r.name = "Room%d" % i
		r.size = Vector2(ROOM_W, ROOM_H)
		r.is_boss = d.get("boss", false)
		r.waves = d.get("waves", [])
		r.obstacles = OBS.get(d.get("obs", "none"), [])
		r.solid_left = d.get("solid_left", false)
		r.solid_right = d.get("solid_right", false)
		add_child(r)
		r.position = Vector2(x + ROOM_W * 0.5, 0.0)
		r.cleared.connect(_on_room_cleared.bind(i))
		rooms.append(r)
		x += ROOM_W

	# ② 분기 데이터 저장 (방 생성 후에 설정)
	_branch_pending_options = branch_options

	player.position = rooms[0].position
	player.died.connect(_end_run.bind(false))
	_set_camera_limits(Rect2(0.0, -ROOM_H * 0.5, x, ROOM_H))
	rooms[0].call_deferred("begin")


func _pick_waves(pool: Array, n: int) -> Array:
	var p := pool.duplicate()
	p.shuffle()
	return p.slice(0, n)


func _rand_obs(keys: Array) -> String:
	return keys[randi() % keys.size()]


func _process(_delta: float) -> void:
	if not is_instance_valid(player):
		return
	var idx := _room_index_at(player.global_position)
	if idx > _reached:
		rooms[idx - 1].lock_exit()
		_reached = idx
		rooms[idx].begin()

	var b = rooms[-1].boss
	if is_instance_valid(b) and b.max_health > 0:
		boss_min_hp_pct = minf(boss_min_hp_pct, 100.0 * float(b.health) / float(b.max_health))


func _room_index_at(gp: Vector2) -> int:
	for i in range(rooms.size() - 1, -1, -1):
		if rooms[i].bounds().has_point(gp):
			return i
	return _reached


func _on_room_cleared(i: int) -> void:
	if rooms[i].is_boss:
		_boss_dead = true
		for r in rooms:
			r.open_exit()
		print("ARENA CLEARED")
		_end_run(true)
		return

	# ② 분기 포인트: 문을 잠그고 선택 메뉴 표시
	if i == 2:
		rooms[i].lock_exit()
		_show_branch(i, _branch_pending_options)


func _show_branch(from_room: int, options: Array) -> void:
	_branch_pending_from = from_room
	get_tree().paused = true

	_branch_overlay = CanvasLayer.new()
	_branch_overlay.layer = 50
	_branch_overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_branch_overlay)

	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.88)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_STOP
	_branch_overlay.add_child(bg)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.add_child(center)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 24)
	center.add_child(vbox)

	var title := Label.new()
	title.text = "다음 경로를 선택하라"
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", Color(0.85, 0.75, 0.45))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 30)
	vbox.add_child(hbox)

	for opt in options:
		var card := VBoxContainer.new()
		card.custom_minimum_size = Vector2(260, 0)
		card.add_theme_constant_override("separation", 10)
		hbox.add_child(card)

		var name_lbl := Label.new()
		name_lbl.text = opt["label"]
		name_lbl.add_theme_font_size_override("font_size", 28)
		name_lbl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5))
		name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		card.add_child(name_lbl)

		var desc_lbl := Label.new()
		desc_lbl.text = opt["desc"]
		desc_lbl.add_theme_color_override("font_color", Color(0.65, 0.65, 0.68))
		desc_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		card.add_child(desc_lbl)

		var btn := Button.new()
		btn.text = "이 길로 간다"
		btn.pressed.connect(_pick_branch.bind(from_room, opt))
		card.add_child(btn)


func _pick_branch(from_room: int, opt: Dictionary) -> void:
	# 다음 방(room 3) 데이터 설정
	var next: Node = rooms[from_room + 1]
	next.waves = opt["waves"]
	next.obstacles = OBS.get(opt.get("obs", "none"), [])

	_branch_pending_from = -1
	if is_instance_valid(_branch_overlay):
		_branch_overlay.queue_free()
		_branch_overlay = null
	get_tree().paused = false
	rooms[from_room].open_exit()


## 봇 전용: 분기를 자동으로 첫 번째 옵션으로 선택
func bot_pick_branch() -> void:
	if _branch_pending_from < 0:
		return
	_pick_branch(_branch_pending_from, _branch_pending_options[0])


func _end_run(cleared: bool) -> void:
	if _ended:
		return
	_ended = true
	Meta.note_run()
	run_ended.emit(cleared)


func _set_camera_limits(r: Rect2) -> void:
	var cam := player.get_node_or_null("Camera2D")
	if cam:
		cam.limit_left = int(r.position.x)
		cam.limit_top = int(r.position.y)
		cam.limit_right = int(r.end.x)
		cam.limit_bottom = int(r.end.y)
