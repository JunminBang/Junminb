extends Node
## 메타 성장 (오토로드 Meta). 컬트 오브 더 램의 교단 업그레이드처럼,
## 런에서 모은 "영혼"을 죽어도 유지하고, 사망/클리어 화면에서 영구 강화에 쓴다.
## user://mabi_proto_save.cfg 에 저장.

const SAVE_PATH := "user://mabi_proto_save.cfg"

# id: { name, max(레벨상한), cost0(1레벨 비용), growth(레벨당 비용 배수), per(레벨당 효과량), unit(설명),
#       tags[]: 각성 계산용 (offense/defense/mobility/sustain) }
# 스탯은 최대 2레벨로 얕게 → HP 한 곳에 몰빵 불가. 빌드 정의 강화는 1레벨(비쌈).
const UPGRADES := {
	# --- 스탯 (최대 2레벨) : 생존 루트를 여러 개로 분산 ---
	"max_hp":    {"name": "강철 심장", "max": 2, "cost0": 16, "growth": 1.7, "per": 18.0, "unit": "최대 체력 +18", "tags": ["defense"]},
	"armor":     {"name": "방벽",      "max": 2, "cost0": 18, "growth": 1.7, "per": 2.0,  "unit": "받는 피해 -2 (고정)", "tags": ["defense"]},
	"vigor":     {"name": "불굴",      "max": 2, "cost0": 18, "growth": 1.7, "per": 0.1,  "unit": "피격 후 무적 +0.1초", "tags": ["defense"]},
	"iframe":    {"name": "잔상",      "max": 2, "cost0": 20, "growth": 1.8, "per": 0.05, "unit": "대시 무적 +0.05초", "tags": ["defense", "mobility"]},
	"damage":    {"name": "예리함",    "max": 2, "cost0": 16, "growth": 1.7, "per": 0.1,  "unit": "모든 피해 +10%", "tags": ["offense"]},
	"haste":     {"name": "속공",      "max": 2, "cost0": 20, "growth": 1.8, "per": 0.09, "unit": "무공 후딜 -9%", "tags": ["offense"]},
	"swift":     {"name": "질풍",      "max": 2, "cost0": 20, "growth": 1.8, "per": 0.1,  "unit": "대시 쿨다운 -0.1초", "tags": ["mobility"]},
	"lifesteal": {"name": "흡혈",      "max": 2, "cost0": 22, "growth": 1.8, "per": 0.06, "unit": "가한 피해의 6% 회복", "locked": true, "tags": ["sustain"]},
	"greed":     {"name": "탐욕",      "max": 2, "cost0": 14, "growth": 1.6, "per": 0.2,  "unit": "영혼 획득 +20%", "locked": true, "tags": []},
	# --- 빌드 정의 (1레벨) : 플레이 방식을 바꾼다. 전부 연구로 해금 ---
	"dash_slash":  {"name": "잔영검",     "max": 1, "cost0": 45, "growth": 1.0, "per": 1.0, "unit": "대시 끝나면 진행 방향으로 검기", "locked": true, "tags": ["mobility", "offense"]},
	"ult_double":  {"name": "폭주의 그릇", "max": 1, "cost0": 50, "growth": 1.0, "per": 1.0, "unit": "필살 게이지 2칸 + 획득 +50%", "locked": true, "tags": ["offense"]},
	"combo_blast": {"name": "파쇄격",     "max": 1, "cost0": 42, "growth": 1.0, "per": 1.0, "unit": "좌클릭 콤보 마무리가 전방위 폭발", "locked": true, "tags": ["offense"]},
	"berserk":     {"name": "광전사",     "max": 1, "cost0": 48, "growth": 1.0, "per": 1.0, "unit": "HP 40% 이하일 때 피해·이속 +40%", "locked": true, "tags": ["offense", "sustain"]},
}
const ORDER := ["max_hp", "armor", "vigor", "iframe", "damage", "haste", "swift", "lifesteal", "greed",
	"dash_slash", "ult_double", "combo_blast", "berserk"]
const OFFER_SIZE := 3

# 같은 태그의 보유 레벨 합이 이 값 이상이면 그 태그 "각성" (Player._apply_meta 에서 효과 + 시각)
const AWAKEN_THRESHOLD := 4
const AWAKEN_TAGS := ["offense", "defense", "mobility", "sustain"]
const AWAKEN_NAME := {"offense": "공세", "defense": "철벽", "mobility": "질주", "sustain": "포식"}

# --- 계약 (런 시작 시 3장 중 1택. 불리한 조건 + 보상 배율) ---
# mods: 난이도 수정치 (0 = 없음)   rewards: 획득 배율 (1.0 = 기본)
const CONTRACTS := {
	"swarm": {"name": "쇄도", "desc": "적 이동속도 +25%, 웨이브당 적 +1", "boon": "영혼 획득 +60%",
		"mods": {"enemy_speed": 0.25, "enemy_count": 1}, "rewards": {"souls": 1.6}},
	"frail": {"name": "무딘 칼", "desc": "플레이어 피해 -20%", "boon": "영혼 획득 +80%",
		"mods": {"player_damage": -0.2}, "rewards": {"souls": 1.8}},
	"glass": {"name": "유리 심장", "desc": "최대 체력 -35%", "boon": "영혼 획득 2배",
		"mods": {"hp_mult": -0.35}, "rewards": {"souls": 2.0}},
	"hunted": {"name": "쫓기는 자", "desc": "보스 예비동작 25% 빨라짐", "boon": "영혼 획득 2배",
		"mods": {"boss_haste": 0.25}, "rewards": {"souls": 2.0}},
	"elite": {"name": "정예", "desc": "적 체력 +50%", "boon": "영혼 획득 +50%",
		"mods": {"enemy_hp": 0.5}, "rewards": {"souls": 1.5}},
}
const CONTRACT_OFFER_SIZE := 3

var souls := 0
var levels: Dictionary = {}
var runs := 0
var offer: Array = []   # 제단에 현재 걸려 있는 강화 3종 (id). 리롤로 교체.
var contract := ""              # 현재 런의 계약 id ("" = 계약 없음)
var contract_offer: Array = []  # 던전 입장 화면에 걸린 계약 후보 3종


func _ready() -> void:
	load_game()


func level(id: String) -> int:
	return int(levels.get(id, 0))


func is_max(id: String) -> bool:
	return level(id) >= int(UPGRADES[id]["max"])


func cost(id: String) -> int:
	var u: Dictionary = UPGRADES[id]
	return int(round(float(u["cost0"]) * pow(float(u["growth"]), level(id))))


func can_buy(id: String) -> bool:
	return not is_max(id) and souls >= cost(id)


func buy(id: String) -> bool:
	if not can_buy(id):
		return false
	souls -= cost(id)
	levels[id] = level(id) + 1
	save_game()
	return true


## 해당 업그레이드의 누적 효과량 (레벨 × per)
func bonus(id: String) -> float:
	return level(id) * float(UPGRADES[id]["per"])


## 빌드 정의 강화 보유 여부
func has(id: String) -> bool:
	return level(id) > 0


func add_souls(base: int) -> void:
	souls += int(round(base * (1.0 + bonus("greed")) * creward("souls")))
	save_game()   # ponytail: 처치마다 파일 쓰기. cfg 가 작아 무해, 필요하면 디바운스.


# --- 각성 (태그별 보유 레벨 합) ------------------------------------------------
func tag_power(tag: String) -> int:
	var p := 0
	for id in ORDER:
		if tag in UPGRADES[id].get("tags", []):
			p += level(id)
	return p


func awakened(tag: String) -> bool:
	return tag_power(tag) >= AWAKEN_THRESHOLD


func awakened_tags() -> Array:
	return AWAKEN_TAGS.filter(func(t): return awakened(t))


# --- 계약 --------------------------------------------------------------------
func roll_contracts() -> void:
	var pool: Array = CONTRACTS.keys()
	pool.shuffle()
	contract_offer = pool.slice(0, CONTRACT_OFFER_SIZE)


func set_contract(id: String) -> void:
	contract = id if CONTRACTS.has(id) else ""
	save_game()


## 계약 난이도 수정치 (계약 없거나 해당 키 없으면 0.0)
func cmod(key: String) -> float:
	if contract == "":
		return 0.0
	return float(CONTRACTS[contract].get("mods", {}).get(key, 0.0))


## 계약 보상 배율 (계약 없거나 해당 키 없으면 1.0)
func creward(key: String) -> float:
	if contract == "":
		return 1.0
	return float(CONTRACTS[contract].get("rewards", {}).get(key, 1.0))


func note_run() -> void:
	runs += 1
	save_game()


# --- 제단 오퍼 (3종 랜덤 강화) ---------------------------------------------------
func _available() -> Array:
	return ORDER.filter(func(id):
		return not is_max(id) \
			and (not UPGRADES[id].get("locked", false) or Research.is_upgrade_unlocked(id)))


## 오퍼 3종을 새로 뽑는다 (리롤 / 최초 오픈).
func roll_offer() -> void:
	var pool: Array = _available()
	pool.shuffle()
	offer = pool.slice(0, OFFER_SIZE)
	save_game()


## 구매한 슬롯을 "다른" 강화로 교체한다 — 같은 걸 연속으로 못 사게 해서 빌드가 갈리게.
## (레벨 2를 원하면 나중에 다시 굴러 나오거나 리롤해야 함.) 채울 게 없으면 슬롯을 비운다.
func consume_offer(bought_id: String) -> void:
	var i: int = offer.find(bought_id)
	if i < 0:
		return
	var pool: Array = _available().filter(func(id): return not offer.has(id))
	if pool.is_empty():
		offer.remove_at(i)
	else:
		pool.shuffle()
		offer[i] = pool[0]
	# 혹시 최대치 도달분이 남아 있으면 정리
	offer = offer.filter(func(id): return not is_max(id))
	save_game()


func spend(n: int) -> bool:
	if souls < n:
		return false
	souls -= n
	save_game()
	return true


func reset() -> void:
	souls = 0
	levels = {}
	runs = 0
	offer = []
	contract = ""
	contract_offer = []
	save_game()


func save_game() -> void:
	var cf := ConfigFile.new()
	cf.set_value("meta", "souls", souls)
	cf.set_value("meta", "levels", levels)
	cf.set_value("meta", "runs", runs)
	cf.set_value("meta", "offer", offer)
	cf.set_value("meta", "contract", contract)
	cf.save(SAVE_PATH)


func load_game() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) != OK:
		return
	souls = int(cf.get_value("meta", "souls", 0))
	levels = cf.get_value("meta", "levels", {})
	runs = int(cf.get_value("meta", "runs", 0))
	offer = cf.get_value("meta", "offer", [])
	offer = offer.filter(func(id): return UPGRADES.has(id) and not is_max(id))
	contract = cf.get_value("meta", "contract", "")
	if not CONTRACTS.has(contract):
		contract = ""
