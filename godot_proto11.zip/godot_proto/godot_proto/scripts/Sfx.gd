extends Node
## 절차적 효과음 (오토로드 Sfx). 외부 에셋 없이 코드로 파형을 만들어 재생한다.
## 기획서 2-4: 저역 강조 타격음 + 크리티컬 시 고음 레이어.
##
## 사용법: Sfx.play("hit_heavy")

const RATE := 22050

var _players: Array[AudioStreamPlayer] = []
var _next := 0
var _cache: Dictionary = {}


func _ready() -> void:
	for i in range(10):
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)
	# name           기본주파수  길이   노이즈  감쇠   고음레이어  볼륨
	_cache["hit_light"] = _make(200.0, 0.12, 0.45, 9.0, 0.0, 0.55)
	_cache["hit_heavy"] = _make(95.0, 0.24, 0.55, 5.0, 0.0, 0.7)
	_cache["hit_crit"]  = _make(95.0, 0.24, 0.55, 5.0, 1600.0, 0.7)
	_cache["whoosh"]    = _make(0.0, 0.13, 1.0, 13.0, 0.0, 0.28)
	_cache["dash"]      = _make(0.0, 0.18, 0.85, 9.0, 0.0, 0.4)
	_cache["tele"]      = _make(480.0, 0.28, 0.1, 2.5, 0.0, 0.35)
	_cache["hurt"]      = _make(140.0, 0.22, 0.4, 6.0, 320.0, 0.6)
	_cache["death"]     = _make(65.0, 0.4, 0.65, 3.0, 0.0, 0.7)
	_cache["soul"]      = _make(880.0, 0.1, 0.03, 14.0, 1760.0, 0.28)


func play(sound: String, pitch_var := 0.08) -> void:
	if not _cache.has(sound):
		return
	var p: AudioStreamPlayer = _players[_next]
	_next = (_next + 1) % _players.size()
	p.stream = _cache[sound]
	p.pitch_scale = 1.0 + randf_range(-pitch_var, pitch_var)
	p.play()


## 감쇠하는 사인 + 노이즈 버스트를 16bit PCM WAV 로 굽는다.
func _make(freq: float, dur: float, noise_amt: float, decay: float, hi_freq: float, vol: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var phase := 0.0
	var hi_phase := 0.0
	for i in range(n):
		var t := float(i) / RATE
		var env: float = exp(-decay * t)
		var s := 0.0
		if freq > 0.0:
			phase += TAU * freq / RATE
			s += sin(phase) * (1.0 - noise_amt)
		if hi_freq > 0.0:
			hi_phase += TAU * hi_freq / RATE
			s += sin(hi_phase) * 0.3 * exp(-16.0 * t)
		s += randf_range(-1.0, 1.0) * noise_amt
		s = clampf(s * env * vol, -1.0, 1.0)
		data.encode_s16(i * 2, int(s * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = data
	return wav
