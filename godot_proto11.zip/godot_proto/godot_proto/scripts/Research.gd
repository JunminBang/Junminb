extends Node
## 빌드연구 (오토로드 Research). 영혼으로 영구 해금.
##   unlock: 제단(Altar) 오퍼 풀에 그 강화 id 를 추가
##   passive: 영구 스탯 (Player._apply_meta 가 합산). key = max_hp / armor / damage ...
## user://mabi_proto_research.cfg 저장.

const SAVE_PATH := "user://mabi_proto_research.cfg"

# id: { name, cost(영혼), requires[선행 id], desc,
#       unlock:"강화id" / unlock_move:"무공id" / passive:{key:값} }
const NODES := {
	"toughness": {"name": "가죽 무두질", "cost": 20, "requires": [],
		"passive": {"armor": 1.0}, "desc": "받는 피해 -1 (영구)"},
	"vitality": {"name": "골법 단련", "cost": 35, "requires": ["toughness"],
		"passive": {"max_hp": 12.0}, "desc": "최대 체력 +12 (영구)"},
	# --- 무공 해금 (로드아웃 슬롯 후보) ---
	"form_thrust": {"name": "찌르기 형", "cost": 20, "requires": [],
		"unlock_move": "thrust", "desc": "무공 '찌르기' (긴 사거리 관통) 해금"},
	"form_cleave": {"name": "강타 형", "cost": 25, "requires": [],
		"unlock_move": "cleave", "desc": "무공 '강타' (넓은 근접) 해금"},
	"form_bolt": {"name": "섬격 형", "cost": 35, "requires": ["form_thrust"],
		"unlock_move": "bolt", "desc": "무공 '섬격' (초장거리 직선) 해금"},
	"form_shockwave": {"name": "충격파 형", "cost": 40, "requires": ["form_cleave"],
		"unlock_move": "shockwave", "desc": "무공 '충격파' (전방위 넉백) 해금"},
	"form_spin": {"name": "회전베기 형", "cost": 30, "requires": ["form_cleave"],
		"unlock_move": "spin", "desc": "무공 '회전베기' (전방위) 해금"},
	"form_pierce": {"name": "돌진 관통 형", "cost": 50, "requires": ["form_thrust"],
		"unlock_move": "lunge_pierce", "desc": "E 무공 '돌진 관통' 해금"},
	# --- 제단 강화 해금 ---
	"blade_arts": {"name": "검술 연구", "cost": 30, "requires": [],
		"unlock": "dash_slash", "desc": "제단에 '잔영검' 해금"},
	"shatter": {"name": "파쇄 이론", "cost": 35, "requires": ["blade_arts"],
		"unlock": "combo_blast", "desc": "제단에 '파쇄격' 해금"},
	"overflow": {"name": "정수 그릇", "cost": 45, "requires": ["blade_arts"],
		"unlock": "ult_double", "desc": "제단에 '폭주의 그릇' 해금"},
	"bloodlust": {"name": "피의 의식", "cost": 35, "requires": [],
		"unlock": "lifesteal", "desc": "제단에 '흡혈' 해금"},
	"frenzy": {"name": "광기 각인", "cost": 50, "requires": ["bloodlust"],
		"unlock": "berserk", "desc": "제단에 '광전사' 해금"},
	"avarice": {"name": "탐욕의 룬", "cost": 25, "requires": [],
		"unlock": "greed", "desc": "제단에 '탐욕' 해금"},
}
const ORDER := ["toughness", "vitality",
	"form_thrust", "form_cleave", "form_bolt", "form_shockwave", "form_spin", "form_pierce",
	"blade_arts", "shatter", "overflow", "bloodlust", "frenzy", "avarice"]

var done: Array = []   # 완료한 연구 id


func _ready() -> void:
	load_research()


func is_done(id: String) -> bool:
	return done.has(id)


func requires_met(id: String) -> bool:
	for r in NODES[id]["requires"]:
		if not is_done(r):
			return false
	return true


func can_research(id: String) -> bool:
	if is_done(id) or not requires_met(id):
		return false
	return Meta.souls >= int(NODES[id]["cost"])


func research(id: String) -> bool:
	if not can_research(id):
		return false
	Meta.souls -= int(NODES[id]["cost"])
	done.append(id)
	save_research()
	return true


## 제단 강화 id 가 연구로 해금됐는가
func is_upgrade_unlocked(upgrade_id: String) -> bool:
	for id in done:
		if NODES[id].get("unlock", "") == upgrade_id:
			return true
	return false


## 무공 id 가 연구로 해금됐는가 (로드아웃 슬롯 후보)
func is_move_unlocked(move_id: String) -> bool:
	for id in done:
		if NODES[id].get("unlock_move", "") == move_id:
			return true
	return false


## 완료한 연구들의 passive[key] 합
func passive(key: String) -> float:
	var total := 0.0
	for id in done:
		total += float(NODES[id].get("passive", {}).get(key, 0.0))
	return total


func reset() -> void:
	done = []
	save_research()


func save_research() -> void:
	var cf := ConfigFile.new()
	cf.set_value("research", "done", done)
	cf.save(SAVE_PATH)


func load_research() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		done = cf.get_value("research", "done", [])
		done = done.filter(func(id): return NODES.has(id))
