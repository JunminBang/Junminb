extends CanvasLayer
## 던전 입장 화면 — 계약 3장 중 1택 (또는 계약 없이 입장).
## 계약 = 불리한 조건 + 획득 보상 배율. Game.enter_dungeon() 이 띄운다.

var _grace := 0.0
var _on_pick: Callable = Callable()

var _overlay: ColorRect
var _list: VBoxContainer


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _process(delta: float) -> void:
	if _grace > 0.0:
		_grace = maxf(0.0, _grace - delta)


func _build() -> void:
	_overlay = ColorRect.new()
	_overlay.color = Color(0, 0, 0, 0.93)
	_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_overlay)

	var box := VBoxContainer.new()
	box.anchor_left = 0.5
	box.anchor_top = 0.5
	box.anchor_right = 0.5
	box.anchor_bottom = 0.5
	box.offset_left = -340.0
	box.offset_right = 340.0
	box.offset_top = -220.0
	box.offset_bottom = 220.0
	box.add_theme_constant_override("separation", 10)
	_overlay.add_child(box)

	var title := Label.new()
	title.text = "계약"
	title.add_theme_font_size_override("font_size", 52)
	title.add_theme_color_override("font_color", Color(0.85, 0.55, 0.5))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)

	var sub := Label.new()
	sub.text = "불리한 조건을 받아들이면 이번 런의 획득이 늘어난다. 하나 고르거나, 계약 없이 입장."
	sub.add_theme_color_override("font_color", Color(0.6, 0.6, 0.62))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(sub)

	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 12)
	box.add_child(gap)

	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 6)
	box.add_child(_list)


func open_menu(on_pick: Callable) -> void:
	if visible:
		return
	_on_pick = on_pick
	Meta.roll_contracts()
	_refresh()
	visible = true
	_grace = 0.35
	get_tree().paused = true


func _refresh() -> void:
	for c in _list.get_children():
		c.queue_free()

	for id in Meta.contract_offer:
		var ct: Dictionary = Meta.CONTRACTS[id]
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 52)
		b.text = "  %s   —  %s\n       보상:  %s" % [ct["name"], ct["desc"], ct["boon"]]
		b.pressed.connect(_pick.bind(id))
		_list.add_child(b)

	var none := Button.new()
	none.custom_minimum_size = Vector2(0, 40)
	none.text = "계약 없이 입장"
	none.pressed.connect(_pick.bind(""))
	_list.add_child(none)


func _pick(id: String) -> void:
	Meta.set_contract(id)
	visible = false
	get_tree().paused = false
	if _on_pick.is_valid():
		_on_pick.call()


func _unhandled_input(e: InputEvent) -> void:
	if _grace > 0.0 or not visible:
		return
	if e is InputEventKey and e.pressed and not e.echo and e.keycode == KEY_ESCAPE:
		_pick("")   # ESC = 계약 없이 입장
