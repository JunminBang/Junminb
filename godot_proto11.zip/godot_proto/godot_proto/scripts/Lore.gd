extends Node
## 거점 서사 (오토로드 Lore). 런은 리셋돼도 거점의 NPC·대화는 누적된다.
## 서사는 던전이 아니라 "집"에서 소비 — 부패도 세계관의 앵커.
## 구출 조건은 결정론적 마일스톤 (RNG 없음). user://mabi_proto_lore.cfg 저장.

const SAVE_PATH := "user://mabi_proto_lore.cfg"

const NPCS := {
	"smith": {"name": "대장장이 카린", "at": Vector2(-190, 150), "color": Color(0.82, 0.5, 0.35),
		"lines": [
			"살아 돌아왔군. 대부분은 못 그래.",
			"부패가 이 땅을 먹은 지 오래야. 당신이 늦추는 그 며칠이 우리에겐 전부지.",
			"쇠는 충분해. 계속 내려가 준다면, 계속 벼려주지.",
		]},
	"scholar": {"name": "기록자 벤", "at": Vector2(190, 150), "color": Color(0.45, 0.7, 0.85),
		"lines": [
			"위험을 자초하고도 돌아왔어? 기록할 가치가 있군.",
			"계약은 부패와의 거래야. 더 내주면 더 가져오지 — 대가는 항상 있지만.",
			"당신이 몇 번을 죽었는지 세어두고 있어. 그게 이 이야기의 길이니까.",
		]},
	"child": {"name": "아이 미르", "at": Vector2(0, -150), "color": Color(0.9, 0.8, 0.5),
		"lines": [
			"또 갔다 왔어? 안 무서워?",
			"다들 당신이 언젠가 안 돌아올 거래. 근데 난 안 믿어.",
			"부패가 다 사라지면… 그때는 안 내려가도 되는 거지?",
		]},
}

var rescued: Array = []      # 구출된 npc id
var wins := 0                # 던전 클리어 횟수
var contract_wins := 0       # 계약을 걸고 클리어한 횟수
var line_seen: Dictionary = {}   # npc id -> 마지막으로 본 대사 인덱스


func _ready() -> void:
	_load()


## 던전 클리어 시 호출. 새로 구출된 NPC id 목록을 반환.
func on_run_cleared(had_contract: bool) -> Array:
	wins += 1
	if had_contract:
		contract_wins += 1
	var newly: Array = []
	if wins >= 1 and not rescued.has("smith"):
		newly.append("smith")
	if contract_wins >= 1 and not rescued.has("scholar"):
		newly.append("scholar")
	if wins >= 5 and not rescued.has("child"):
		newly.append("child")
	for id in newly:
		rescued.append(id)
	_save()
	return newly


## NPC 와 상호작용 시 다음 대사 (마지막 대사 지나면 처음으로 순환).
func next_line(npc_id: String) -> String:
	var lines: Array = NPCS[npc_id]["lines"]
	var i := (int(line_seen.get(npc_id, -1)) + 1) % lines.size()
	line_seen[npc_id] = i
	_save()
	return lines[i]


func reset() -> void:
	rescued = []
	wins = 0
	contract_wins = 0
	line_seen = {}
	_save()


func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("lore", "rescued", rescued)
	cf.set_value("lore", "wins", wins)
	cf.set_value("lore", "contract_wins", contract_wins)
	cf.set_value("lore", "line_seen", line_seen)
	cf.save(SAVE_PATH)


func _load() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) != OK:
		return
	rescued = cf.get_value("lore", "rescued", [])
	rescued = rescued.filter(func(id): return NPCS.has(id))
	wins = int(cf.get_value("lore", "wins", 0))
	contract_wins = int(cf.get_value("lore", "contract_wins", 0))
	line_seen = cf.get_value("lore", "line_seen", {})
