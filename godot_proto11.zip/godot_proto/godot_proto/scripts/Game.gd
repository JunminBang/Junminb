extends Node
## 씬 매니저 (메인 씬). 거점(Base) ↔ 던전(Main) 을 World 컨테이너에 로드/교체한다.
##   - 거점 던전 포탈 → enter_dungeon() → 계약 선택 → 던전
##   - 던전 클리어/사망 → run_ended 시그널 → 수확 요약 배너 → 거점 복귀
##   - 클리어 시 Lore 마일스톤 체크 → 거점에 NPC 구출
##   - Tab: 영혼 제단 (어디서든)

const BaseScene := preload("res://scenes/Base.tscn")
const DungeonScene := preload("res://scenes/Main.tscn")

@onready var _world: Node = $World
@onready var _altar: CanvasLayer = $Altar
@onready var _research: CanvasLayer = $Research
@onready var _loadout: CanvasLayer = $Loadout
@onready var _contract: CanvasLayer = $Contract
@onready var _dialogue: CanvasLayer = $Dialogue
@onready var _banner_bg: ColorRect = $Banner/BG
@onready var _banner: Label = $Banner/BG/Label

var _in_dungeon := false

# 런 수확 추적 (던전 입장 시점 스냅샷 → 종료 시 차이)
var _run_souls0 := 0
var _run_contract := ""


func _ready() -> void:
	add_to_group("game")
	$Banner.visible = false
	_load_base()


func _clear_world() -> void:
	for c in _world.get_children():
		_world.remove_child(c)   # 즉시 트리에서 제거 → 그룹에서도 빠짐
		c.queue_free()


func _load_base() -> void:
	_clear_world()
	_in_dungeon = false
	_world.add_child(BaseScene.instantiate())


func enter_dungeon(skip_contract := false) -> void:
	if _in_dungeon:
		return
	if skip_contract:
		Meta.set_contract("")
		_do_enter_dungeon()
	else:
		_contract.open_menu(_do_enter_dungeon)


func _do_enter_dungeon() -> void:
	if _in_dungeon:
		return
	_clear_world()
	_in_dungeon = true
	_run_souls0 = Meta.souls
	_run_contract = Meta.contract
	var d := DungeonScene.instantiate()
	d.run_ended.connect(_on_run_ended)
	_world.add_child(d)



func _on_run_ended(cleared: bool) -> void:
	if not _in_dungeon:
		return
	_in_dungeon = false   # 중복 방지

	var arena: Node = _world.get_child(0) if _world.get_child_count() > 0 else null
	var reached := 0
	var boss_low := 100.0
	if is_instance_valid(arena):
		reached = int(arena._reached)
		boss_low = float(arena.boss_min_hp_pct)

	# 클리어 시 서사 마일스톤
	var rescued_now: Array = []
	if cleared:
		rescued_now = Lore.on_run_cleared(_run_contract != "")

	# --- 수확 요약 배너 ---
	var gained_souls: int = Meta.souls - _run_souls0
	var head := "던전 클리어!" if cleared else "쓰러졌다..."
	var lines: Array = [head]
	lines.append("%d번째 시도 · 최고 도달 방 %d/%d" % [Meta.runs, reached, 5])
	lines.append("영혼 +%d" % maxi(0, gained_souls))
	if not cleared and boss_low < 99.0:
		lines.append("보스 HP %d%% 까지 몰아붙였다" % int(round(boss_low)))
	if not rescued_now.is_empty():
		var names: Array = rescued_now.map(func(id): return Lore.NPCS[id]["name"])
		lines.append("거점에 %s 합류" % ", ".join(names))

	_banner.text = "\n".join(lines)
	_banner.add_theme_color_override("font_color",
		Color(0.5, 0.9, 0.6) if cleared else Color(0.85, 0.35, 0.3))
	$Banner.visible = true
	await get_tree().create_timer(2.6).timeout
	$Banner.visible = false
	_load_base()


## 거점 NPC 와 대화 (Base 가 triggered("npc:<id>") 로 호출)
func talk_to(npc_id: String) -> void:
	if not Lore.NPCS.has(npc_id):
		return
	var npc: Dictionary = Lore.NPCS[npc_id]
	_dialogue.show_line(npc["name"], Lore.next_line(npc_id), npc["color"])


func open_shop() -> void:
	_altar.open_shop()


func open_research() -> void:
	_research.open_bench()


func open_loadout() -> void:
	_loadout.open_menu()
