extends CharacterBody2D
## 몬스터: 플레이어를 쫓아가 예비동작(텔레그래프) 후 돌진 공격한다.
## RANGED 체급은 거리를 벌리며 투사체를 쏜다.
## 체급(weight)에 따라 넉백 저항 / 크기 / 체력 / 속도 / 공격 방식이 다르다. (기획서 2-4)
##
## 상태: IDLE → CHASE → TELE(예비동작) → ATTACK(돌진) → RECOVER → CHASE
##       피격 시 HURT 로 빠지고, TELE 중 맞으면 예비동작이 취소된다.

const HitSpark := preload("res://scripts/HitSpark.gd")
const Pickup := preload("res://scripts/Pickup.gd")
const AoeWarning := preload("res://scripts/AoeWarning.gd")
const ProjectileScript := preload("res://scripts/Projectile.gd")

## 경량: 잘 날아감 / 중량: 반만 밀림 / 고정형: 안 밀림 / 원거리: 카이팅 + 투사체
enum Weight { LIGHT, HEAVY, FIXED, RANGED }
@export var weight: Weight = Weight.LIGHT

enum S { IDLE, CHASE, TELE, ATTACK, RECOVER, HURT }

const ATTACK_RANGE := 48.0
const TELE_TIME := 0.5
const ATTACK_TIME := 0.13
const RECOVER_TIME := 0.4
const LUNGE_SPEED := 430.0
const CONTACT_DAMAGE := 12
const CONTACT_KNOCKBACK := 300.0

# 원거리 전용
const KITE_MIN := 190.0        # 이보다 가까우면 후퇴
const KITE_MAX := 360.0        # 이보다 멀면 접근
const RANGED_DAMAGE := 8
const RANGED_COOLDOWN := 1.3
const PROJECTILE_SPEED := 300.0
var fire_cd := 0.0

var st: S = S.IDLE
var max_health := 40
var move_spd := 95.0
var kb_resist := 1.0          # 받는 넉백 배율
var stagger := 0.18           # 피격 경직 시간

const STAGGER_IMMUNE := 0.55  # 경직에서 회복한 뒤 이 시간 동안은 다시 경직 안 됨 (연타 스턴락 방지)
var stagger_immune := 0.0

var health: int
var knockback: Vector2 = Vector2.ZERO
var t := 0.0
var lunge_dir: Vector2 = Vector2.RIGHT
var player: Node2D
var _glow_tween: Tween
var _atk_warn: Node2D           # 공격 범위 예고 장판

@onready var sprite: ColorRect = $Vis/Sprite
@onready var jelly: Node2D = $Vis
@onready var health_bar: ProgressBar = $HealthBar
@onready var col_shape: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	add_to_group("enemy")
	_apply_weight()
	# 계약 수정치 (계약 없으면 0 → 변화 없음)
	move_spd *= 1.0 + Meta.cmod("enemy_speed")
	max_health = maxi(1, int(round(max_health * (1.0 + Meta.cmod("enemy_hp")))))
	health = max_health
	health_bar.max_value = max_health
	health_bar.value = health


func _apply_weight() -> void:
	var radius := 18.0
	var c: Color
	match weight:
		Weight.LIGHT:
			max_health = 30; move_spd = 115.0; kb_resist = 1.4; stagger = 0.2
			radius = 15.0; c = Color(0.9, 0.35, 0.3)
		Weight.HEAVY:
			max_health = 70; move_spd = 62.0; kb_resist = 0.45; stagger = 0.12
			radius = 24.0; c = Color(0.6, 0.18, 0.18)
		Weight.FIXED:
			max_health = 55; move_spd = 78.0; kb_resist = 0.0; stagger = 0.04
			radius = 21.0; c = Color(0.55, 0.35, 0.7)
		Weight.RANGED:
			max_health = 20; move_spd = 92.0; kb_resist = 1.3; stagger = 0.22
			radius = 14.0; c = Color(0.4, 0.85, 0.9)
	sprite.offset_left = -radius
	sprite.offset_top = -radius
	sprite.offset_right = radius
	sprite.offset_bottom = radius
	sprite.color = c
	var shape := CircleShape2D.new()   # 인스턴스마다 고유 shape (공유 리소스 리사이즈 방지)
	shape.radius = radius
	col_shape.shape = shape
	health_bar.offset_left = -radius - 2
	health_bar.offset_right = radius + 2
	health_bar.offset_top = -radius - 16
	health_bar.offset_bottom = -radius - 8


func _physics_process(delta: float) -> void:
	knockback = knockback.move_toward(Vector2.ZERO, 900.0 * delta)
	t -= delta
	stagger_immune = maxf(0.0, stagger_immune - delta)
	fire_cd = maxf(0.0, fire_cd - delta)
	if not is_instance_valid(player):
		player = get_tree().get_first_node_in_group("player")

	match st:
		S.IDLE, S.CHASE:
			if weight == Weight.RANGED:
				_ranged_move()
			else:
				_chase()
		S.TELE:
			velocity = Vector2.ZERO
			if t <= 0.0:
				_begin_lunge()
		S.ATTACK:
			velocity = lunge_dir * LUNGE_SPEED
			if t <= 0.0:
				_land_attack()
		S.RECOVER:
			velocity = velocity.move_toward(Vector2.ZERO, 700.0 * delta)
			if t <= 0.0:
				st = S.CHASE
		S.HURT:
			velocity = Vector2.ZERO
			if t <= 0.0:
				st = S.CHASE

	velocity += knockback
	move_and_slide()


func _glow_telegraph(col: Color) -> void:
	if _glow_tween and _glow_tween.is_valid():
		_glow_tween.kill()
	_glow_tween = create_tween()
	_glow_tween.tween_property(sprite, "modulate", col, TELE_TIME * 0.85)


func _chase() -> void:
	if not is_instance_valid(player):
		velocity = Vector2.ZERO
		return
	var to: Vector2 = player.global_position - global_position
	var d := to.length()
	if d <= ATTACK_RANGE:
		st = S.TELE
		t = TELE_TIME
		velocity = Vector2.ZERO
		Sfx.play("tele")
		_glow_telegraph(Color(1.7, 1.5, 0.4))
		jelly.poke(-0.22, 0.28)   # 예비동작: 웅크렸다가
		# 공격 방향을 지금 확정하고, 착지 예상 지점에 피격 범위를 예고 (플레이어가 TELE_TIME 동안 회피)
		lunge_dir = to.normalized()
		var land := global_position + lunge_dir * (LUNGE_SPEED * ATTACK_TIME)
		_atk_warn = AoeWarning.spawn(get_parent(), land, "circle",
			{"radius": ATTACK_RANGE + 22.0, "color": Color(1.0, 0.4, 0.32)},
			0, TELE_TIME + ATTACK_TIME)
	else:
		# 방에 갇힌 전투이므로 거리 상관없이 끝까지 추격 (디아그로 없음)
		st = S.CHASE
		velocity = to.normalized() * move_spd


## 원거리: 사거리 유지하며 스트레이프, 쿨 준비되면 조준(TELE) 후 발사
func _ranged_move() -> void:
	if not is_instance_valid(player):
		velocity = Vector2.ZERO
		return
	var to: Vector2 = player.global_position - global_position
	var d := to.length()
	st = S.CHASE
	if d < KITE_MIN:
		velocity = -to.normalized() * move_spd            # 후퇴
	elif d > KITE_MAX:
		velocity = to.normalized() * move_spd             # 접근
	elif fire_cd <= 0.0:
		# 조준
		st = S.TELE
		t = TELE_TIME
		velocity = Vector2.ZERO
		Sfx.play("tele")
		_glow_telegraph(Color(0.5, 1.7, 1.8))
		lunge_dir = to.normalized()
		_atk_warn = AoeWarning.spawn(get_parent(), global_position, "cone",
			{"radius": KITE_MAX + 120.0, "half_angle": 0.09, "aim": lunge_dir,
			"color": Color(0.45, 0.9, 0.95)}, 0, TELE_TIME)
	else:
		velocity = to.orthogonal().normalized() * move_spd * 0.65   # 스트레이프


func _begin_lunge() -> void:
	sprite.modulate = Color.WHITE
	if weight == Weight.RANGED:
		_fire()
		st = S.RECOVER
		t = RECOVER_TIME
		return
	st = S.ATTACK
	t = ATTACK_TIME
	# lunge_dir 은 TELE 진입 때 확정됨 — 여기서 재조준하지 않아야 예고가 정직해진다
	jelly.poke_dir(lunge_dir, 0.6)   # 돌진: 앞으로 쭉


func _fire() -> void:
	var b := ProjectileScript.new()
	b.velocity = lunge_dir * PROJECTILE_SPEED
	b.damage = RANGED_DAMAGE
	b.knockback = 220.0
	b.color = Color(0.5, 0.9, 0.95)
	get_parent().add_child(b)
	b.global_position = global_position + lunge_dir * 18.0
	fire_cd = RANGED_COOLDOWN
	Sfx.play("whoosh")
	jelly.poke_dir(-lunge_dir, 0.45)   # 반동


func _land_attack() -> void:
	if is_instance_valid(player) and player.has_method("take_hit"):
		if player.global_position.distance_to(global_position) <= ATTACK_RANGE + 22.0:
			player.take_hit(CONTACT_DAMAGE, lunge_dir, CONTACT_KNOCKBACK)
	st = S.RECOVER
	t = RECOVER_TIME


## 플레이어의 공격이 호출한다.
func take_hit(damage: int, dir: Vector2, knockback_force: float) -> void:
	health -= damage
	health_bar.value = health
	jelly.poke(-0.3, 0.5)           # 피격: 납작하게 눌렸다 튀어오름
	_flash()

	var will_stagger := stagger > 0.0 and stagger_immune <= 0.0
	var kb_mult := kb_resist if will_stagger else kb_resist * 0.3   # 면역 중엔 덜 밀림 (버티는 느낌)
	knockback = dir.normalized() * knockback_force * kb_mult

	if will_stagger:
		# 경직: 예비동작/예고를 끊고 HURT 로. 이후 (경직시간 + STAGGER_IMMUNE) 동안은 재경직 불가
		# → 연타로 무한 스턴락 못 걸고, 적이 반격할 창이 주기적으로 열린다.
		if _glow_tween and _glow_tween.is_valid():
			_glow_tween.kill()
		sprite.modulate = Color.WHITE
		if is_instance_valid(_atk_warn):
			_atk_warn.queue_free()
		st = S.HURT
		t = stagger
		stagger_immune = stagger + STAGGER_IMMUNE

	if health <= 0:
		var s := HitSpark.new()
		get_parent().add_child(s)
		s.global_position = global_position
		s.setup(Color(1.0, 0.7, 0.5), 46.0)
		Sfx.play("death")
		Pickup.drop(get_parent(), global_position, "soul", [2, 5, 4, 3][weight])   # 영혼 (L/H/F/R)
		queue_free()


func _flash() -> void:
	var base: Color = sprite.color
	sprite.color = Color(1, 1, 1)
	var tw := create_tween()
	tw.tween_property(sprite, "color", base, 0.1)
