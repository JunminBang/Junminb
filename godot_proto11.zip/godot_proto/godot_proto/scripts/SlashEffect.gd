extends Node2D
## 검기 / 스킬 범위 이펙트.
## 부채꼴(근접 참격) 또는 확장 링(전방위기)을 그린 뒤 짧게 페이드아웃하고 스스로 사라진다.
## 별도 에셋 없이 _draw 로만 그리며, 공격의 사거리·각도를 그대로 받아 판정 범위를 시각화한다.
## 빗나가도 이 이펙트는 나오므로 "입력이 먹혔는지"에 대한 피드백 역할도 한다.

var _range: float = 60.0
var _half_angle: float = 0.9   # 부채꼴 절반각(rad). PI 이상이면 전방위 링으로 그린다.
var _color: Color = Color(0.8, 0.95, 1.0)
var _life: float = 0.16
var _t: float = 0.0


## dir: 공격 방향 / range_px: 사거리 / half_angle: 부채꼴 절반각 / color: 색 / life: 지속 시간
func setup(dir: Vector2, range_px: float, half_angle: float, color: Color, life: float = 0.16) -> void:
	rotation = dir.angle()
	_range = range_px
	_half_angle = half_angle
	_color = color
	_life = life


func _process(delta: float) -> void:
	_t += delta
	if _t >= _life:
		queue_free()
		return
	queue_redraw()


func _draw() -> void:
	var k: float = clampf(_t / _life, 0.0, 1.0)
	var col: Color = _color
	col.a = 1.0 - k

	if _half_angle >= PI - 0.05:
		# 전방위 충격파: 확장하는 두 겹 링
		var rr: float = _range * (0.35 + 0.65 * k)
		draw_arc(Vector2.ZERO, rr, 0.0, TAU, 48, col, 4.0, true)
		var inner_col: Color = col
		inner_col.a *= 0.4
		draw_arc(Vector2.ZERO, rr * 0.72, 0.0, TAU, 48, inner_col, 8.0, true)
		return

	# 근접 참격: 앞으로 살짝 쓸리는 호를 3겹으로 겹쳐 스윙처럼 보이게. 바깥 호 = 최대 사거리.
	var outer: float = _range * (0.9 + 0.15 * k)
	var sweep: float = lerpf(-_half_angle * 0.4, _half_angle * 0.4, k)
	var a_lo: float = sweep - _half_angle
	var a_hi: float = sweep + _half_angle
	for j in range(3):
		var rr: float = outer * (1.0 - 0.16 * j)
		var c: Color = col
		c.a *= 1.0 - 0.28 * j
		draw_arc(Vector2.ZERO, rr, a_lo, a_hi, 28, c, 3.0 - j, true)
