extends Node
## 채집 자원 인벤토리 (오토로드 Inventory). 던전에서만 모이고 거점에서만 쓴다.
## Meta(영혼·강화)와 별개 파일에 저장: user://mabi_proto_inv.cfg

const SAVE_PATH := "user://mabi_proto_inv.cfg"

# kind: { name, color }  — 픽업 색/HUD 표시용
const KINDS := {
	"wood":  {"name": "목재", "color": Color(0.62, 0.42, 0.24)},
	"stone": {"name": "석재", "color": Color(0.58, 0.58, 0.64)},
	"herb":  {"name": "약초", "color": Color(0.42, 0.82, 0.45)},
	"ore":   {"name": "광석", "color": Color(0.78, 0.66, 0.36)},
}
const ORDER := ["wood", "stone", "herb", "ore"]

var counts: Dictionary = {}


func _ready() -> void:
	load_inv()


func amount(kind: String) -> int:
	return int(counts.get(kind, 0))


func add(kind: String, n: int) -> void:
	counts[kind] = amount(kind) + n
	save_inv()


func spend(kind: String, n: int) -> bool:
	if amount(kind) < n:
		return false
	counts[kind] -= n
	save_inv()
	return true


## 여러 자원을 한 번에 소모 (연구·건설 비용). cost = {"wood": 10, "ore": 3}
func can_afford(cost: Dictionary) -> bool:
	for k in cost:
		if amount(k) < int(cost[k]):
			return false
	return true


func pay(cost: Dictionary) -> bool:
	if not can_afford(cost):
		return false
	for k in cost:
		counts[k] -= int(cost[k])
	save_inv()
	return true


func reset() -> void:
	counts = {}
	save_inv()


func save_inv() -> void:
	var cf := ConfigFile.new()
	cf.set_value("inv", "counts", counts)
	cf.save(SAVE_PATH)


func load_inv() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		counts = cf.get_value("inv", "counts", {})
