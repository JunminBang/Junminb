extends RefCounted
## 무공(move) 데이터. 각 무공은 하나의 타격 = 콤보 체인의 한 칸.
## damage/knockback/range/half_angle(PI 이상=전방위) / windup(시전~판정) / recover(후딜)
## cancel_at(후딜 이 시점 지나면 다음 입력으로 캔슬 가능) / lunge(시전 중 전진속도)
## iframe / slow / cooldown(E 체인) / color/shake/hitstop

const MOVES := {
	# === 좌클릭 경공격 스트링 (l1 → l2 → l3) ===
	"l1": {"name": "횡베기", "damage": 8, "knockback": 130.0, "range": 66.0, "half_angle": 1.0,
		"windup": 0.05, "recover": 0.15, "cancel_at": 0.05, "lunge": 150.0,
		"color": Color(0.72, 0.86, 1.0), "shake": 3.0, "hitstop": 0.04},
	"l2": {"name": "연격", "damage": 10, "knockback": 150.0, "range": 66.0, "half_angle": 0.9,
		"windup": 0.05, "recover": 0.16, "cancel_at": 0.06, "lunge": 130.0,
		"color": Color(0.72, 0.86, 1.0), "shake": 3.0, "hitstop": 0.05},
	"l3": {"name": "마무리 베기", "damage": 17, "knockback": 320.0, "range": 78.0, "half_angle": 1.15,
		"windup": 0.08, "recover": 0.28, "cancel_at": 0.16, "lunge": 190.0,
		"color": Color(0.82, 0.92, 1.0), "shake": 6.0, "hitstop": 0.08},

	# === 우클릭 강공격 스트링 (r1 → r2) ===
	"r1": {"name": "내려찍기", "damage": 19, "knockback": 220.0, "range": 72.0, "half_angle": 0.6,
		"windup": 0.13, "recover": 0.22, "cancel_at": 0.11, "lunge": 90.0,
		"color": Color(1.0, 0.8, 0.5), "shake": 6.0, "hitstop": 0.07},
	"r2": {"name": "올려베기", "damage": 26, "knockback": 440.0, "range": 86.0, "half_angle": 0.85,
		"windup": 0.12, "recover": 0.32, "cancel_at": 0.2, "lunge": 150.0,
		"color": Color(1.0, 0.75, 0.4), "shake": 9.0, "hitstop": 0.1},

	# === E 기동기 (쿨다운, 무적) ===
	"e1": {"name": "질풍참", "damage": 24, "knockback": 320.0, "range": 78.0, "half_angle": 0.7,
		"windup": 0.1, "recover": 0.22, "cancel_at": 0.12, "lunge": 980.0, "iframe": true,
		"color": Color(0.9, 0.85, 0.5), "shake": 5.0, "hitstop": 0.07, "cooldown": 3.2},

	# === R 필살 (게이지, 무적, 화면 슬로우) ===
	"u1": {"name": "회천", "damage": 58, "knockback": 620.0, "range": 195.0, "half_angle": PI,
		"windup": 0.14, "recover": 0.5, "cancel_at": 0.3, "iframe": true, "slow": true,
		"color": Color(1.0, 0.6, 0.92), "shake": 14.0, "hitstop": 0.22},

	# === 교체용 무공 풀 (Loadout 에서 슬롯에 장착) ===
	"thrust": {"name": "찌르기", "damage": 14, "knockback": 110.0, "range": 118.0, "half_angle": 0.26,
		"windup": 0.06, "recover": 0.17, "cancel_at": 0.07, "lunge": 300.0,
		"color": Color(0.7, 0.9, 1.0), "shake": 3.0, "hitstop": 0.05},
	"cleave": {"name": "강타", "damage": 21, "knockback": 260.0, "range": 92.0, "half_angle": 1.5,
		"windup": 0.11, "recover": 0.26, "cancel_at": 0.14, "lunge": 100.0,
		"color": Color(0.9, 0.9, 1.0), "shake": 6.0, "hitstop": 0.07},
	"shockwave": {"name": "충격파", "damage": 16, "knockback": 470.0, "range": 132.0, "half_angle": PI,
		"windup": 0.09, "recover": 0.3, "cancel_at": 0.16,
		"color": Color(0.6, 1.0, 0.82), "shake": 7.0, "hitstop": 0.06},
	"bolt": {"name": "섬격", "damage": 12, "knockback": 170.0, "range": 250.0, "half_angle": 0.14,
		"windup": 0.05, "recover": 0.15, "cancel_at": 0.06,
		"color": Color(0.6, 0.85, 1.0), "shake": 2.0, "hitstop": 0.03},
	"spin": {"name": "회전베기", "damage": 15, "knockback": 300.0, "range": 96.0, "half_angle": PI,
		"windup": 0.1, "recover": 0.28, "cancel_at": 0.15, "lunge": 60.0,
		"color": Color(1.0, 0.85, 0.9), "shake": 6.0, "hitstop": 0.06},
	"lunge_pierce": {"name": "돌진 관통", "damage": 20, "knockback": 260.0, "range": 90.0, "half_angle": 0.5,
		"windup": 0.1, "recover": 0.2, "cancel_at": 0.1, "lunge": 1100.0, "iframe": true,
		"color": Color(0.85, 0.9, 0.6), "shake": 5.0, "hitstop": 0.07, "cooldown": 3.6},
}

const _FALLBACK := "l1"


static func get_move(id: String) -> Dictionary:
	return MOVES.get(id, MOVES[_FALLBACK]).duplicate()


static func name_of(id: String) -> String:
	return MOVES.get(id, {}).get("name", id)
