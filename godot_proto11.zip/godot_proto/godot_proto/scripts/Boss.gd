extends CharacterBody2D
## 보스: 2페이즈, 패턴 10종.
##   페이즈1 풀: charge / triple_charge / cone_slash / ring_aoe / cross_aoe
##   페이즈2 풀: + bullet_spray / homing_shots / summon / jump_slam / spin  (HP 50%에서 전환)
##
## 상태: INTRO → IDLE(패턴 선택) → TELE(예고) → ACT(실행) → RECOVER → IDLE
## 플레이어 공격은 "enemy" 그룹으로 들어오므로 그룹에 등록한다.

const ProjectileScript := preload("res://scripts/Projectile.gd")
const AoeWarningScript := preload("res://scripts/AoeWarning.gd")
const SlashEffect := preload("res://scripts/SlashEffect.gd")
const HitSpark := preload("res://scripts/HitSpark.gd")
const EnemyScene := preload("res://scenes/Enemy.tscn")

signal died

@export var max_health := 1050

var _first_pattern := true   # 첫 패턴은 반드시 느린 예고형 (오프닝 즉사 방지)

enum St { INTRO, IDLE, TELE, ACT, RECOVER, PHASE, DEAD }

const POOL_1 := ["charge", "triple_charge", "cone_slash", "ring_aoe", "cross_aoe"]
const POOL_2 := ["bullet_spray", "homing_shots", "summon", "jump_slam", "spin"]

var st: St = St.INTRO
var health: int
var phase := 1
var phased := false
var t := 0.0
var tick := 0.0
var seq := 0
var pattern := ""
var aim: Vector2 = Vector2.DOWN
var kb: Vector2 = Vector2.ZERO
var invuln := false
var player: Node2D
var arena_rect := Rect2(-430, -280, 860, 560)   # 방 로컬 이동 한계

var _charge_dir: Vector2 = Vector2.RIGHT
var _glow_tw: Tween

@onready var sprite: ColorRect = $Vis/Sprite
@onready var jelly: Node2D = $Vis
@onready var hpbar: ProgressBar = $HpBar


func _ready() -> void:
	add_to_group("enemy")   # 플레이어 타격 대상
	add_to_group("boss")
	health = max_health
	hpbar.max_value = max_health
	hpbar.value = health
	st = St.INTRO
	t = 1.2
	Sfx.play("tele")
	_glow(Color(2.0, 1.6, 0.5))


func _physics_process(delta: float) -> void:
	kb = kb.move_toward(Vector2.ZERO, 700.0 * delta)
	t -= delta
	if not is_instance_valid(player):
		player = get_tree().get_first_node_in_group("player")
	if is_instance_valid(player):
		aim = (player.global_position - global_position).normalized()

	match st:
		St.INTRO:
			velocity = Vector2.ZERO
			if t <= 0.0:
				st = St.IDLE
				t = 1.1
		St.IDLE:
			_drift()
			if t <= 0.0:
				_pick()
		St.TELE:
			velocity = Vector2.ZERO
			if t <= 0.0:
				_begin_act()
		St.ACT:
			_run_act(delta)
		St.RECOVER:
			velocity = velocity.move_toward(Vector2.ZERO, 500.0 * delta)
			if t <= 0.0:
				st = St.IDLE
				# 페이즈1은 패턴 사이 간격을 넉넉히 (반응할 틈). 페이즈2는 촘촘하게.
				t = randf_range(0.8, 1.25) if phase == 1 else randf_range(0.35, 0.7)
		St.PHASE:
			velocity = Vector2.ZERO
			if t <= 0.0:
				phase = 2
				invuln = false
				st = St.IDLE
				t = 0.4
		St.DEAD:
			velocity = Vector2.ZERO

	velocity += kb
	move_and_slide()
	position.x = clampf(position.x, arena_rect.position.x, arena_rect.end.x)
	position.y = clampf(position.y, arena_rect.position.y, arena_rect.end.y)
	hpbar.value = health


# ------------------------------------------------------------------ 이동/선택
func _drift() -> void:
	if not is_instance_valid(player):
		velocity = Vector2.ZERO
		return
	var to: Vector2 = player.global_position - global_position
	var d := to.length()
	if d > 340.0:
		velocity = to.normalized() * 80.0
	elif d < 190.0:
		velocity = -to.normalized() * 80.0
	else:
		velocity = to.orthogonal().normalized() * 70.0


func _pick() -> void:
	var pool: Array = POOL_1.duplicate()
	if phase == 2:
		pool += POOL_2
	if _first_pattern:
		_first_pattern = false
		pool = ["cone_slash", "ring_aoe"]   # 오프닝은 느린 예고형만
	pattern = pool[randi() % pool.size()]
	seq = 0
	tick = 0.0
	st = St.TELE
	t = _tele_time(pattern)
	_glow(Color(1.9, 1.5, 0.4))
	if pattern == "charge" or pattern == "triple_charge":
		_warn("cone", {"radius": 560.0, "half_angle": 0.13}, 0, t)
	elif pattern == "spin":
		_warn("circle", {"radius": 155.0}, 0, t)


func _tele_time(p: String) -> float:
	return _raw_tele_time(p) / (1.0 + Meta.cmod("boss_haste"))   # 계약 '쫓기는 자' = 예고 단축


func _raw_tele_time(p: String) -> float:
	var slow := 0.15 if phase == 1 else 0.0   # 페이즈1은 예고를 조금 더 길게
	match p:
		"charge": return 0.6 + slow
		"triple_charge": return 0.6 + slow
		"cone_slash": return 0.55 + slow
		"ring_aoe": return 0.85
		"cross_aoe": return 0.8
		"bullet_spray": return 0.7
		"homing_shots": return 0.6
		"summon": return 0.8
		"jump_slam": return 0.45
		"spin": return 0.7
	return 0.6


# ------------------------------------------------------------------ 실행
func _begin_act() -> void:
	_glow(Color.WHITE)
	st = St.ACT
	tick = 0.0
	match pattern:
		"charge":
			seq = 1
			_charge_dir = aim
			t = 0.32
			jelly.poke_dir(_charge_dir, 0.55)
		"triple_charge":
			seq = 2
			_charge_dir = aim
			t = 0.24
			jelly.poke_dir(_charge_dir, 0.55)
		"cone_slash":
			_do_cone_slash()
			t = 0.18
		"ring_aoe":
			_warn("donut", {"radius": 195.0, "thickness": 44.0}, 20, 0.4, global_position)
			t = 0.25
		"cross_aoe":
			_warn("cross", {"length": 720.0, "thickness": 44.0}, 20, 0.4, global_position)
			t = 0.25
		"bullet_spray":
			seq = 3
			t = 0.75
		"homing_shots":
			_spawn_homing()
			t = 0.3
		"summon":
			_do_summon()
			t = 0.3
		"jump_slam":
			seq = 1
			t = 0.5
			invuln = true
		"spin":
			t = 1.4


func _run_act(delta: float) -> void:
	match pattern:
		"charge", "triple_charge":
			velocity = _charge_dir * 780.0
			_contact(22 if pattern == "charge" else 15, _charge_dir, 340.0)
			if t <= 0.0:
				seq -= 1
				if seq > 0:
					_charge_dir = aim
					t = 0.26
					velocity = Vector2.ZERO
				else:
					_recover(0.5)
		"bullet_spray":
			velocity = Vector2.ZERO
			tick -= delta
			if tick <= 0.0 and seq > 0:
				tick = 0.22
				seq -= 1
				_ring_bullets(14, seq * 0.22)
			if t <= 0.0:
				_recover(0.5)
		"jump_slam":
			if is_instance_valid(player):
				global_position = global_position.lerp(player.global_position, 0.14)
			sprite.modulate = Color(1, 1, 1, 0.35)
			if t <= 0.0:
				sprite.modulate = Color.WHITE
				invuln = false
				_warn("circle", {"radius": 175.0}, 30, 0.28, global_position)
				Sfx.play("hit_heavy")
				Hitstop.shake(12.0)
				jelly.poke(0.75, -0.6)   # 착지: 납작하게 퍼짐
				_recover(0.6)
		"spin":
			_drift()
			tick -= delta
			if tick <= 0.0:
				tick = 0.18
				_spin_tick()
			if t <= 0.0:
				_recover(0.5)
		_:
			# cone_slash / ring_aoe / cross_aoe / homing_shots / summon: 즉발형, 대기만
			velocity = Vector2.ZERO
			if t <= 0.0:
				_recover(0.4)


func _recover(x: float) -> void:
	st = St.RECOVER
	t = x
	velocity = Vector2.ZERO


# ------------------------------------------------------------------ 패턴 헬퍼
func _contact(dmg: int, dir: Vector2, knockback: float) -> void:
	if is_instance_valid(player) and player.has_method("take_hit"):
		if global_position.distance_to(player.global_position) <= 64.0:
			player.take_hit(dmg, dir, knockback)


func _do_cone_slash() -> void:
	var fx := SlashEffect.new()
	add_child(fx)
	fx.setup(aim, 175.0, 1.0, Color(1, 0.5, 0.6), 0.2)
	Sfx.play("hit_heavy")
	Hitstop.hitstop(0.05, 0.08)
	Hitstop.shake(6.0)
	jelly.poke_dir(aim, 0.4)
	if is_instance_valid(player) and player.has_method("take_hit"):
		var v: Vector2 = player.global_position - global_position
		if v.length() <= 180.0 and absf(aim.angle_to(v)) <= 1.0:
			player.take_hit(24, v, 420.0)


func _spin_tick() -> void:
	var fx := SlashEffect.new()
	add_child(fx)
	fx.setup(Vector2.RIGHT, 150.0, PI, Color(1, 0.4, 0.5), 0.16)
	Sfx.play("whoosh")
	if is_instance_valid(player) and player.has_method("take_hit"):
		var v: Vector2 = player.global_position - global_position
		if v.length() <= 155.0:
			player.take_hit(14, v, 260.0)


func _ring_bullets(n: int, ang_off: float) -> void:
	for i in range(n):
		var ang := TAU * i / n + ang_off
		_bullet(global_position, Vector2(cos(ang), sin(ang)) * 235.0, 0.0, 10)
	Sfx.play("whoosh")


func _spawn_homing() -> void:
	for i in range(4):
		var ang := aim.angle() + randf_range(-0.7, 0.7)
		_bullet(global_position, Vector2(cos(ang), sin(ang)) * 165.0, 2.1, 12)
	Sfx.play("whoosh")


func _do_summon() -> void:
	for i in range(3):
		var e := EnemyScene.instantiate()
		e.weight = 0
		get_parent().add_child(e)
		e.position = position + Vector2(cos(TAU * i / 3), sin(TAU * i / 3)) * 100.0
	Sfx.play("tele")


func _bullet(pos: Vector2, vel: Vector2, homing: float, dmg: int) -> void:
	var b := Node2D.new()
	b.set_script(ProjectileScript)
	b.velocity = vel
	b.homing = homing
	b.damage = dmg
	get_parent().add_child(b)
	b.global_position = pos


func _warn(shape: String, params: Dictionary, dmg: int, tele: float, at: Vector2 = Vector2.INF) -> Node:
	var a := Node2D.new()
	a.set_script(AoeWarningScript)
	a.shape = shape
	a.aim = aim
	a.tele = tele
	a.damage = dmg
	for k in params:
		a.set(k, params[k])
	get_parent().add_child(a)
	a.global_position = global_position if at == Vector2.INF else at
	return a


# ------------------------------------------------------------------ 피격/사망
func take_hit(damage: int, dir: Vector2, knockback: float) -> void:
	if invuln or st == St.DEAD or st == St.INTRO:
		return
	health -= damage
	kb = dir.normalized() * knockback * 0.12
	jelly.poke(-0.24, 0.42)
	_flash()
	if not phased and health <= max_health / 2:
		_enter_phase_2()
	elif health <= 0:
		_die()


func _enter_phase_2() -> void:
	phased = true
	st = St.PHASE
	t = 1.3
	invuln = true
	health = int(max_health / 2)
	Sfx.play("death")
	Hitstop.hitstop(0.12, 0.1)
	Hitstop.shake(16.0)
	jelly.poke(0.55, 0.55)   # 페이즈 전환: 부풀었다가
	_glow(Color(2.2, 0.6, 0.6))


func _die() -> void:
	st = St.DEAD
	health = 0
	invuln = true
	hpbar.value = 0
	Sfx.play("death")
	Hitstop.hitstop(0.16, 0.08)
	Hitstop.shake(20.0)
	jelly.poke(0.9, -0.7)
	Meta.add_souls(70)
	for i in range(7):
		var s := HitSpark.new()
		get_parent().add_child(s)
		s.global_position = global_position + Vector2(randf_range(-42, 42), randf_range(-42, 42))
		s.setup(Color(1, 0.7, 0.5), 52.0)
	died.emit()
	await get_tree().create_timer(0.5).timeout
	queue_free()


func _flash() -> void:
	sprite.color = Color(1, 1, 1)
	var tw := create_tween()
	tw.tween_property(sprite, "color", Color(0.72, 0.2, 0.45), 0.09)


func _glow(c: Color) -> void:
	if _glow_tw and _glow_tw.is_valid():
		_glow_tw.kill()
	sprite.modulate = c
	_glow_tw = create_tween()
	_glow_tw.tween_property(sprite, "modulate", Color.WHITE, 0.5)
