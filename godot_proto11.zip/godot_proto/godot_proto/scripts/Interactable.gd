extends Area2D
## 거점 스테이션 — 근처에 플레이어가 오면 프롬프트를 띄우고, F 를 누르면 triggered(id) 발신.

signal triggered(id: String)

var id := ""
var label_text := ""
var tint: Color = Color(0.7, 0.7, 0.7)
var _near := false

@onready var _marker: ColorRect = $Marker
@onready var _prompt: Label = $Prompt


func _ready() -> void:
	_marker.color = tint
	_prompt.text = "[F] " + label_text
	_prompt.visible = false
	body_entered.connect(_on_enter)
	body_exited.connect(_on_exit)


func _on_enter(b: Node) -> void:
	if b.is_in_group("player"):
		_near = true
		_prompt.visible = true


func _on_exit(b: Node) -> void:
	if b.is_in_group("player"):
		_near = false
		_prompt.visible = false


func _unhandled_input(e: InputEvent) -> void:
	if _near and e.is_action_pressed(&"interact"):
		triggered.emit(id)
