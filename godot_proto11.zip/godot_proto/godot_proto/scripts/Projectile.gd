extends Node2D
## 보스 투사체. Area2D 없이 매 프레임 플레이어와의 거리로 판정한다.
## velocity / homing(초당 회전) / lifetime / damage 를 세팅하고 씬에 add_child.

const HitSpark := preload("res://scripts/HitSpark.gd")

var velocity: Vector2 = Vector2.ZERO
var homing := 0.0
var damage := 10
var knockback := 260.0
var lifetime := 3.5
var radius := 8.0
var color := Color(1.0, 0.5, 0.3)
var _t := 0.0


func _ready() -> void:
	add_to_group("hazard")


func _physics_process(delta: float) -> void:
	_t += delta
	if _t >= lifetime:
		queue_free()
		return
	var p: Node2D = get_tree().get_first_node_in_group("player")
	if homing > 0.0 and is_instance_valid(p):
		var want: Vector2 = (p.global_position - global_position).normalized()
		var step := clampf(velocity.angle_to(want), -homing * delta, homing * delta)
		velocity = velocity.rotated(step)
	global_position += velocity * delta
	queue_redraw()
	if is_instance_valid(p) and global_position.distance_to(p.global_position) <= radius + 14.0:
		if p.has_method("take_hit"):
			p.take_hit(damage, velocity.normalized(), knockback)
		var s := HitSpark.new()
		get_parent().add_child(s)
		s.global_position = global_position
		s.setup(color.lerp(Color.WHITE, 0.5), 24.0)
		Sfx.play("hit_light")
		queue_free()


func _draw() -> void:
	var k := _t / lifetime
	var c := color
	c.a = 1.0 - 0.55 * k
	draw_circle(Vector2.ZERO, radius, c)
	draw_arc(Vector2.ZERO, radius + 3.0, 0.0, TAU, 16, Color(1, 1, 1, 0.5 * (1.0 - k)), 1.5)
