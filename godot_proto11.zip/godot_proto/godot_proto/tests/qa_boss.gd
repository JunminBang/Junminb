extends Node
## 보스전 밸런스 QA — 여러 빌드로 보스방에서 바로 싸워 격파 가능 여부 / 도달한 보스 HP% 를 잰다.
## (일반 방 1~4는 qa_balance 에서 모든 빌드가 통과 확인됨 → 여기선 보스만.)

const PER_TRY := 190.0
const TRIES := 2   # 스쿼시 빌드는 봇 회피 RNG 편차가 커서 2회 시도, 최선 기록

# 약한 빌드(6레벨, 첫 도전자) + 현실적 빌드(9~10레벨, 몇 방 더 돈 뒤)
const BUILDS := [
	{"name": "무강화(0)",       "lv": {}},
	{"name": "아머탱(6)",       "lv": {"max_hp": 2, "armor": 2, "vigor": 2}},
	{"name": "흡혈브루저(6)",   "lv": {"lifesteal": 2, "damage": 2, "berserk": 1, "armor": 1}},
	{"name": "글래스캐논(6)",   "lv": {"damage": 2, "haste": 2, "combo_blast": 1, "ult_double": 1}},
	{"name": "탱 종합(10)",     "lv": {"max_hp": 2, "armor": 2, "vigor": 2, "iframe": 2, "lifesteal": 2}},
	{"name": "밸런스 종합(9)",  "lv": {"armor": 1, "damage": 2, "haste": 2, "swift": 1, "lifesteal": 1, "dash_slash": 1, "berserk": 1}},
]

var arena: Node2D
var p: Node2D
var _bi := -1
var _try := 0
var _lv := {}
var _t := 0.0
var _try_start := 0.0
var _min_hp_pct := 100.0
var _results: Array = []
var _busy := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_watchdog()
	_next()


func _next() -> void:
	_try += 1
	if _bi < 0 or _try > TRIES:
		_bi += 1
		_try = 1
		if _bi >= BUILDS.size():
			_report()
			return
		_lv = BUILDS[_bi]["lv"]
		_min_hp_pct = 100.0
	_try_start = _t
	await _spawn()


func _spawn() -> void:
	_busy = true
	if is_instance_valid(arena):
		arena.queue_free()
		await get_tree().physics_frame
	get_tree().paused = false
	Meta.reset()
	Research.reset()
	Loadout.reset()
	Meta.levels = _lv.duplicate()
	arena = load("res://scenes/Main.tscn").instantiate()
	add_child(arena)
	await get_tree().physics_frame
	await get_tree().physics_frame
	p = arena.get_node("Player")
	p.global_position = arena.rooms[5].global_position   # 보스방 순간이동
	_busy = false


func _physics_process(delta: float) -> void:
	_t += delta
	if _busy or not is_instance_valid(p):
		return

	if arena._boss_dead:
		_record("격파", 0.0)
		return
	if p.dead:
		_record("사망", _min_hp_pct)
		return
	if _t - _try_start > PER_TRY:
		_record("시간초과", _min_hp_pct)
		return

	# 보스 스폰 대기 / 이동
	var b = arena.rooms[5].boss
	if not is_instance_valid(b):
		p.move_target = arena.rooms[5].global_position
		p.has_move_target = true
		return
	_min_hp_pct = minf(_min_hp_pct, 100.0 * float(b.health) / float(b.max_health))

	var to: Vector2 = b.global_position - p.global_position
	var d := to.length()
	var dir := to.normalized() if d > 1.0 else Vector2.RIGHT

	if p.dash_cd_timer <= 0.0 and not p.invulnerable:
		var dg := _danger(b)
		if dg != Vector2.ZERO or float(p.hp) < float(p.max_hp) * 0.6:
			var ddv: Vector2 = dg if dg != Vector2.ZERO else -dir
			p.aim_at(p.global_position + ddv.normalized() * 100.0)
			p._buffer("DASH")
			return

	if d > 250.0:
		p.move_target = b.global_position
		p.has_move_target = true
	elif d < 195.0:
		p.move_target = p.global_position - dir * 140.0
		p.has_move_target = true
	else:
		p.has_move_target = false

	p.aim_at(b.global_position)
	if p.ultimate_gauge >= p.GAUGE_MAX:
		p._buffer("U")
	elif p.e_cd_timer <= 0.0 and d > 55.0:
		p._buffer("E")
	elif d < 100.0:
		p._buffer("R")
	else:
		p._buffer("L")


func _danger(b) -> Vector2:
	for h in get_tree().get_nodes_in_group("hazard"):
		if not is_instance_valid(h):
			continue
		var off: Vector2 = p.global_position - h.global_position
		if h.has_method("_contains"):
			if h._t / maxf(0.01, h.tele) > 0.35 and h._contains(p.global_position):
				return off.normalized() if off.length() > 1.0 else Vector2.RIGHT
		elif off.length() < 135.0:
			return Vector2(-h.velocity.y, h.velocity.x).normalized()
	if is_instance_valid(b) and (b.st == b.St.TELE or b.st == b.St.ACT):
		if p.global_position.distance_to(b.global_position) < 250.0:
			return (p.global_position - b.global_position).normalized()
	return Vector2.ZERO


func _record(outcome: String, hp_pct: float) -> void:
	var dur := _t - _try_start
	print("  %-14s 시도 %d → %-9s (보스 HP 최저 %.0f%%, %.0fs)" %
		[BUILDS[_bi]["name"], _try, outcome, hp_pct, dur])
	if _try >= TRIES or outcome == "격파":
		_results.append({"name": BUILDS[_bi]["name"],
			"best": "격파" if outcome == "격파" else "%.0f%%" % _min_hp_pct,
			"killed": outcome == "격파"})
		_try = TRIES   # 다음 _next 에서 빌드 넘어감
	_next()


func _report() -> void:
	set_physics_process(false)
	var lines: Array = ["", "=== 보스전 QA 결과 (빌드별 최선) ===", "빌드            | 보스전 결과"]
	var cant := []
	for r in _results:
		lines.append("%-16s | %s" % [r["name"], "격파 ✅" if r["killed"] else "보스 HP %s 까지 (미격파)" % r["best"]])
		if not r["killed"]:
			cant.append(r["name"])
	lines.append("")
	if cant.is_empty():
		lines.append("→ 모든 빌드로 봇이 보스 격파. 밸런스 OK.")
	else:
		lines.append("→ 봇이 격파 못한 빌드: %s" % ", ".join(cant))
		lines.append("  (봇 회피 실력 한계도 있음 — HP% 가 20 근처면 사람은 클리어 가능한 수준)")
	print("\n".join(lines))
	Meta.reset()
	get_tree().quit(0)


func _watchdog() -> void:
	await get_tree().create_timer(3600.0).timeout
	_report()
