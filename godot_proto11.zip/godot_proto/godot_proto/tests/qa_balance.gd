extends Node
## 밸런스 QA — 여러 고정 빌드로 게임을 자동 플레이해서 클리어 가능 여부를 표로 뽑는다.
## 각 빌드는 처음부터 그 강화만 보유(구매 없음), 죽으면 같은 빌드로 재시작.
## 실행: godot --headless --path . res://tests/qa_balance.tscn   (오래 걸림 — 백그라운드 권장)

const DEATH_CAP := 7
const PER_BUILD_SECONDS := 260.0   # 저DPS 탱커는 풀 건틀릿(방6+보스)에 시간이 더 걸림 — 보스전 QA로 격파력은 이미 확인됨
const HARD_LIMIT := 2400.0

# 대략 6레벨 예산으로 맞춘 아키타입들 + 바닥(무강화) + 천장(풀강)
const BUILDS := [
	{"name": "무강화 (바닥)",   "lv": {}},
	{"name": "HP+아머 순수탱",  "lv": {"max_hp": 2, "armor": 2, "vigor": 2}},
	{"name": "회피 탱커",       "lv": {"iframe": 2, "vigor": 1, "swift": 2, "lifesteal": 1}},
	{"name": "글래스캐논",      "lv": {"damage": 2, "haste": 2, "combo_blast": 1, "ult_double": 1}},
	{"name": "흡혈 브루저",     "lv": {"lifesteal": 2, "damage": 2, "berserk": 1, "armor": 1}},
	{"name": "기동전 (잔영검)", "lv": {"swift": 2, "iframe": 2, "dash_slash": 1, "haste": 1}},
	{"name": "얕고 넓게",       "lv": {"max_hp": 1, "armor": 1, "damage": 1, "haste": 1, "lifesteal": 1, "swift": 1}},
	{"name": "풀강 (천장)",     "lv": {"max_hp": 2, "armor": 2, "vigor": 2, "iframe": 2, "damage": 2, "haste": 2,
		"swift": 2, "lifesteal": 2, "dash_slash": 1, "ult_double": 1, "combo_blast": 1, "berserk": 1}},
	# --- 계약을 걸고도 클리어 가능한지 ---
	{"name": "계약:쇄도(6)",   "lv": {"damage": 2, "haste": 2, "swift": 1, "armor": 1}, "contract": "swarm"},
	{"name": "계약:정예(9)",   "lv": {"max_hp": 2, "armor": 2, "damage": 2, "haste": 2, "lifesteal": 1}, "contract": "elite"},
	{"name": "계약:유리심장(8)", "lv": {"iframe": 2, "swift": 2, "damage": 2, "lifesteal": 2}, "contract": "glass"},
]

var arena: Node2D
var p: Node2D
var _bi := -1
var _build_lv := {}
var _t := 0.0
var _build_start := 0.0
var _deaths := 0
var _best := 0
var _hit_boss := false   # 이 빌드로 보스방에 한 번이라도 도달했으면, 사망 재시작 시 보스방으로 바로 복귀
var _results: Array = []
var _busy := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_watchdog()
	_next_build()


func _next_build() -> void:
	_bi += 1
	if _bi >= BUILDS.size():
		_report()
		return
	_build_lv = BUILDS[_bi]["lv"]
	_deaths = 0
	_best = 0
	_hit_boss = false
	_build_start = _t
	await _spawn()


func _spawn() -> void:
	_busy = true
	if is_instance_valid(arena):
		arena.queue_free()
		await get_tree().physics_frame
	get_tree().paused = false
	Meta.reset()
	Research.reset()
	Loadout.reset()
	Meta.levels = _build_lv.duplicate()
	Meta.set_contract(BUILDS[_bi].get("contract", ""))
	arena = load("res://scenes/Main.tscn").instantiate()
	add_child(arena)
	await get_tree().physics_frame
	await get_tree().physics_frame
	p = arena.get_node("Player")
	if _hit_boss:
		p.global_position = arena.rooms[arena.rooms.size() - 1].global_position   # 보스방 복귀
	_busy = false


func _physics_process(delta: float) -> void:
	_t += delta
	if _busy or not is_instance_valid(p):
		return

	# ② 분기 선택 대기 중이면 자동으로 첫 번째 경로 선택
	if arena._branch_pending_from >= 0:
		arena.bot_pick_branch()
		return

	if _t - _build_start > PER_BUILD_SECONDS:
		_finish_build("시간초과")
		return

	if arena._boss_dead:
		_finish_build("클리어")
		return

	if p.dead:
		_deaths += 1
		if _deaths > DEATH_CAP:
			_finish_build("사망 %d회" % DEATH_CAP)
			return
		_spawn()   # 같은 빌드로 재시작 (구매 없음)
		return

	var ri: int = arena._reached
	_best = maxi(_best, ri)
	var room: Node = arena.rooms[ri]
	if room.is_boss:
		_hit_boss = true

	if room.is_boss and is_instance_valid(room.boss):
		_act(room.boss, true)
	else:
		var foe: Node2D = _nearest(room)
		if foe:
			_act(foe, false)
		elif ri + 1 < arena.rooms.size():
			p.move_target = arena.rooms[ri + 1].global_position
			p.has_move_target = true


func _act(target: Node2D, is_boss: bool) -> void:
	var to: Vector2 = target.global_position - p.global_position
	var d := to.length()
	var dir := to.normalized() if d > 1.0 else Vector2.RIGHT

	if p.dash_cd_timer <= 0.0 and not p.invulnerable:
		var dg := _danger(is_boss)
		var flee := float(p.hp) < float(p.max_hp) * (0.45 if is_boss else 0.28)
		if dg != Vector2.ZERO or flee:
			var ddv: Vector2 = dg if dg != Vector2.ZERO else -dir
			p.aim_at(p.global_position + ddv.normalized() * 100.0)
			p._buffer("DASH")
			return

	var want := 210.0 if is_boss else 70.0
	if d > want + 20.0:
		p.move_target = target.global_position
		p.has_move_target = true
	elif is_boss and d < want - 35.0:
		p.move_target = p.global_position - dir * 120.0
		p.has_move_target = true
	else:
		p.has_move_target = false

	p.aim_at(target.global_position)
	if p.ultimate_gauge >= p.GAUGE_MAX:
		p._buffer("U")
	elif p.e_cd_timer <= 0.0 and d > 55.0:
		p._buffer("E")
	elif d < 100.0:
		p._buffer("R")
	else:
		p._buffer("L")


func _danger(is_boss: bool) -> Vector2:
	var pr := 120.0 if is_boss else 78.0
	for h in get_tree().get_nodes_in_group("hazard"):
		if not is_instance_valid(h):
			continue
		var off: Vector2 = p.global_position - h.global_position
		if h.has_method("_contains"):
			if h._t / maxf(0.01, h.tele) > 0.4 and h._contains(p.global_position):
				return off.normalized() if off.length() > 1.0 else Vector2.RIGHT
		elif off.length() < pr:
			return Vector2(-h.velocity.y, h.velocity.x).normalized()
	if is_boss:
		var b: Node = arena.rooms[arena._reached].boss
		if is_instance_valid(b) and (b.st == b.St.TELE or b.st == b.St.ACT):
			if p.global_position.distance_to(b.global_position) < 235.0:
				return (p.global_position - b.global_position).normalized()
	return Vector2.ZERO


func _nearest(room: Node) -> Node2D:
	var best: Node2D = null
	var bd := 1e9
	var b: Rect2 = room.bounds()
	for e in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(e) or e.is_in_group("boss") or not b.has_point(e.global_position):
			continue
		var dd: float = p.global_position.distance_squared_to(e.global_position)
		if dd < bd:
			bd = dd
			best = e
	return best


func _finish_build(outcome: String) -> void:
	var dur := _t - _build_start
	_results.append({"name": BUILDS[_bi]["name"], "out": outcome, "best": _best, "deaths": _deaths, "dur": dur})
	print("  [%2d/%d] %-16s → %s  (방 %d, 사망 %d, %.0fs)" %
		[_bi + 1, BUILDS.size(), BUILDS[_bi]["name"], outcome, _best, _deaths, dur])
	_next_build()


func _report() -> void:
	set_physics_process(false)
	var lines: Array = ["", "=== 밸런스 QA 결과 ===", "빌드                | 결과       | 최고방 | 사망 | 시간"]
	var fails := 0
	for r in _results:
		if r["out"] != "클리어":
			fails += 1
		lines.append("%-18s | %-9s | %d      | %d    | %.0fs" %
			[r["name"], r["out"], r["best"], r["deaths"], r["dur"]])
	lines.append("")
	lines.append("클리어 %d / %d.  %s" % [_results.size() - fails, _results.size(),
		"모든 유효 빌드 클리어 가능" if fails <= 1 else "클리어 불가 빌드 %d개 — 밸런스 확인 필요" % fails])
	print("\n".join(lines))
	Meta.reset()
	get_tree().quit(0 if fails <= 1 else 1)


func _watchdog() -> void:
	await get_tree().create_timer(HARD_LIMIT).timeout
	_report()
