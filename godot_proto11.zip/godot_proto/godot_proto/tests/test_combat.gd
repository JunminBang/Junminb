extends Node
## 최소 런타임 자체검증 (WASD + 콤보 체인).
## 실행: godot --headless --path . res://tests/test_combat.tscn   (성공 시 exit 0)

const PlayerScene := preload("res://scenes/Player.tscn")
const EnemyScene := preload("res://scenes/Enemy.tscn")
const Moves := preload("res://scripts/Moves.gd")


func _ready() -> void:
	_watchdog()
	Meta.reset()
	Inventory.reset()
	Research.reset()
	Loadout.reset()

	var p := PlayerScene.instantiate()
	add_child(p)
	await _f(2)
	var start: Vector2 = p.global_position

	# --- 1. WASD 이동 ---
	Input.action_press(&"move_right")
	await _f(20)
	assert(p.global_position.distance_to(start) > 8.0, "WASD 이동이 안 됨")
	assert(p.jelly.scale.distance_to(Vector2.ONE) > 0.01, "이동 중 젤리 변형 없음")
	Input.action_release(&"move_right")

	# --- 1b. 봇용 move_target 오버라이드 ---
	await _idle(p)
	var here: Vector2 = p.global_position
	p.move_target = here + Vector2(200, 0)
	p.has_move_target = true
	await _f(25)
	assert(p.global_position.distance_to(here) > 8.0, "move_target 오버라이드 이동 실패")
	p.has_move_target = false

	# --- 2. 좌클릭 연타 = 경공격 체인이 끝까지 진행 (l1→l2→l3, 이후 유지) ---
	await _idle(p)
	p._buffer("L")
	await _f(2)
	assert(p.state != p.State.IDLE, "좌클릭 체인이 시전 안 됨")
	assert(p.chain_ptr["L"] == 1, "1타 포인터 이상 (%d)" % p.chain_ptr["L"])
	for press in 4:
		p._buffer("L")
		await _f(7)
	assert(p.chain_ptr["L"] == 3, "L 연타로 체인이 끝까지 안 감 (ptr=%d)" % p.chain_ptr["L"])

	# --- 3. 체인 리셋: 입력 없으면 포인터 0 ---
	await _idle(p)
	for i in 55:  # CHAIN_RESET(0.7) 초과
		await get_tree().physics_frame
	assert(p.chain_ptr["L"] == 0, "무입력 후 체인이 리셋 안 됨")

	# --- 4. 크로스 캔슬: L 후딜 중 R 입력 → R 체인으로 ---
	await _idle(p)
	p._buffer("L")
	await _f(5)   # windup 지나 recover 진입
	p._buffer("R")
	for i in 16:
		await get_tree().physics_frame
		if p.chain_ptr["R"] >= 1:
			break
	assert(p.chain_ptr["R"] >= 1, "크로스 캔슬로 R 체인 진입 실패")

	# --- 5. Shift 대시 (무적) ---
	await _idle(p)
	p._buffer("DASH")
	await _f(2)
	assert(p.state == p.State.DASH or p.dash_cd_timer > 0.0, "대시가 안 됨")
	assert(p.invulnerable or p.dash_cd_timer > 0.0, "대시 중 무적이 아님")
	await _idle(p)

	# --- 6. E 체인 = 쿨다운 ---
	await _idle(p)
	p._buffer("E")
	await _f(3)
	assert(p.e_cd_timer > 0.0, "E 사용 후 쿨다운이 안 걸림")
	p._buffer("E")   # 쿨 도는 중 재입력 → 무시
	await _f(3)
	assert(p.state == p.State.ACT or p.state == p.State.RECOVER or p.e_cd_timer > 0.0, "E 상태 이상")

	# --- 7. 필살(U): 게이지 100%에서 발동하며 소모 ---
	await _idle(p)
	p.ultimate_gauge = p.GAUGE_MAX
	p._buffer("U")
	await _f(3)
	assert(p.ultimate_gauge < p.GAUGE_MAX, "필살 발동 후 게이지가 안 줄음")

	# --- 8. 피격: HP -armor / 게이지 증가 ---
	await _idle(p)
	p.hp = p.max_hp
	p.invulnerable = false
	p.hurt_timer = 0.0
	var g0: float = p.ultimate_gauge
	p.take_hit(10, Vector2.RIGHT, 200.0)
	assert(p.hp == p.max_hp - 10, "피격 시 HP 가 안 깎임")
	assert(p.ultimate_gauge > g0, "피격 시 게이지가 안 참")

	# --- 9. 무적 프레임 ---
	p.hp = p.max_hp
	p.hurt_timer = 0.0
	p.invulnerable = true
	p.take_hit(10, Vector2.RIGHT, 200.0)
	assert(p.hp == p.max_hp, "무적 중인데 피해를 받음")
	p.invulnerable = false

	# --- 10. 넉백 3단계 + 스턴락 방지 (Enemy) ---
	var light := EnemyScene.instantiate(); light.weight = 0; add_child(light)
	var fixed := EnemyScene.instantiate(); fixed.weight = 2; add_child(fixed)
	await get_tree().physics_frame
	light.take_hit(5, Vector2.RIGHT, 300.0)
	fixed.take_hit(5, Vector2.RIGHT, 300.0)
	assert(light.knockback.length() > fixed.knockback.length() + 50.0, "체급별 넉백 차등 안 됨")
	var lock := EnemyScene.instantiate(); lock.weight = 0; add_child(lock)
	await get_tree().physics_frame
	var escaped := false
	for i in 45:
		lock.take_hit(0, Vector2.RIGHT, 60.0)
		await _f(2)
		if lock.st != lock.S.HURT and lock.stagger_immune > 0.0:
			escaped = true
			break
	assert(escaped, "연타로 적이 경직에서 못 벗어남")
	p.queue_free(); light.queue_free(); fixed.queue_free(); lock.queue_free()
	await get_tree().physics_frame

	# --- 11. 몬스터가 플레이어를 때린다 + 사망 시그널 ---
	var p2 := PlayerScene.instantiate(); add_child(p2); p2.position = Vector2(2000, 0)
	var foe := EnemyScene.instantiate(); foe.weight = 0; add_child(foe)
	foe.position = p2.position + Vector2(36, 0)
	await get_tree().physics_frame
	var hp0: int = p2.hp
	for i in 120:
		await get_tree().physics_frame
	assert(p2.hp < hp0, "몬스터가 플레이어를 못 때림 (%d->%d)" % [hp0, p2.hp])
	var got_died := [false]
	p2.died.connect(func(): got_died[0] = true)
	p2.hp = 3; p2.invulnerable = false; p2.hurt_timer = 0.0
	p2.take_hit(999, Vector2.RIGHT, 0.0)
	assert(p2.dead and got_died[0], "사망 처리/시그널 이상")
	p2.queue_free(); foe.queue_free()
	await get_tree().physics_frame

	# --- 12. 메타 성장: 구매 / 비용 증가 / 플레이어 반영 ---
	Meta.reset(); Meta.souls = 300
	var c0 := Meta.cost("max_hp")
	assert(Meta.buy("max_hp"), "구매 실패")
	assert(Meta.level("max_hp") == 1 and is_equal_approx(Meta.bonus("max_hp"), 18.0), "메타 계산 오류")
	assert(Meta.cost("max_hp") > c0, "구매 후 비용 안 오름")
	var p3 := PlayerScene.instantiate(); add_child(p3)
	await get_tree().physics_frame
	assert(p3.max_hp >= 118, "메타 최대체력이 반영 안 됨 (%d)" % p3.max_hp)

	# --- 13. combo_blast: 좌클릭 마무리(l3)가 전방위 ---
	Meta.reset()
	p3._combo_blast = true
	p3.chains = {"L": ["l1", "l2", "l3"], "R": ["r1"], "E": ["e1"], "U": ["u1"]}
	p3._active_chain = "L"
	p3._current_is_last = true
	p3._start_act(Moves.get_move("l3"))
	assert(p3.current.get("half_angle", 0.0) >= PI, "파쇄격인데 마무리가 전방위가 아님")
	p3.queue_free()
	await get_tree().physics_frame

	# --- 14. 영혼 드랍 획득 ---
	Meta.reset(); Inventory.reset()
	var pw := PlayerScene.instantiate(); add_child(pw); pw.global_position = Vector2(6000, 0)
	await get_tree().physics_frame
	var foec := EnemyScene.instantiate(); foec.weight = 1; add_child(foec)
	foec.global_position = pw.global_position + Vector2(26, 0)
	await get_tree().physics_frame
	foec.take_hit(9999, Vector2.RIGHT, 0.0)
	var sb := Meta.souls
	for i in 150:
		await get_tree().physics_frame
	assert(Meta.souls > sb, "영혼 획득 실패")
	pw.queue_free()
	await get_tree().physics_frame
	Meta.reset(); Inventory.reset()

	# --- 15. 제단(Altar): 열기 / 리롤 / 구매 ---
	Meta.reset(); Meta.souls = 500
	var altar := CanvasLayer.new()
	altar.set_script(load("res://scripts/Altar.gd"))
	add_child(altar)
	await get_tree().physics_frame
	altar.open_shop()
	assert(altar.visible and get_tree().paused, "제단이 안 열림")
	assert(Meta.offer.size() == 3, "오퍼 3종이 아님")
	var arc: int = altar._reroll_cost()
	var as0: int = Meta.souls
	altar._do_reroll()
	assert(Meta.souls == as0 - arc, "리롤이 영혼을 안 씀")
	var apick: String = Meta.offer[0]
	var alv0: int = Meta.level(apick)
	altar._buy(apick)
	assert(Meta.level(apick) == alv0 + 1, "제단 구매 실패")
	altar._close_shop()
	assert(not altar.visible and not get_tree().paused, "제단이 안 닫힘")
	altar.queue_free()

	# --- 16. 연구: 강화 해금 + 무공 해금 + 패시브 ---
	Meta.reset(); Research.reset(); Inventory.reset()
	Meta.souls = 300
	Meta.roll_offer()
	assert(not Meta._available().has("dash_slash"), "연구 전 dash_slash 가 오퍼 풀에 있음")
	assert(not Loadout.pool_for("L").has("thrust"), "연구 전 thrust 가 로드아웃 후보에 있음")
	assert(Research.research("blade_arts"), "blade_arts 연구 실패")
	assert(Meta._available().has("dash_slash"), "해금됐는데 오퍼 풀에 안 들어옴")
	assert(Research.research("form_thrust"), "form_thrust 연구 실패")
	assert(Loadout.pool_for("L").has("thrust"), "무공 해금이 로드아웃 후보에 반영 안 됨")
	Research.research("toughness")
	var pr := PlayerScene.instantiate(); add_child(pr)
	await get_tree().physics_frame
	assert(pr._armor >= 1, "연구 패시브(armor)가 반영 안 됨")
	pr.queue_free()

	# --- 17. 로드아웃: 슬롯 교체 ---
	Loadout.reset()
	assert(Loadout.get_chains()["L"] == ["l1", "l2", "l3"], "기본 로드아웃 이상")
	Loadout.set_slot("L", 0, "thrust")   # thrust 는 해금됨(16번에서)
	assert(Loadout.get_chains()["L"][0] == "thrust", "로드아웃 슬롯 교체 실패")
	var pl := PlayerScene.instantiate(); add_child(pl)
	await get_tree().physics_frame
	assert(pl.chains["L"][0] == "thrust", "플레이어가 교체된 로드아웃을 안 씀")
	pl.queue_free()

	# --- 18. 각성: 같은 태그 레벨 합 4 이상이면 발동 + Player 에 반영 ---
	Meta.reset(); Research.reset(); Loadout.reset()
	Meta.levels = {"damage": 2, "haste": 2}           # offense 합 4
	assert(Meta.awakened("offense"), "offense 각성 안 됨 (합4)")
	assert(not Meta.awakened("defense"), "defense 가 왜 각성됨")
	var pa := PlayerScene.instantiate(); add_child(pa)
	await get_tree().physics_frame
	assert("offense" in pa._awakened, "Player 가 각성 태그 반영 안 함")
	var dm_base := 1.0 + Meta.bonus("damage")
	assert(pa._damage_mult > dm_base + 0.2, "offense 각성 데미지 보너스 미적용 (%.2f)" % pa._damage_mult)
	pa.queue_free()

	Meta.reset()
	Meta.levels = {"damage": 1, "haste": 1, "swift": 1}   # 어느 태그도 4 미만
	assert(Meta.awakened_tags().is_empty(), "얕게 퍼진 빌드가 각성됨")

	# --- 19. 계약: cmod / creward + Enemy·Player 에 반영 ---
	Meta.reset()
	Meta.set_contract("elite")                       # 적 체력 +50%, 보상 +50%
	assert(is_equal_approx(Meta.cmod("enemy_hp"), 0.5), "계약 cmod 오류")
	assert(is_equal_approx(Meta.creward("souls"), 1.5), "계약 creward 오류")
	var EnemyScene: PackedScene = load("res://scenes/Enemy.tscn")
	var e0: Node2D = EnemyScene.instantiate(); add_child(e0)
	await get_tree().physics_frame
	assert(e0.max_health >= 44, "정예 계약 적 체력 증가 미적용 (%d)" % e0.max_health)  # LIGHT 30 * 1.5 = 45
	e0.queue_free()
	Meta.set_contract("frail")                       # 플레이어 피해 -20%
	var pc := PlayerScene.instantiate(); add_child(pc)
	await get_tree().physics_frame
	assert(pc._damage_mult < 1.0, "무딘 칼 계약 피해 감소 미적용 (%.2f)" % pc._damage_mult)
	pc.queue_free()
	Meta.set_contract("")
	assert(Meta.cmod("enemy_hp") == 0.0 and Meta.creward("souls") == 1.0, "계약 해제 후에도 수정치 남음")

	# --- 20. Lore: 결정론적 마일스톤 + 대사 순환 ---
	Lore.reset()
	assert(Lore.rescued.is_empty(), "Lore reset 후에도 NPC 남음")
	var got := Lore.on_run_cleared(false)            # 첫 클리어(계약 없음)
	assert("smith" in got and "smith" in Lore.rescued, "첫 클리어에 대장장이 구출 안 됨")
	assert(not Lore.rescued.has("scholar"), "계약 없이 클리어했는데 기록자 구출됨")
	Lore.on_run_cleared(true)                        # 계약 클리어
	assert(Lore.rescued.has("scholar"), "계약 클리어 후 기록자 구출 안 됨")
	var l1 := Lore.next_line("smith"); var l2 := Lore.next_line("smith")
	assert(l1 != l2, "NPC 대사가 안 넘어감")
	Lore.reset()

	Meta.reset(); Research.reset(); Inventory.reset(); Loadout.reset()
	print("test_combat: OK")
	get_tree().quit(0)


func _f(n: int) -> void:
	for i in n:
		await get_tree().physics_frame


func _idle(p: Node) -> void:
	for i in 150:
		await get_tree().physics_frame
		if p.state == p.State.IDLE and p.hurt_timer <= 0.0:
			return


func _wait_for_recover(p: Node) -> void:
	for i in 30:
		await get_tree().physics_frame
		if p.state == p.State.RECOVER or p.state == p.State.IDLE:
			return


func _watchdog() -> void:
	await get_tree().create_timer(50.0).timeout
	push_error("test_combat: WATCHDOG TIMEOUT")
	get_tree().quit(2)
