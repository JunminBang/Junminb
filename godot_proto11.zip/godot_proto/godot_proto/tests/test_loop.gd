extends Node
## 거점 ↔ 던전 루프 스모크 테스트 (Game.tscn).
## 거점 로드 → 던전 입장 → 보스 처치 → 거점 복귀.

const GameScene := preload("res://scenes/Game.tscn")

var game: Node


func _ready() -> void:
	_watchdog()
	Meta.reset()
	Inventory.reset()
	Research.reset()
	Loadout.reset()
	Lore.reset()
	game = GameScene.instantiate()
	add_child(game)
	await _frames(5)

	# 1. 거점 로드
	assert(game._world.get_child_count() == 1, "World 에 씬이 하나만 있어야 함")
	assert(not game._in_dungeon, "시작은 거점이어야 함")
	assert(get_tree().get_first_node_in_group("player") != null, "거점에 플레이어 없음")

	# 2. 던전 입장 (계약 화면 스킵)
	game.enter_dungeon(true)
	await _frames(5)
	assert(game._in_dungeon, "던전 진입 플래그 안 섬")
	var arena: Node = game._world.get_child(0)
	assert(arena.rooms.size() == 6, "던전(Arena)이 안 뜸")

	# 2b. 계약 화면 경로도 동작하는지 (열고 → 계약 선택 → 던전)
	# (여기선 skip 경로만 검증. 계약 UI 자체는 ContractMenu._pick 로 별도 확인 가능)

	# 3. 보스방 순간이동 → 보스 처치
	var p: Node2D = arena.get_node("Player")
	p.invulnerable = true
	p.global_position = arena.rooms[5].global_position
	await _frames(20)
	var boss: Node = arena.rooms[5].boss
	assert(boss != null, "보스 스폰 안 됨")
	var kg := 0
	while is_instance_valid(boss) and kg < 400:
		if is_instance_valid(boss):
			boss.take_hit(400, Vector2.DOWN, 0.0)
		await get_tree().physics_frame
		kg += 1
	assert(not is_instance_valid(boss), "보스 안 죽음")

	# 4. 배너(2.6s) 후 거점 복귀
	for i in 220:
		await get_tree().physics_frame
	assert(not game._in_dungeon, "클리어 후 거점 복귀 안 됨")
	assert(not is_instance_valid(arena), "이전 던전 씬이 안 치워짐")
	assert(get_tree().get_first_node_in_group("player") != null, "복귀한 거점에 플레이어 없음")

	# 5. 제단 Tab
	game.open_shop()
	assert(game._altar.visible, "거점에서 제단이 안 열림")
	game._altar._close_shop()

	# 6. 연구소 — 영혼 지급 후 연구
	Meta.souls = 300
	game.open_research()
	assert(game._research.visible, "연구소가 안 열림")
	game._research._do("blade_arts")
	assert(Research.is_done("blade_arts"), "연구소에서 연구가 안 됨")
	game._research._close()

	print("test_loop: OK")
	Meta.reset()
	Research.reset()
	get_tree().quit(0)


func _frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame


func _watchdog() -> void:
	await get_tree().create_timer(45.0).timeout
	push_error("test_loop: WATCHDOG TIMEOUT")
	get_tree().quit(2)
