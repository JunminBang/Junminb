@echo off
echo === LISTING PROGRAMS DIR ===
dir C:\Users\qkdwnsals22\AppData\Local\Programs\
echo === CHECKING GODOT EXE ===
if exist "C:\Users\qkdwnsals22\AppData\Local\Programs\Godot\Godot_v4.7.2-stable_win64.exe" (
  echo EXE EXISTS
) else (
  echo EXE NOT FOUND
  echo === SEARCHING FOR GODOT ===
  where godot 2>&1
  dir /s /b "C:\Users\qkdwnsals22\AppData\Local\*odot*" 2>&1
)
