# godot_proto — 핸드오프 문서

**엔진**: Godot 4.7.2  
**장르**: 로그라이크 액션 (탑다운 2D)  
**작성일**: 2026-09-02

---

## 1. 프로젝트 개요

마비노기 IP 기반 로그라이크 전투 프로토타입.  
"영혼" 단일 화폐로 메타 성장(제단 강화) + 연구 영구 해금.  
런마다 6개 방(입구 → 전투 4 → 보스)을 클리어하고 영혼을 모아 다음 런을 강화.

---

## 2. 씬 구조

```
scenes/
  Main.tscn       ← 던전 루트 (Arena + Player + HUD)
  Base.tscn       ← 거점 (제단 / 연구소 / 무공소 / NPC)
  Enemy.tscn
  Boss.tscn
  Pickup.tscn
  ...
```

**메인 씬 트리 (Main.tscn)**
```
Node2D [Arena.gd]
  Player [Player.gd]
    Camera2D
    Jelly          ← 히트스탑 / 젤리 반동 이펙트
  Hud [Hud.gd]
```

---

## 3. 오토로드 (자동로드 싱글턴)

| 이름 | 파일 | 역할 |
|------|------|------|
| Meta | scripts/Meta.gd | 영혼 화폐, 메타 강화(제단), 계약, 세이브/로드 |
| Research | scripts/Research.gd | 연구 트리 (영혼 → 무공/강화 영구 해금) |
| Inventory | scripts/Inventory.gd | 현재 미사용 스텁 (구 채집 시스템 잔재) |
| Loadout | scripts/Loadout.gd | 장착 무공 슬롯 (E키 기동기, R키 필살) |
| Lore | scripts/Lore.gd | NPC 서사 마일스톤 |
| Hitstop | scripts/HitstopManager.gd | 전역 히트스탑 |
| Sfx | scripts/Sfx.gd | 효과음 |

---

## 4. 핵심 스크립트 요약

### Player.gd
- **상태 머신**: IDLE → DASH → ACT → RECOVER
- **조작**: WASD 이동 / 마우스 조준 / Space 대시 / 좌클릭(경공격) / 우클릭(강공격) / E(기동기) / R(필살)
- **대시**: 무적 프레임 + 적 레이어 통과 (collision_mask=1). 방향은 현재 WASD 입력 → 마지막 이동 방향(`_last_move_dir`) 순 우선순위. 마우스 방향 **아님**.
- **콤보 체인**: 같은 버튼 연타로 l1→l2→l3, 후딜 중 다른 버튼으로 크로스 캔슬
- **메타 반영**: `_apply_meta()` 에서 제단/연구 보너스 합산

### Arena.gd
- 방 6개를 가로로 배치. 플레이어 위치로 방 인덱스를 감지해 자동 begin().
- **절차적 던전 ①** — OBS 딕셔너리로 방마다 장애물 프리셋 적용
- **절차적 던전 ②** — 방 2 클리어 후 분기 선택 UI (CanvasLayer, process_mode=ALWAYS). 봇용 `bot_pick_branch()` 제공
- **절차적 던전 ③** — WAVE_POOL_T1/T2/T3 셔플로 런마다 다른 웨이브 조합
- `_branch_pending_from >= 0` 이면 분기 선택 대기 중

### Room.gd
- 방 구조(벽 + 출구 문) 빌드, 웨이브 스폰, 클리어 시그널
- 장애물: `_spawn_obstacles()` → `_obstacle()` (StaticBody2D + ColorRect)
- 8초 웨이브 타임아웃: 마지막 웨이브 전엔 잔당을 남긴 채 다음 웨이브 진행

### Enemy.gd
- 체급: LIGHT / HEAVY / FIXED / RANGED
- 상태: IDLE → CHASE → TELE(예비동작 0.5s) → ATTACK(돌진) → RECOVER

### Boss.gd
- POOL_1(5패턴) + POOL_2(5패턴) = 10패턴
- 페이즈 1→2 전환 있음 (`phased`, `phase` 변수)

### Meta.gd (메타 성장)
- **제단 강화** (런 중 사망/클리어 후 영혼 소비):
  - 스탯: 강철 심장, 방벽, 불굴, 잔상, 예리함, 속공, 질풍 (최대 2레벨)
  - 빌드 정의: 잔영검, 폭주의 그릇, 파쇄격, 광전사 (1레벨, 연구로 해금)
- **각성**: 태그(offense/defense/mobility/sustain) 합산 4레벨 이상 시 각성 보너스
- **계약**: 쇄도 / 무딘 칼 / 유리 심장 / 쫓기는 자 / 정예 (불리한 조건 + 영혼 배율 보상)
- 저장: `user://mabi_proto_save.cfg`

### Research.gd (연구 트리)
- 영혼 소비로 무공/강화 영구 해금. 선행 연구 조건 있음.
- 저장: `user://mabi_proto_research.cfg`

---

## 5. 화폐 & 경제

- **영혼(souls)** — 유일 화폐. 적 처치/보스 처치로 획득.
- Inventory는 현재 비어 있는 스텁 (채집 시스템 제거됨).
- 런 종료 후 영혼은 유지됨(로그라이크 메타). 제단/연구 구매로 소비.

---

## 6. 테스트 스위트

```bash
# 실행 방법 (헤드리스)
GODOT="/c/Users/qkdwnsals22/Downloads/Godot_v4.7.2-stable_win64.exe/Godot_v4.7.2-stable_win64_console.exe"
cd /c/Users/qkdwnsals22/Downloads/godot_proto/godot_proto
"$GODOT" --headless --path . res://tests/<테스트명>.tscn
```

| 테스트 | 파일 | 커버 범위 | 최신 결과 |
|--------|------|-----------|-----------|
| test_combat | tests/test_combat.gd | 전투 기초 (피격/사망/킬/투사체 등) | ✅ OK |
| test_arena | tests/test_arena.gd | 방 6개 + 분기 + 보스 패턴 10종 + 보스 클리어 | ✅ OK |
| test_loop | tests/test_loop.gd | 사망→메타→재도전 루프 | ✅ OK |
| playthrough | tests/playthrough.gd | 봇이 던전 완주 (사망 1회 허용) | ✅ 클리어 |
| qa_balance | tests/qa_balance.gd | 빌드 11종 × 클리어 가능 여부 | ✅ 10/11 (무강화만 시간초과 — 의도) |
| qa_boss | tests/qa_boss.gd | 빌드별 보스전 격파 | 재실행 필요 |

> **주의**: 테스트는 반드시 `.tscn` 씬으로 실행. `--script` 모드는 오토로드가 로드되지 않아 실패함.

---

## 7. 최근 주요 변경 이력

| 날짜 | 변경 내용 |
|------|-----------|
| 2026-09-02 | 대시 키 Shift → Space |
| 2026-09-02 | 채집 시스템 제거, 화폐 wood/stone/herb/ore → souls 단일 통합 |
| 2026-09-02 | 대시 중 적이 달라붙는 버그 수정 (collision_mask=1 during dash) |
| 2026-09-02 | 절차적 던전 ① 방 내부 장애물 프리셋 (pillars2/4, walls_v/h, pillar_c) |
| 2026-09-02 | 절차적 던전 ② 방 2 클리어 후 분기 선택 UI (쇄도의 길 / 중압의 길) |
| 2026-09-02 | 절차적 던전 ③ WAVE_POOL 셔플로 런마다 다른 웨이브 |
| 2026-09-02 | 분기 UI process_mode=ALWAYS 수정 (pause 중 버튼 클릭 불가 버그) |
| 2026-09-02 | 대시 방향 마우스 → 마지막 WASD 입력 방향으로 수정 |

---

## 8. 알려진 이슈 / TODO

- **qa_boss 재실행 필요**: 이전 실행이 Arena.gd 파싱 오류 전 결과라 테이블이 비어 있음.
- **분기 UI 디자인**: 현재 코드로 생성된 최소 UI. 아트 적용 필요.
- **Inventory.gd**: 채집 제거 후 빈 스텁으로 남아 있음. 오토로드에서 제거 가능하나 테스트 코드 일부가 `Inventory.reset()` 호출 중 — 제거 시 테스트도 수정 필요.
- **ObjectDB 리크 경고**: 헤드리스 종료 시 2~8개 인스턴스 누수 경고. 기능 영향 없음.

---

## 9. 디렉터리 구조

```
godot_proto/
├── scenes/          ← .tscn 씬 파일
├── scripts/         ← GDScript 로직
├── tests/           ← 헤드리스 자동 테스트 (.gd + .tscn)
├── assets/          ← 오디오 등 리소스
├── project.godot
└── HANDOFF.md       ← 이 문서
```
