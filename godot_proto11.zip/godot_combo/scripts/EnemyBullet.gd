extends Area2D

var _vel: Vector2  = Vector2.ZERO
var _dmg: int      = 8
var _life: float   = 3.5
var _t: float      = 0.0


func launch(dir: Vector2, speed: float, dmg: int) -> void:
	_vel = dir * speed
	_dmg = dmg
	collision_layer = 8
	collision_mask  = 1
	var cs := CollisionShape2D.new()
	var sh := CircleShape2D.new()
	sh.radius = 7.0
	cs.shape  = sh
	add_child(cs)
	body_entered.connect(_on_hit)


func _process(delta: float) -> void:
	position += _vel * delta
	_t += delta
	if _t >= _life:
		queue_free()
		return
	# 화면 밖
	if position.x < -20 or position.x > 1300 or position.y < -20 or position.y > 740:
		queue_free()
		return
	queue_redraw()


func _draw() -> void:
	draw_circle(Vector2.ZERO, 7.0, Color(0.3, 0.5, 1.0))
	draw_circle(Vector2.ZERO, 3.5, Color.WHITE)


func _on_hit(body: Node2D) -> void:
	if body.has_method("take_hit"):
		body.take_hit(_dmg)
	queue_free()
