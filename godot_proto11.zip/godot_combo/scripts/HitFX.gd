class_name HitFX

# ── 슬래시 아크 ──────────────────────────────────────────────
class _Arc extends Node2D:
	var _radius: float
	var _arc_deg: float
	var _col: Color
	var _angle: float  # 중심 각도 (라디안)
	var _alpha: float = 1.0

	func init(radius: float, arc_deg: float, col: Color, dir: Vector2) -> void:
		_radius = radius
		_arc_deg = arc_deg
		_col = col
		_angle = dir.angle()

	func _ready() -> void:
		var tw := create_tween()
		tw.tween_property(self, "_alpha", 0.0, 0.25)
		tw.tween_callback(queue_free)

	func _process(_delta: float) -> void:
		queue_redraw()

	func _draw() -> void:
		var half := deg_to_rad(_arc_deg * 0.5)
		var from_a := _angle - half
		var to_a := _angle + half
		# 내부 얇은 하이라이트
		var c2 := Color(1.0, 1.0, 1.0, _alpha * 0.6)
		draw_arc(Vector2.ZERO, _radius * 0.75, from_a, to_a, 48, c2, 3.0)
		# 외곽 두꺼운 아크 (판정 경계와 일치)
		var c1 := Color(_col.r, _col.g, _col.b, _alpha * 0.9)
		draw_arc(Vector2.ZERO, _radius, from_a, to_a, 48, c1, 8.0)


# ── 확장 링 ──────────────────────────────────────────────────
class _Ring extends Node2D:
	var _max_radius: float
	var _col: Color
	var _cur_radius: float = 0.0
	var _alpha: float = 1.0
	var _delay: float = 0.0

	func init(max_radius: float, col: Color, delay: float) -> void:
		_max_radius = max_radius
		_col = col
		_delay = delay

	func _ready() -> void:
		var tw := create_tween()
		tw.tween_interval(_delay)
		tw.tween_method(_set_radius, 0.0, _max_radius, 0.35)
		tw.parallel().tween_property(self, "_alpha", 0.0, 0.35)
		tw.tween_callback(queue_free)

	func _set_radius(v: float) -> void:
		_cur_radius = v
		queue_redraw()

	func _draw() -> void:
		var c := Color(_col.r, _col.g, _col.b, _alpha)
		draw_arc(Vector2.ZERO, _cur_radius, 0.0, TAU, 64, c, 4.0)
		draw_arc(Vector2.ZERO, _cur_radius * 0.88, 0.0, TAU, 64, Color(1, 1, 1, _alpha * 0.4), 2.0)


# ── 스파크 ───────────────────────────────────────────────────
class _Spark extends Node2D:
	var _lines: Array = []
	var _alpha: float = 1.0

	func init(count: int, min_len: float, max_len: float, col: Color) -> void:
		for i in count:
			var ang := randf() * TAU
			var len := randf_range(min_len, max_len)
			var dir := Vector2(cos(ang), sin(ang))
			_lines.append({"dir": dir, "len": len, "col": col})

	func _ready() -> void:
		var tw := create_tween()
		tw.tween_property(self, "_alpha", 0.0, 0.3)
		tw.tween_callback(queue_free)
		# 선들이 바깥으로 퍼짐
		for ln in _lines:
			var tw2 := create_tween()
			tw2.tween_method(func(v: float): ln["offset"] = v, 0.0, ln["len"] * 0.5, 0.15)

	func _process(_delta: float) -> void:
		queue_redraw()

	func _draw() -> void:
		for ln in _lines:
			var off: float = ln.get("offset", 0.0)
			var start: Vector2 = ln["dir"] * off
			var end: Vector2   = ln["dir"] * (off + ln["len"])
			var c := Color(ln["col"].r, ln["col"].g, ln["col"].b, _alpha)
			draw_line(start, end, c, 2.0)


# ── 데미지 숫자 ───────────────────────────────────────────────
class _DmgNum extends Node2D:
	var _amount: int
	var _col: Color
	var _alpha: float = 1.0
	var _prefix: String = ""

	func init(amount: int, col: Color) -> void:
		_amount = amount
		_col = col

	func _ready() -> void:
		var tw := create_tween()
		tw.tween_property(self, "position:y", position.y - 55.0, 0.6)
		tw.parallel().tween_property(self, "_alpha", 0.0, 0.6)
		tw.tween_callback(queue_free)

	func _process(_delta: float) -> void:
		queue_redraw()

	func _draw() -> void:
		var text := str(_prefix) + str(_amount)
		var c := Color(_col.r, _col.g, _col.b, _alpha)
		# 외곽선
		for dx in [-2, 2]:
			for dy in [-2, 2]:
				draw_string(ThemeDB.fallback_font, Vector2(dx - 14, dy + 8), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(0, 0, 0, _alpha * 0.8))
		draw_string(ThemeDB.fallback_font, Vector2(-14, 8), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, c)


# ── 사망 폭발 ─────────────────────────────────────────────────
class _DeathBurst extends Node2D:
	var _col: Color
	var _radius: float
	var _cur_r: float = 0.0
	var _alpha: float = 1.0

	func init(col: Color, radius: float) -> void:
		_col = col
		_radius = radius

	func _ready() -> void:
		var tw := create_tween()
		tw.tween_method(_set_r, 0.0, _radius * 2.0, 0.3)
		tw.parallel().tween_property(self, "_alpha", 0.0, 0.3)
		tw.tween_callback(queue_free)
		# 스파크
		var sp := _Spark.new()
		sp.init(14, 20.0, 60.0, _col)
		add_child(sp)

	func _set_r(v: float) -> void:
		_cur_r = v
		queue_redraw()

	func _draw() -> void:
		var c := Color(_col.r, _col.g, _col.b, _alpha)
		draw_arc(Vector2.ZERO, _cur_r, 0.0, TAU, 64, c, 5.0)
		draw_circle(Vector2.ZERO, _cur_r * 0.5, Color(_col.r, _col.g, _col.b, _alpha * 0.25))


# ── 화면 흰 플래시 ────────────────────────────────────────────
class _Flash extends CanvasLayer:
	func init() -> void:
		layer = 10
		var rect := ColorRect.new()
		rect.color = Color(1, 1, 1, 0.85)
		rect.size = Vector2(1280, 720)
		add_child(rect)
		var tw := create_tween()
		tw.tween_property(rect, "color:a", 0.0, 0.08)
		tw.tween_callback(queue_free)


# ── static 팩토리 함수들 ──────────────────────────────────────

static func slash_arc(parent: Node, origin: Vector2, dir: Vector2, radius: float, arc_deg: float, col: Color) -> void:
	var node := _Arc.new()
	node.init(radius, arc_deg, col, dir)
	node.position = origin
	parent.add_child(node)

static func slam_ring(parent: Node, origin: Vector2, radius: float, col: Color) -> void:
	for i in 3:
		var node := _Ring.new()
		node.init(radius * 1.4 * (0.6 + i * 0.2), col, i * 0.1)
		node.position = origin
		parent.add_child(node)

static func dash_trail(parent: Node, from_pos: Vector2, to_pos: Vector2, col: Color) -> void:
	# 잔상: 경로를 따라 페이드 아웃 원들
	var steps := 6
	for i in steps:
		var t := float(i) / float(steps - 1)
		var p := from_pos.lerp(to_pos, t)
		var node := _Ring.new()
		node.init(18.0 * (1.0 - t * 0.5), col, i * 0.03)
		node.position = p
		parent.add_child(node)

static func finisher(parent: Node, origin: Vector2, radius: float, col: Color) -> void:
	# 4개 링
	for i in 4:
		var node := _Ring.new()
		node.init(radius * 1.3 * (0.4 + i * 0.2), col, i * 0.06)
		node.position = origin
		parent.add_child(node)
	# 30개 스파크
	var sp := _Spark.new()
	sp.init(30, 30.0, 90.0, col)
	sp.position = origin
	parent.add_child(sp)
	# 흰 플래시
	var fl := _Flash.new()
	fl.init()
	parent.add_child(fl)

static func damage_number(parent: Node, pos: Vector2, amount: int, col: Color) -> void:
	var node := _DmgNum.new()
	node.init(amount, col)
	node.position = pos + Vector2(randf_range(-12, 12), randf_range(-10, 0))
	parent.add_child(node)

static func heal_number(parent: Node, pos: Vector2, amount: int) -> void:
	var n := _DmgNum.new()
	n.global_position = pos + Vector2(randf_range(-15, 15), -20)
	n.init(amount, Color(0.2, 1.0, 0.4))
	n._prefix = "+"
	parent.add_child(n)

static func death_burst(parent: Node, pos: Vector2, col: Color) -> void:
	var node := _DeathBurst.new()
	node.init(col, 40.0)
	node.position = pos
	parent.add_child(node)
