extends CharacterBody2D

const EnemyBulletScript := preload("res://scripts/EnemyBullet.gd")

signal died(xp_val: int)

enum EType { RUSHER, RANGED, SKILL }

var etype: int = EType.RUSHER
var hp: int = 30
var max_hp: int = 30
var move_speed: float = 90.0
var xp_val: int = 1
var contact_dmg: int = 10
var radius: float = 18.0

var _player: Node2D = null
var _inv_t: float = 0.0
var _pattern_t: float = 0.0
var _fire_t: float = 0.0

# SKILL 전용
enum SkillState { NORMAL, TELEGRAPH, ACTING }
var _skill_state: int = SkillState.NORMAL
var _skill_timer: float = 0.0
var _charge_dir: Vector2 = Vector2.ZERO
var _skill_type: int = 0   # 0=charge 1=spin
var _spin_active: bool = false


func setup(player: Node2D, hp_val: int, spd: float, et: int) -> void:
	_player = player
	hp        = hp_val
	max_hp    = hp_val
	move_speed = spd
	etype     = et
	xp_val    = 1 + et
	contact_dmg = 8 + et * 4


func _ready() -> void:
	add_to_group("enemy")
	collision_layer = 4
	collision_mask  = 2

	var col := CollisionShape2D.new()
	var sh  := CircleShape2D.new()
	sh.radius = radius
	col.shape = sh
	add_child(col)

	# 접촉 판정 Area2D
	var area := Area2D.new()
	area.collision_layer = 4
	area.collision_mask  = 1
	var acs := CollisionShape2D.new()
	var ash := CircleShape2D.new()
	ash.radius = radius + 2.0
	acs.shape = ash
	area.add_child(acs)
	area.body_entered.connect(_on_contact)
	add_child(area)

	_pattern_t = randf_range(2.0, 4.0)
	_fire_t    = randf_range(1.5, 3.0)


func _draw() -> void:
	var body_col := _body_color()
	draw_circle(Vector2.ZERO, radius, body_col)
	draw_circle(Vector2.ZERO, radius * 0.55, body_col.lightened(0.25))

	# HP 바
	var hp_ratio: float = float(hp) / float(max_hp)
	draw_rect(Rect2(Vector2(-radius, -radius - 8), Vector2(radius * 2, 4)), Color(0.2, 0.0, 0.0))
	draw_rect(Rect2(Vector2(-radius, -radius - 8), Vector2(radius * 2 * hp_ratio, 4)), Color(0.0, 0.85, 0.2))

	# 스킬 예고 표시
	if _skill_state == SkillState.TELEGRAPH:
		var flash: bool = fmod(_skill_timer * 8.0, 1.0) > 0.5
		if flash:
			draw_circle(Vector2.ZERO, radius + 6.0, Color(1.0, 0.2, 0.0, 0.5))

	# 스핀 범위 표시
	if _spin_active:
		draw_circle(Vector2.ZERO, radius * 2.2, Color(1.0, 0.5, 0.0, 0.3))

	# 눈
	if is_instance_valid(_player):
		var eye_dir: Vector2 = (_player.global_position - global_position).normalized()
		var perp := Vector2(-eye_dir.y, eye_dir.x)
		draw_circle(eye_dir * (radius * 0.55) + perp * (radius * 0.3), 3.5, Color.WHITE)
		draw_circle(eye_dir * (radius * 0.55) - perp * (radius * 0.3), 3.5, Color.WHITE)


func _body_color() -> Color:
	match etype:
		EType.RANGED: return Color(0.2, 0.35, 0.85)
		EType.SKILL:  return Color(0.7, 0.25, 0.75)
		_:            return Color(0.78, 0.15, 0.15)


func _physics_process(delta: float) -> void:
	if not is_instance_valid(_player):
		return
	_inv_t = maxf(0.0, _inv_t - delta)
	queue_redraw()

	match etype:
		EType.RUSHER:  _update_rusher(delta)
		EType.RANGED:  _update_ranged(delta)
		EType.SKILL:   _update_skill(delta)


# ── 경계 클램프 ───────────────────────────────────────────────────
func _clamp_arena() -> void:
	position.x = clampf(position.x, 30.0, 1250.0)
	position.y = clampf(position.y, 30.0, 690.0)


# ── RUSHER ────────────────────────────────────────────────────────
func _update_rusher(_delta: float) -> void:
	var dir: Vector2 = (_player.global_position - global_position).normalized()
	velocity = dir * move_speed
	move_and_slide()
	_clamp_arena()


# ── RANGED ────────────────────────────────────────────────────────
func _update_ranged(delta: float) -> void:
	var dist: float = global_position.distance_to(_player.global_position)
	var dir: Vector2 = (_player.global_position - global_position).normalized()

	# 거리 유지: 너무 가까우면 후퇴, 너무 멀면 접근
	if dist < 220.0:
		velocity = -dir * move_speed * 0.8
	elif dist > 340.0:
		velocity = dir * move_speed * 0.5
	else:
		velocity = Vector2.ZERO
	move_and_slide()
	_clamp_arena()

	# 발사
	_fire_t -= delta
	if _fire_t <= 0.0:
		_fire_t = randf_range(2.0, 3.2)
		_shoot_at_player()


func _shoot_at_player() -> void:
	if not is_instance_valid(_player):
		return
	var bullet: Area2D = EnemyBulletScript.new()
	var dir: Vector2 = (_player.global_position - global_position).normalized()
	get_parent().add_child(bullet)
	bullet.global_position = global_position
	bullet.launch(dir, 280.0, contact_dmg - 4)


# ── SKILL ─────────────────────────────────────────────────────────
func _update_skill(delta: float) -> void:
	match _skill_state:
		SkillState.NORMAL:
			# 천천히 접근
			var dir: Vector2 = (_player.global_position - global_position).normalized()
			velocity = dir * move_speed * 0.55
			move_and_slide()
			_pattern_t -= delta
			if _pattern_t <= 0.0:
				_pattern_t = randf_range(3.5, 5.5)
				_start_telegraph()

		SkillState.TELEGRAPH:
			velocity = Vector2.ZERO
			_skill_timer -= delta
			if _skill_timer <= 0.0:
				_start_act()

		SkillState.ACTING:
			_skill_timer -= delta
			if _skill_type == 0:
				# 돌진
				velocity = _charge_dir * move_speed * 4.5
				move_and_slide()
				_clamp_arena()
				if _skill_timer <= 0.0:
					_skill_state = SkillState.NORMAL
					velocity = Vector2.ZERO
			else:
				# 스핀 (제자리)
				velocity = Vector2.ZERO
				_spin_active = true
				# 스핀 범위 안 플레이어 지속 피해
				if is_instance_valid(_player):
					var d: float = global_position.distance_to(_player.global_position)
					if d < radius * 2.4 and _inv_t <= 0.0:
						_player.take_hit(contact_dmg)
						_inv_t = 0.4
				if _skill_timer <= 0.0:
					_spin_active = false
					_skill_state = SkillState.NORMAL


func _start_telegraph() -> void:
	_skill_state = SkillState.TELEGRAPH
	_skill_type  = randi() % 2
	_skill_timer = 0.75
	if _skill_type == 0 and is_instance_valid(_player):
		_charge_dir = (_player.global_position - global_position).normalized()


func _start_act() -> void:
	_skill_state = SkillState.ACTING
	_skill_timer = 0.45 if _skill_type == 0 else 1.4
	_spin_active = (_skill_type == 1)


# ── 피격 / 사망 ───────────────────────────────────────────────────
func take_hit(dmg: int, kb: Vector2 = Vector2.ZERO) -> void:
	hp -= dmg
	velocity += kb
	_squash_hit()
	if hp <= 0:
		died.emit(xp_val)
		const HFX := preload("res://scripts/HitFX.gd")
		HFX.death_burst(get_parent(), global_position, _body_color())
		queue_free()


func _on_contact(body: Node2D) -> void:
	if body.has_method("take_hit") and _inv_t <= 0.0:
		body.take_hit(contact_dmg)
		_inv_t = 0.55


func _squash_hit() -> void:
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(1.75, 0.35), 0.05)
	tw.tween_property(self, "scale", Vector2(0.80, 1.25), 0.09)
	tw.tween_property(self, "scale", Vector2(1.0,  1.0),  0.15)
