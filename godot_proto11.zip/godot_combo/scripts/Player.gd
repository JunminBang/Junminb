extends CharacterBody2D

signal hp_changed(hp: int, max_hp: int)
signal died
signal combo_updated(idx: int, cstate: int, window_ratio: float)
signal leveled_up
signal xp_changed(xp: int, needed: int)

# ── 스탯 ─────────────────────────────────────────────────────
var max_hp: int = 100
var hp: int = 100
var move_speed: float = 400.0
var lifesteal: int = 0

var slots: Array = [
	# 시작: 평타 1개만
	{"name":"평타", "dmg":12, "range":82.0, "arc":70.0, "type":"slash",
	 "col":Color(0.75,0.75,0.75), "window":0.50},
]
var combo_window_bonus: float = 0.0  # 업그레이드로 전체 창 보정

# ── XP / 레벨 ────────────────────────────────────────────────────
var xp: int = 0
var level: int = 1

# ── 콤보 상태머신 ─────────────────────────────────────────────
enum CState { IDLE, ATTACKING, OPEN }
var combo_idx: int = 0
var cstate: int = CState.IDLE
var _window_timer: float = 0.0
var _attack_timer: float = 0.0

# ── 이동/대시 ────────────────────────────────────────────────
var _dash_active: bool = false
var _invincible: bool = false
var _invincible_timer: float = 0.0
var _blink_timer: float = 0.0
var _draw_visible: bool = true

# ── 마우스 방향 ──────────────────────────────────────────────
var _aim_dir: Vector2 = Vector2.RIGHT
var _face_dir: Vector2 = Vector2.RIGHT  # _aim_dir 별칭 (슬롯 함수에서 사용)

func _ready() -> void:
	add_to_group("player")
	# 충돌 셰이프
	var shape := CircleShape2D.new()
	shape.radius = 16.0
	var col := CollisionShape2D.new()
	col.shape = shape
	add_child(col)

func xp_needed() -> int:
	return 3 + level * 2

func add_xp(amount: int) -> void:
	xp += amount
	var needed := xp_needed()
	xp_changed.emit(xp, needed)
	if xp >= needed:
		xp -= needed
		level += 1
		leveled_up.emit()
		xp_changed.emit(xp, xp_needed())

func add_slot(slot_data: Dictionary) -> void:
	slots.append(slot_data.duplicate())

func _process(delta: float) -> void:
	# 마우스 방향
	var mp := get_global_mouse_position()
	var d := (mp - global_position)
	if d.length() > 1.0:
		_aim_dir = d.normalized()
		_face_dir = _aim_dir

	# 무적 타이머
	if _invincible:
		_invincible_timer -= delta
		_blink_timer -= delta
		if _blink_timer <= 0.0:
			_blink_timer = 0.1
			_draw_visible = not _draw_visible
		if _invincible_timer <= 0.0:
			_invincible = false
			_draw_visible = true

	# 콤보 상태머신 타이머
	match cstate:
		CState.ATTACKING:
			_attack_timer -= delta
			if _attack_timer <= 0.0:
				cstate = CState.OPEN
				_window_timer = float(slots[combo_idx]["window"]) + combo_window_bonus
				_emit_combo()
		CState.OPEN:
			_window_timer -= delta
			_emit_combo()
			if _window_timer <= 0.0:
				_reset_combo()

	queue_redraw()

func _physics_process(delta: float) -> void:
	if _dash_active:
		return
	var dir := Vector2.ZERO
	if Input.is_action_pressed("ui_right") or Input.is_key_pressed(KEY_D):
		dir.x += 1.0
	if Input.is_action_pressed("ui_left") or Input.is_key_pressed(KEY_A):
		dir.x -= 1.0
	if Input.is_action_pressed("ui_down") or Input.is_key_pressed(KEY_S):
		dir.y += 1.0
	if Input.is_action_pressed("ui_up") or Input.is_key_pressed(KEY_W):
		dir.y -= 1.0
	if dir.length() > 0.1:
		dir = dir.normalized()
	velocity = dir * move_speed
	move_and_slide()

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_on_attack_pressed()

func _on_attack_pressed() -> void:
	match cstate:
		CState.IDLE:
			_execute_slot(combo_idx)
		CState.OPEN:
			combo_idx = (combo_idx + 1) % slots.size()
			_execute_slot(combo_idx)

func _execute_slot(idx: int) -> void:
	cstate = CState.ATTACKING
	_attack_timer = 0.25
	_emit_combo()
	var slot: Dictionary = slots[idx]
	match slot["type"]:
		"slash":     _do_slash(slot)
		"slam":      _do_slam(slot)
		"dash":      _do_dash(slot)
		"finisher":  _do_finisher(slot)
		"spin":      _do_spin(slot)
		"lifedrain": _do_lifedrain(slot)
		"lightning": _do_lightning(slot)
		"jumpslam":  _do_jumpslam(slot)
	_squash_stretch(_aim_dir)

func _reset_combo() -> void:
	combo_idx = 0
	cstate = CState.IDLE
	_window_timer = 0.0
	_emit_combo()

func _emit_combo() -> void:
	var ratio := 0.0
	if cstate == CState.OPEN:
		var w: float = float(slots[combo_idx]["window"]) + combo_window_bonus
		if w > 0.0:
			ratio = _window_timer / w
	emit_signal("combo_updated", combo_idx, cstate, ratio)

# ── 슬롯 실행 ────────────────────────────────────────────────

func _do_slash(slot: Dictionary) -> void:
	var dmg: int = int(slot["dmg"])
	var range_r: float = slot["range"]
	var arc_deg: float = slot["arc"]
	HitFX.slash_arc(get_parent(), global_position, _aim_dir, range_r, arc_deg, slot["col"])
	var hit_count := 0
	for e in _find_enemies_in_cone(global_position, _aim_dir, range_r, deg_to_rad(arc_deg * 0.5)):
		e.take_hit(dmg, _aim_dir * 120.0)
		HitFX.damage_number(get_parent(), e.global_position, dmg, slot["col"])
		hit_count += 1
	if hit_count > 0:
		_heal_lifesteal()
		_hit_stop(0.04)

func _do_slam(slot: Dictionary) -> void:
	var dmg: int = int(slot["dmg"])
	var range_r: float = slot["range"]
	HitFX.slam_ring(get_parent(), global_position, range_r, slot["col"])
	var hit_count := 0
	for e in _find_enemies_in_radius(global_position, range_r):
		var kb_dir: Vector2 = (e.global_position - global_position).normalized()
		e.take_hit(dmg, kb_dir * 280.0)
		HitFX.damage_number(get_parent(), e.global_position, dmg, slot["col"])
		hit_count += 1
	if hit_count > 0:
		_heal_lifesteal()
	_hit_stop(0.06)
	_screen_shake(6.0)

func _do_dash(slot: Dictionary) -> void:
	var dmg: int = int(slot["dmg"])
	var range_r: float = slot["range"]
	var arc_deg: float = slot["arc"]
	var from_pos := global_position
	var to_pos := global_position + _aim_dir * range_r
	# 벽 경계 클램프
	to_pos.x = clampf(to_pos.x, 30.0, 1250.0)
	to_pos.y = clampf(to_pos.y, 30.0, 690.0)

	_dash_active = true
	var tw := create_tween()
	tw.tween_property(self, "global_position", to_pos, 0.15).set_ease(Tween.EASE_OUT)
	tw.tween_callback(func():
		_dash_active = false
		HitFX.dash_trail(get_parent(), from_pos, to_pos, slot["col"])
		var hit_count := 0
		for e in _find_enemies_in_cone(global_position, _aim_dir, 80.0, deg_to_rad(arc_deg * 0.5)):
			e.take_hit(dmg, _aim_dir * 200.0)
			HitFX.damage_number(get_parent(), e.global_position, dmg, slot["col"])
			hit_count += 1
		if hit_count > 0:
			_heal_lifesteal()
			_hit_stop(0.04)
	)

func _do_finisher(slot: Dictionary) -> void:
	var dmg: int = int(slot["dmg"])
	var range_r: float = slot["range"]
	HitFX.finisher(get_parent(), global_position, range_r, slot["col"])
	var hit_count := 0
	for e in _find_enemies_in_radius(global_position, range_r):
		var kb_dir: Vector2 = (e.global_position - global_position).normalized()
		e.take_hit(dmg, kb_dir * 500.0)
		HitFX.damage_number(get_parent(), e.global_position, dmg, slot["col"])
		hit_count += 1
	if hit_count > 0:
		_heal_lifesteal()
	_hit_stop(0.10)
	_screen_shake(14.0)

func _do_spin(slot: Dictionary) -> void:
	var dmg: int = int(slot["dmg"])
	var range_r: float = slot["range"]
	HitFX.slam_ring(get_parent(), global_position, range_r, slot["col"])
	var hit_count := 0
	for e in _find_enemies_in_radius(global_position, range_r):
		var kb_dir: Vector2 = (e.global_position - global_position).normalized()
		e.take_hit(dmg, kb_dir * 200.0)
		HitFX.damage_number(get_parent(), e.global_position, dmg, slot["col"])
		hit_count += 1
	if hit_count > 0:
		_heal_lifesteal()
	_hit_stop(0.05)
	_screen_shake(4.0)

func _do_lifedrain(slot: Dictionary) -> void:
	var dmg: int = int(slot["dmg"])
	var range_r: float = slot["range"]
	var half_arc: float = deg_to_rad(slot["arc"] * 0.5)
	HitFX.slash_arc(get_parent(), global_position, _face_dir, range_r, slot["arc"], slot["col"])
	var hit_count := 0
	for e in _find_enemies_in_cone(global_position, _face_dir, range_r, half_arc):
		e.take_hit(dmg, _face_dir * 150.0)
		HitFX.damage_number(get_parent(), e.global_position, dmg, slot["col"])
		hit_count += 1
	if hit_count > 0:
		var heal := 15
		hp = mini(hp + heal, max_hp)
		hp_changed.emit(hp, max_hp)
		HitFX.heal_number(get_parent(), global_position, heal)
		_hit_stop(0.04)

func _do_lightning(slot: Dictionary) -> void:
	var dmg: int = int(slot["dmg"])
	var half_arc: float = deg_to_rad(slot["arc"] * 0.5)
	var primary: Array = _find_enemies_in_cone(global_position, _face_dir, slot["range"], half_arc)
	var chained: Array = []
	for e in primary:
		for near in _find_enemies_in_radius(e.global_position, 160.0):
			if not primary.has(near) and not chained.has(near):
				chained.append(near)
	for e in primary:
		e.take_hit(dmg, Vector2.ZERO)
		HitFX.damage_number(get_parent(), e.global_position, dmg, slot["col"])
	for e in chained:
		var chain_dmg: int = int(dmg * 0.6)
		e.take_hit(chain_dmg, Vector2.ZERO)
		HitFX.damage_number(get_parent(), e.global_position, chain_dmg, slot["col"])
	HitFX.slam_ring(get_parent(), global_position, slot["range"] * 0.5, slot["col"])
	if primary.size() + chained.size() > 0:
		_heal_lifesteal()
		_hit_stop(0.05)

func _do_jumpslam(slot: Dictionary) -> void:
	if _dash_active:
		return
	_dash_active = true
	var target: Vector2 = global_position + _face_dir * float(slot["range"]) * 0.55
	target.x = clampf(target.x, 40, 1240)
	target.y = clampf(target.y, 40, 680)
	var tw := create_tween()
	tw.tween_property(self, "global_position", target, 0.18).set_trans(Tween.TRANS_EXPO)
	await tw.finished
	_dash_active = false
	var aoe_r: float = slot["range"] * 0.65
	HitFX.slam_ring(get_parent(), global_position, aoe_r, slot["col"])
	var hit_count := 0
	for e in _find_enemies_in_radius(global_position, aoe_r):
		var kb_dir: Vector2 = (e.global_position - global_position).normalized()
		e.take_hit(int(slot["dmg"]), kb_dir * 350.0)
		HitFX.damage_number(get_parent(), e.global_position, int(slot["dmg"]), slot["col"])
		hit_count += 1
	if hit_count > 0:
		_heal_lifesteal()
	_hit_stop(0.07)
	_screen_shake(8.0)

# ── 유틸 ─────────────────────────────────────────────────────

func _find_enemies_in_cone(origin: Vector2, dir: Vector2, range_r: float, half_arc_rad: float) -> Array:
	var result: Array = []
	for e in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(e):
			continue
		var to_e: Vector2 = e.global_position - origin
		if to_e.length() > range_r:
			continue
		if to_e.length() < 0.1:
			result.append(e)
			continue
		var angle := dir.angle_to(to_e.normalized())
		if abs(angle) <= half_arc_rad:
			result.append(e)
	return result

func _find_enemies_in_radius(origin: Vector2, radius: float) -> Array:
	var result: Array = []
	for e in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(e):
			continue
		if (e.global_position - origin).length() <= radius:
			result.append(e)
	return result

func _heal_lifesteal() -> void:
	if lifesteal > 0:
		hp = mini(hp + lifesteal, max_hp)
		emit_signal("hp_changed", hp, max_hp)

func _squash_stretch(dir: Vector2) -> void:
	var sx := 1.0 + dir.x * dir.x * 0.45 - dir.y * dir.y * 0.30
	var sy := 1.0 + dir.y * dir.y * 0.45 - dir.x * dir.x * 0.30
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(2.0 - sx, 2.0 - sy), 0.07)
	tw.tween_property(self, "scale", Vector2(sx, sy), 0.09)
	tw.tween_property(self, "scale", Vector2(1.0, 1.0), 0.16)

func _hit_stop(duration: float) -> void:
	Engine.time_scale = 0.05
	# process_always=true 로 time_scale 영향 무시
	await get_tree().create_timer(duration, true, false, true).timeout
	Engine.time_scale = 1.0

func _screen_shake(mag: float) -> void:
	var cam: Camera2D = get_viewport().get_camera_2d()
	if not cam:
		return
	var tw := cam.create_tween()
	for i in 8:
		tw.tween_property(cam, "offset",
			Vector2(randf_range(-mag, mag), randf_range(-mag, mag)), 0.03)
	tw.tween_property(cam, "offset", Vector2.ZERO, 0.05)

func take_hit(amount: int) -> void:
	if _invincible:
		return
	hp -= amount
	hp = maxi(hp, 0)
	emit_signal("hp_changed", hp, max_hp)
	_invincible = true
	_invincible_timer = 0.6
	_blink_timer = 0.1
	if hp <= 0:
		emit_signal("died")

func _draw() -> void:
	if not _draw_visible:
		return
	var slot_col: Color = slots[combo_idx]["col"] if combo_idx < slots.size() else Color.WHITE
	# 몸통
	draw_circle(Vector2.ZERO, 18.0, Color(0.3, 0.5, 1.0))
	# 외곽선 (현재 슬롯 색)
	draw_arc(Vector2.ZERO, 18.0, 0.0, TAU, 32, slot_col, 3.0)
	# 눈
	var eye_offset := _aim_dir * 7.0
	var perp := Vector2(-_aim_dir.y, _aim_dir.x) * 5.0
	draw_circle(eye_offset + perp, 4.0, Color.WHITE)
	draw_circle(eye_offset - perp, 4.0, Color.WHITE)
	draw_circle(eye_offset + perp + _aim_dir * 2.0, 2.0, Color(0.1, 0.1, 0.2))
	draw_circle(eye_offset - perp + _aim_dir * 2.0, 2.0, Color(0.1, 0.1, 0.2))
