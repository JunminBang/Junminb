extends Node2D

const PlayerScript      := preload("res://scripts/Player.gd")
const EnemyScript       := preload("res://scripts/Enemy.gd")
const HudScript         := preload("res://scripts/Hud.gd")

# ── 신규 슬롯 카드 풀 ──────────────────────────────────────────────
const CARD_POOL: Array = [
	{"name":"참격",    "desc":"빠른 베기\n타이밍 창: 0.45초",
	 "slot":{"name":"참격",    "dmg":22, "range":95.0,  "arc":85.0,  "type":"slash",     "col":Color(1.0,0.95,0.2), "window":0.45}},
	{"name":"강타",    "desc":"AOE 강타 + 넉백\n타이밍 창: 0.80초",
	 "slot":{"name":"강타",    "dmg":45, "range":75.0,  "arc":360.0, "type":"slam",      "col":Color(1.0,0.45,0.1), "window":0.80}},
	{"name":"돌진베기", "desc":"고속 돌진 후 베기\n타이밍 창: 0.55초",
	 "slot":{"name":"돌진베기", "dmg":35, "range":190.0, "arc":50.0,  "type":"dash",      "col":Color(0.2,0.75,1.0), "window":0.55}},
	{"name":"피니셔",  "desc":"대폭발 (콤보 리셋)\n타이밍 창: 없음",
	 "slot":{"name":"피니셔",  "dmg":115,"range":135.0, "arc":360.0, "type":"finisher",  "col":Color(1.0,0.1,0.55), "window":0.0}},
	{"name":"회전베기", "desc":"360° 회전베기\n타이밍 창: 0.60초",
	 "slot":{"name":"회전베기", "dmg":30, "range":85.0,  "arc":360.0, "type":"spin",      "col":Color(0.3,1.0,0.45), "window":0.60}},
	{"name":"흡혈베기", "desc":"베기 + HP 회복\n타이밍 창: 0.90초",
	 "slot":{"name":"흡혈베기", "dmg":20, "range":90.0,  "arc":75.0,  "type":"lifedrain", "col":Color(0.85,0.1,0.85),"window":0.90}},
	{"name":"번개",    "desc":"연쇄 번개\n타이밍 창: 0.50초",
	 "slot":{"name":"번개",    "dmg":38, "range":300.0, "arc":30.0,  "type":"lightning", "col":Color(0.85,0.85,1.0),"window":0.50}},
	{"name":"점프강타", "desc":"점프 후 AOE 착지\n타이밍 창: 0.70초",
	 "slot":{"name":"점프강타", "dmg":65, "range":90.0,  "arc":360.0, "type":"jumpslam",  "col":Color(0.85,0.5,0.1), "window":0.70}},
]

# ── 업그레이드 풀 ──────────────────────────────────────────────────
const UPGRADE_POOL: Array = [
	{"name":"파워 업",    "desc":"모든 슬롯\n데미지 +25%",      "type":"dmg_up",       "value":0.25},
	{"name":"범위 확장",  "desc":"모든 슬롯\n사거리 +30%",      "type":"range_up",     "value":0.30},
	{"name":"체력 강화",  "desc":"최대 HP +30\n전량 회복",      "type":"hp_up",        "value":30.0},
	{"name":"타이밍 연장","desc":"콤보 타이밍 창\n+0.20초",     "type":"window_up",    "value":0.20},
	{"name":"쾌속 이동",  "desc":"이동속도 +20%",              "type":"speed_up",     "value":0.20},
	{"name":"흡혈 강화",  "desc":"공격 적중 시\nHP +8 회복",    "type":"lifesteal_up", "value":8.0},
]

var _player: CharacterBody2D = null
var _camera: Camera2D        = null
var _hud: CanvasLayer        = null

# ── 연속 스포너 ───────────────────────────────────────────────────
var _spawn_timer: float = 2.0
var _difficulty:  float = 0.0   # 경과 시간에 비례해 상승

var _card_overlay: CanvasLayer = null
var _offered_cards: Array      = []
var _is_upgrade: bool          = false


func _ready() -> void:
	randomize()
	_build_walls()
	_build_player()
	_build_hud()


func _build_player() -> void:
	_player = CharacterBody2D.new()
	_player.set_script(PlayerScript)
	_player.position = Vector2(640, 360)
	_player.z_index = 2
	add_child(_player)
	_player.died.connect(_on_player_died)
	_player.leveled_up.connect(_on_leveled_up)

	_camera = Camera2D.new()
	_camera.anchor_mode = Camera2D.ANCHOR_MODE_DRAG_CENTER
	_player.add_child(_camera)
	_camera.make_current()


func _build_hud() -> void:
	_hud = CanvasLayer.new()
	_hud.set_script(HudScript)
	add_child(_hud)
	_player.hp_changed.connect(func(h, m): _hud.on_hp_changed(h, m))
	_player.combo_updated.connect(func(i, s, r): _hud.on_combo_updated(i, s, r, _player.slots))
	_player.xp_changed.connect(func(x, n): _hud.on_xp_changed(x, n))
	_hud.on_hp_changed(_player.hp, _player.max_hp)
	_hud.on_xp_changed(0, _player.xp_needed())
	_hud.on_combo_updated(0, 0, 1.0, _player.slots)


func _build_walls() -> void:
	for wall in [
		[Vector2(640, -10),  Vector2(1280, 20)],
		[Vector2(640, 730),  Vector2(1280, 20)],
		[Vector2(-10, 360),  Vector2(20, 720)],
		[Vector2(1290, 360), Vector2(20, 720)],
	]:
		var sb  := StaticBody2D.new()
		sb.position = wall[0]
		var cs  := CollisionShape2D.new()
		var box := RectangleShape2D.new()
		box.size = wall[1]
		cs.shape = box
		sb.add_child(cs)
		add_child(sb)


func _process(delta: float) -> void:
	if get_tree().paused:
		return

	_difficulty += delta * 0.025   # ~40초마다 1.0 증가

	_spawn_timer -= delta
	if _spawn_timer <= 0.0:
		var interval: float = maxf(0.6, 2.5 - _difficulty * 0.3)
		_spawn_timer = interval
		_spawn_enemy()


func _spawn_enemy() -> void:
	var diff := _difficulty
	var hp: int     = int(30.0 + diff * 14.0)
	var spd: float  = 180.0 + diff * 20.0

	var et: int = 0
	if diff >= 4.0:
		et = randi() % 3
	elif diff >= 2.0:
		et = randi() % 2

	var enemy: CharacterBody2D = EnemyScript.new()
	add_child(enemy)
	enemy.position = _spawn_pos()
	enemy.setup(_player, hp, spd, et)
	enemy.died.connect(_on_enemy_died)


func _spawn_pos() -> Vector2:
	var edge := randi() % 4
	match edge:
		0: return Vector2(randf_range(60, 1220), randf_range(20, 60))
		1: return Vector2(randf_range(60, 1220), randf_range(660, 700))
		2: return Vector2(randf_range(20, 60),   randf_range(60, 660))
		_: return Vector2(randf_range(1220, 1260), randf_range(60, 660))
	return Vector2(640, 360)


func _on_enemy_died(xp_val: int) -> void:
	_player.add_xp(xp_val)


func _on_leveled_up() -> void:
	_hud._player_level = _player.level
	get_tree().paused = true
	# 5레벨 배수이고 슬롯이 4개 미만이면 신규 슬롯, 아니면 업그레이드
	if _player.level % 5 == 0 and _player.slots.size() < 4:
		_is_upgrade = false
		_show_card_select()
	else:
		_is_upgrade = true
		_show_upgrade_select()


# ── 신규 슬롯 선택 UI ─────────────────────────────────────────────
func _show_card_select() -> void:
	if _card_overlay:
		_card_overlay.queue_free()

	# 이미 보유한 타입 제외
	var owned: Array = []
	for s in _player.slots:
		owned.append(s["type"])
	var pool: Array = []
	for c in CARD_POOL:
		if not owned.has(c["slot"]["type"]):
			pool.append(c)
	pool.shuffle()
	_offered_cards = pool.slice(0, mini(3, pool.size()))

	_card_overlay = _make_overlay()
	_card_overlay.add_child(_make_title(
		"레벨 %d  —  새 콤보 슬롯 (%d/4)" % [_player.level, _player.slots.size()]))

	var n: int = _offered_cards.size()
	var card_w := 220
	var start_x: int = 640 - (n * card_w + (n - 1) * 12) / 2
	for i in n:
		var cd: Dictionary = _offered_cards[i]
		var stat := "DMG %d  |  RNG %.0f" % [cd["slot"]["dmg"], cd["slot"]["range"]]
		_make_card_btn(_card_overlay, cd["name"], cd["desc"], cd["slot"]["col"],
			stat, Vector2(start_x + i * (card_w + 12), 275), card_w, i)


# ── 업그레이드 선택 UI ────────────────────────────────────────────
func _show_upgrade_select() -> void:
	if _card_overlay:
		_card_overlay.queue_free()

	var pool: Array = UPGRADE_POOL.duplicate()
	pool.shuffle()
	_offered_cards = pool.slice(0, 3)

	_card_overlay = _make_overlay()
	_card_overlay.add_child(_make_title("레벨 %d  —  강화 선택" % _player.level))

	var card_w := 220
	var start_x := 640 - (3 * card_w + 2 * 12) / 2
	for i in 3:
		var upg: Dictionary = _offered_cards[i]
		_make_card_btn(_card_overlay, upg["name"], upg["desc"],
			Color(0.75, 0.6, 1.0), "", Vector2(start_x + i * (card_w + 12), 275), card_w, i)


# ── 공용 오버레이/타이틀 ──────────────────────────────────────────
func _make_overlay() -> CanvasLayer:
	var cl := CanvasLayer.new()
	cl.layer = 20
	cl.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(cl)
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.0, 0.0, 0.0, 0.72)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cl.add_child(bg)
	return cl


func _make_title(text: String) -> Label:
	var lbl := Label.new()
	lbl.text = text
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.position = Vector2(290, 220)
	lbl.size = Vector2(700, 40)
	lbl.add_theme_color_override("font_color", Color.WHITE)
	lbl.add_theme_font_size_override("font_size", 20)
	lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return lbl


func _make_card_btn(layer: CanvasLayer, card_name: String, desc: String,
		col: Color, stat: String, pos: Vector2, w: int, idx: int) -> void:
	var btn := Button.new()
	btn.position = pos
	btn.size = Vector2(w, 200)
	btn.text = ""
	btn.process_mode = Node.PROCESS_MODE_ALWAYS
	layer.add_child(btn)

	var bg := ColorRect.new()
	bg.size = Vector2(w, 200)
	bg.color = Color(col.r * 0.15, col.g * 0.15, col.b * 0.15, 0.95)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	btn.add_child(bg)

	var bar := ColorRect.new()
	bar.size = Vector2(w, 6)
	bar.color = col
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	btn.add_child(bar)

	var name_lbl := Label.new()
	name_lbl.text = card_name
	name_lbl.position = Vector2(0, 16)
	name_lbl.size = Vector2(w, 30)
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_lbl.add_theme_color_override("font_color", col)
	name_lbl.add_theme_font_size_override("font_size", 18)
	name_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	btn.add_child(name_lbl)

	var desc_lbl := Label.new()
	desc_lbl.text = desc
	desc_lbl.position = Vector2(8, 60)
	desc_lbl.size = Vector2(w - 16, 100)
	desc_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc_lbl.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85))
	desc_lbl.add_theme_font_size_override("font_size", 13)
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	desc_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	btn.add_child(desc_lbl)

	if stat != "":
		var stat_lbl := Label.new()
		stat_lbl.text = stat
		stat_lbl.position = Vector2(0, 168)
		stat_lbl.size = Vector2(w, 24)
		stat_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		stat_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
		stat_lbl.add_theme_font_size_override("font_size", 11)
		stat_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.add_child(stat_lbl)

	btn.pressed.connect(func(): _on_selected(idx))


func _on_selected(idx: int) -> void:
	if _is_upgrade:
		_apply_upgrade(_offered_cards[idx])
	else:
		_player.add_slot(_offered_cards[idx]["slot"])
	_hud.on_combo_updated(_player.combo_idx, _player.cstate, 1.0, _player.slots)
	if _card_overlay:
		_card_overlay.queue_free()
		_card_overlay = null
	get_tree().paused = false


func _apply_upgrade(upg: Dictionary) -> void:
	match upg["type"]:
		"dmg_up":
			for s in _player.slots:
				s["dmg"] = int(float(s["dmg"]) * (1.0 + float(upg["value"])))
		"range_up":
			for s in _player.slots:
				s["range"] = float(s["range"]) * (1.0 + float(upg["value"]))
		"hp_up":
			_player.max_hp += int(upg["value"])
			_player.hp = _player.max_hp
			_player.hp_changed.emit(_player.hp, _player.max_hp)
		"window_up":
			_player.combo_window_bonus += float(upg["value"])
		"speed_up":
			_player.move_speed *= (1.0 + float(upg["value"]))
		"lifesteal_up":
			_player.lifesteal += int(upg["value"])


func _on_player_died() -> void:
	get_tree().paused = true
	var msg := Label.new()
	msg.text = "GAME OVER"
	msg.position = Vector2(490, 320)
	msg.add_theme_color_override("font_color", Color(1.0, 0.2, 0.2))
	msg.add_theme_font_size_override("font_size", 48)
	var cl := CanvasLayer.new()
	cl.layer = 30
	cl.process_mode = Node.PROCESS_MODE_ALWAYS
	cl.add_child(msg)
	add_child(cl)
	await get_tree().create_timer(2.5, true, false, true).timeout
	get_tree().paused = false
	get_tree().reload_current_scene()


func _draw() -> void:
	var grid_col := Color(0.16, 0.16, 0.20)
	var step := 60
	for x in range(20, 1261, step):
		draw_line(Vector2(x, 20), Vector2(x, 700), grid_col, 1.0)
	for y in range(20, 701, step):
		draw_line(Vector2(20, y), Vector2(1260, y), grid_col, 1.0)
