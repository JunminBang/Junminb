extends CanvasLayer

# ── 노드 참조 ─────────────────────────────────────────────────
var _slot_panels: Array = []
var _slot_labels: Array = []
var _timing_bar: ColorRect
var _timing_bg: ColorRect
var _hp_bar: ColorRect
var _hp_bg: ColorRect
var _hp_label: Label
var _xp_bar_bg: ColorRect
var _xp_bar_fill: ColorRect
var _level_lbl: Label

var _cur_idx: int = 0
var _cur_state: int = 0  # CState
var _window_ratio: float = 0.0
var _blink_timer: float = 0.0
var _blink_on: bool = true
var _player_level: int = 1

# 현재 슬롯 데이터 (시각 업데이트용)
var _slots: Array = []

const SLOT_SIZE := 64
const SLOT_GAP := 8
const SLOT_Y := 720 - 90

const XP_BAR_W := 400
const XP_BAR_H := 10
const XP_BAR_X := (1280 - XP_BAR_W) / 2
const XP_BAR_Y := 720 - 14


func _ready() -> void:
	layer = 5
	_build_ui()


func _build_ui() -> void:
	# HP 바
	_hp_bg = ColorRect.new()
	_hp_bg.size = Vector2(200, 18)
	_hp_bg.position = Vector2(16, 16)
	_hp_bg.color = Color(0.2, 0.2, 0.2, 0.9)
	add_child(_hp_bg)

	_hp_bar = ColorRect.new()
	_hp_bar.size = Vector2(200, 18)
	_hp_bar.position = Vector2(16, 16)
	_hp_bar.color = Color(0.2, 0.85, 0.25)
	add_child(_hp_bar)

	_hp_label = Label.new()
	_hp_label.position = Vector2(16, 14)
	_hp_label.size = Vector2(200, 20)
	_hp_label.text = "HP 100/100"
	_hp_label.add_theme_color_override("font_color", Color.WHITE)
	_hp_label.add_theme_constant_override("outline_size", 1)
	_hp_label.add_theme_font_size_override("font_size", 13)
	add_child(_hp_label)

	# XP 바 (하단 중앙)
	_xp_bar_bg = ColorRect.new()
	_xp_bar_bg.size = Vector2(XP_BAR_W, XP_BAR_H)
	_xp_bar_bg.position = Vector2(XP_BAR_X, XP_BAR_Y)
	_xp_bar_bg.color = Color(0.15, 0.15, 0.25, 0.9)
	add_child(_xp_bar_bg)

	_xp_bar_fill = ColorRect.new()
	_xp_bar_fill.size = Vector2(0, XP_BAR_H)
	_xp_bar_fill.position = Vector2(XP_BAR_X, XP_BAR_Y)
	_xp_bar_fill.color = Color(0.25, 0.7, 1.0)
	add_child(_xp_bar_fill)

	_level_lbl = Label.new()
	_level_lbl.text = "Lv.1"
	_level_lbl.position = Vector2(XP_BAR_X - 44, XP_BAR_Y - 2)
	_level_lbl.size = Vector2(40, 14)
	_level_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_level_lbl.add_theme_color_override("font_color", Color(0.8, 0.9, 1.0))
	_level_lbl.add_theme_font_size_override("font_size", 12)
	add_child(_level_lbl)

	# 타이밍 바 배경/바 (슬롯 생성 후 크기 조정)
	_timing_bg = ColorRect.new()
	_timing_bg.size = Vector2(SLOT_SIZE, 6)  # 초기값, _rebuild_slots에서 갱신
	_timing_bg.color = Color(0.15, 0.15, 0.15, 0.9)
	_timing_bg.visible = false
	add_child(_timing_bg)

	_timing_bar = ColorRect.new()
	_timing_bar.size = Vector2(SLOT_SIZE, 6)
	_timing_bar.color = Color(0.3, 0.9, 0.3)
	_timing_bar.visible = false
	add_child(_timing_bar)


func _rebuild_slots(slots: Array) -> void:
	# 기존 패널 제거
	for p in _slot_panels:
		p.queue_free()
	_slot_panels.clear()
	_slot_labels.clear()

	var n: int = slots.size()
	var total_w: int = n * SLOT_SIZE + (n - 1) * SLOT_GAP
	var start_x: int = (1280 - total_w) / 2

	for i in n:
		var panel := ColorRect.new()
		panel.size = Vector2(SLOT_SIZE, SLOT_SIZE)
		panel.position = Vector2(start_x + i * (SLOT_SIZE + SLOT_GAP), SLOT_Y)
		panel.color = Color(0.1, 0.1, 0.15, 0.85)
		add_child(panel)
		_slot_panels.append(panel)

		var lbl := Label.new()
		lbl.text = slots[i]["name"]
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		lbl.size = Vector2(SLOT_SIZE, SLOT_SIZE)
		lbl.add_theme_font_size_override("font_size", 12)
		panel.add_child(lbl)
		_slot_labels.append(lbl)

	# 타이밍 바 위치/크기 갱신
	_timing_bg.size.x = total_w
	_timing_bg.position = Vector2(start_x, SLOT_Y + SLOT_SIZE + 6)
	_timing_bar.size.x = total_w
	_timing_bar.position = Vector2(start_x, SLOT_Y + SLOT_SIZE + 6)


func on_hp_changed(cur_hp: int, max_hp: int) -> void:
	var ratio := float(cur_hp) / float(max_hp)
	_hp_bar.size.x = 200.0 * ratio
	_hp_label.text = "HP %d/%d" % [cur_hp, max_hp]
	if ratio > 0.5:
		_hp_bar.color = Color(0.2, 0.85, 0.25)
	elif ratio > 0.25:
		_hp_bar.color = Color(0.9, 0.75, 0.1)
	else:
		_hp_bar.color = Color(0.9, 0.2, 0.2)


func on_xp_changed(xp: int, needed: int) -> void:
	_xp_bar_fill.size.x = XP_BAR_W * clampf(float(xp) / float(needed), 0.0, 1.0)
	_level_lbl.text = "Lv.%d" % _player_level


func on_combo_updated(idx: int, cstate: int, window_ratio: float, slots: Array) -> void:
	# 슬롯 수가 바뀌었으면 재빌드
	if slots.size() != _slot_panels.size():
		_slots = slots.duplicate()
		_rebuild_slots(slots)

	_cur_idx = idx
	_cur_state = cstate
	_window_ratio = window_ratio
	_slots = slots

	# 슬롯 시각 갱신
	for i in _slot_panels.size():
		if i >= slots.size():
			break
		var col: Color = slots[i]["col"]
		var panel: ColorRect = _slot_panels[i]
		var lbl: Label = _slot_labels[i]
		lbl.text = slots[i]["name"]

		if i == idx:
			panel.color = Color(col.r * 0.4, col.g * 0.4, col.b * 0.4, 0.95)
			lbl.add_theme_color_override("font_color", col)
		else:
			panel.color = Color(0.08, 0.08, 0.12, 0.85)
			lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))


func _process(delta: float) -> void:
	_update_timing_bar()
	_blink_timer -= delta
	if _blink_timer <= 0.0:
		_blink_timer = 0.12
		_blink_on = not _blink_on


func _update_timing_bar() -> void:
	# CState.OPEN = 2
	var is_open := (_cur_state == 2)
	_timing_bg.visible = is_open
	_timing_bar.visible = is_open
	if not is_open:
		return
	_timing_bar.size.x = _timing_bg.size.x * _window_ratio
	# 20% 이하 빨간 점멸
	if _window_ratio <= 0.2:
		_timing_bar.color = Color(1.0, 0.1, 0.1) if _blink_on else Color(0.5, 0.05, 0.05)
	else:
		_timing_bar.color = Color(0.3, 0.9, 0.3)
