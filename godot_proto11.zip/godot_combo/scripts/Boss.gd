extends "res://scripts/Enemy.gd"

# ── 보스 전용 설정 ─────────────────────────────────────────────
var _charge_timer: float = 8.0
var _is_charging: bool = false
var _charge_vel: Vector2 = Vector2.ZERO
var _phase2: bool = false

const BULLET_SPEED: float = 220.0
const BULLET_DAMAGE: int = 12

func _ready() -> void:
	# super._ready() 전에 radius를 먼저 설정해야 충돌 셰이프 크기가 올바름
	max_hp = 500
	hp = 500
	speed = 65.0
	color = Color(0.7, 0.1, 0.8)
	radius = 34.0
	contact_damage = 14
	super._ready()

func _physics_process(delta: float) -> void:
	if _dead:
		return
	_contact_timer -= delta
	if _player == null:
		_player = get_tree().get_first_node_in_group("player")

	# 페이즈 2 전환
	if not _phase2 and float(hp) / float(max_hp) <= 0.5:
		_phase2 = true

	_charge_timer -= delta
	if _charge_timer <= 0.0:
		_charge_timer = _phase2 and 5.0 or 8.0
		if not _is_charging and _player and is_instance_valid(_player):
			_start_charge()

	if _is_charging:
		velocity = _charge_vel
		_knockback = Vector2.ZERO
	else:
		if _player and is_instance_valid(_player):
			var dir := (_player.global_position - global_position).normalized()
			velocity = dir * speed + _knockback
		else:
			velocity = _knockback
	_knockback = _knockback.lerp(Vector2.ZERO, delta * 6.0)
	move_and_slide()
	queue_redraw()

func _start_charge() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	_is_charging = true
	_charge_vel = (_player.global_position - global_position).normalized() * 340.0
	# 0.5초 후 돌진 종료
	var tw := create_tween()
	tw.tween_interval(0.5)
	tw.tween_callback(func(): _is_charging = false)

	if _phase2:
		# 3방향 분산샷
		_fire_spread()

func _fire_spread() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	var base_dir := (_player.global_position - global_position).normalized()
	for i in 3:
		var angle_offset := deg_to_rad((i - 1) * 30.0)
		var dir := base_dir.rotated(angle_offset)
		_spawn_bullet(dir)

func _spawn_bullet(dir: Vector2) -> void:
	var b := _Bullet.new()
	b.init(dir * BULLET_SPEED, BULLET_DAMAGE, global_position)
	get_parent().add_child(b)


# ── 보스 투사체 ──────────────────────────────────────────────
class _Bullet extends Area2D:
	var _vel: Vector2
	var _dmg: int
	var _life: float = 3.5

	func init(vel: Vector2, dmg: int, pos: Vector2) -> void:
		_vel = vel
		_dmg = dmg
		position = pos
		var shape := CircleShape2D.new()
		shape.radius = 8.0
		var col := CollisionShape2D.new()
		col.shape = shape
		add_child(col)
		body_entered.connect(_on_body)

	func _process(delta: float) -> void:
		position += _vel * delta
		_life -= delta
		if _life <= 0.0:
			queue_free()
		queue_redraw()

	func _on_body(body: Node) -> void:
		if body.is_in_group("player"):
			body.take_hit(_dmg)
			queue_free()

	func _draw() -> void:
		draw_circle(Vector2.ZERO, 8.0, Color(0.9, 0.2, 0.9))
		draw_arc(Vector2.ZERO, 8.0, 0.0, TAU, 24, Color(1.0, 0.6, 1.0), 2.0)

func _draw() -> void:
	# 보스 전용 드로우 (크고 위협적)
	draw_circle(Vector2.ZERO, radius, color)
	draw_arc(Vector2.ZERO, radius, 0.0, TAU, 48, Color(1.0, 0.5, 1.0), 4.0)
	draw_arc(Vector2.ZERO, radius + 6.0, 0.0, TAU, 48, Color(0.8, 0.2, 0.9, 0.5), 2.0)
	# HP 바
	var hp_ratio := float(hp) / float(max_hp)
	var bar_w := radius * 2.5
	draw_rect(Rect2(-bar_w * 0.5, radius + 8.0, bar_w, 7.0), Color(0.15, 0.15, 0.15))
	draw_rect(Rect2(-bar_w * 0.5, radius + 8.0, bar_w * hp_ratio, 7.0), Color(0.8, 0.1, 0.8))
	# 페이즈2 표시
	if _phase2:
		draw_arc(Vector2.ZERO, radius + 12.0, 0.0, TAU, 48, Color(1.0, 0.0, 0.5, 0.7), 2.0)
