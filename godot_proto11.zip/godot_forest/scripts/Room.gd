extends Node3D
## 10×10m 디오라마 방.
## build(open_dirs) 호출 후 부모 씬에 add_child 하고 position 설정.

const HALF := 5.0   # 방 반폭

var grid_pos:     Vector2i = Vector2i.ZERO
var has_light:    bool     = false
var is_exit:      bool     = false
var campfire_pos: Vector3  = Vector3.ZERO  # 로컬 좌표


func build(open_dirs: Array) -> void:
	_build_floor()
	_build_walls(open_dirs)
	_build_trees()
	if has_light:
		_build_campfire()
	if is_exit:
		_build_exit_marker()


# ── 바닥 ──────────────────────────────────────────────────────────
func _build_floor() -> void:
	var mi  := MeshInstance3D.new()
	var pm  := PlaneMesh.new()
	pm.size = Vector2(10.0, 10.0)
	mi.mesh = pm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.09, 0.13, 0.07)
	mi.material_override = mat
	add_child(mi)


# ── 벽 ───────────────────────────────────────────────────────────
func _build_walls(open_dirs: Array) -> void:
	for dir in [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]:
		_wall_side(dir, open_dirs.has(dir))


func _wall_side(dir: Vector2i, has_gap: bool) -> void:
	# 연결된 방향 → 중앙 2.5m 갭 / 연결 없음 → 통벽
	if dir.x != 0:
		var wx := float(dir.x) * HALF
		if has_gap:
			_wall_box(Vector3(wx, 1.0, -3.25), Vector3(0.5, 2.0, 3.5))
			_wall_box(Vector3(wx, 1.0,  3.25), Vector3(0.5, 2.0, 3.5))
		else:
			_wall_box(Vector3(wx, 1.0, 0.0),   Vector3(0.5, 2.0, 10.0))
	else:
		var wz := float(dir.y) * HALF
		if has_gap:
			_wall_box(Vector3(-3.25, 1.0, wz), Vector3(3.5, 2.0, 0.5))
			_wall_box(Vector3( 3.25, 1.0, wz), Vector3(3.5, 2.0, 0.5))
		else:
			_wall_box(Vector3(0.0,  1.0, wz),  Vector3(10.0, 2.0, 0.5))


func _wall_box(pos: Vector3, sz: Vector3) -> void:
	var sb  := StaticBody3D.new()
	sb.position = pos
	add_child(sb)
	var cs  := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = sz
	cs.shape = box
	sb.add_child(cs)
	var mi  := MeshInstance3D.new()
	var bm  := BoxMesh.new()
	bm.size = sz
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.05, 0.08, 0.04)
	mi.material_override = mat
	sb.add_child(mi)


# ── 나무 ─────────────────────────────────────────────────────────
func _build_trees() -> void:
	var n := 6 + randi() % 5
	for _i in n:
		var tx := randf_range(-4.0, 4.0)
		var tz := randf_range(-4.0, 4.0)
		if Vector2(tx, tz).length() < 2.0:
			continue
		_spawn_tree(Vector3(tx, 0.0, tz))


func _spawn_tree(pos: Vector3) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	var h := randf_range(1.8, 4.0)
	# 줄기
	var ti  := MeshInstance3D.new()
	var tc  := CylinderMesh.new()
	tc.height = h; tc.top_radius = 0.12; tc.bottom_radius = 0.22
	ti.mesh = tc; ti.position.y = h * 0.5
	var tm := StandardMaterial3D.new()
	tm.albedo_color = Color(0.20, 0.11, 0.05)
	ti.material_override = tm
	root.add_child(ti)
	# 수관
	var ci := MeshInstance3D.new()
	var sm := SphereMesh.new()
	var r  := randf_range(0.8, 1.6)
	sm.radius = r; sm.height = r * 2.0
	ci.mesh = sm; ci.position.y = h + r * 0.5
	var cm := StandardMaterial3D.new()
	cm.albedo_color = Color(
		randf_range(0.03, 0.09),
		randf_range(0.13, 0.24),
		randf_range(0.03, 0.09)
	)
	ci.material_override = cm
	root.add_child(ci)


# ── 모닥불 ───────────────────────────────────────────────────────
func _build_campfire() -> void:
	var lx := randf_range(-2.5, 2.5)
	var lz := randf_range(-2.5, 2.5)
	campfire_pos = Vector3(lx, 0.0, lz)

	var root := Node3D.new()
	root.position = campfire_pos
	add_child(root)

	# 장작
	var li := MeshInstance3D.new()
	var lc := CylinderMesh.new()
	lc.height = 0.12; lc.top_radius = 0.28; lc.bottom_radius = 0.28
	li.mesh = lc; li.position.y = 0.06
	var lm := StandardMaterial3D.new()
	lm.albedo_color = Color(0.28, 0.14, 0.05)
	li.material_override = lm
	root.add_child(li)

	# 불꽃
	var fi := MeshInstance3D.new()
	var fc := CylinderMesh.new()
	fc.height = 0.55; fc.top_radius = 0.02; fc.bottom_radius = 0.20
	fi.mesh = fc; fi.position.y = 0.38
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(1.0, 0.50, 0.05)
	fm.emission_enabled = true
	fm.emission = Color(1.0, 0.32, 0.0)
	fm.emission_energy_multiplier = 3.0
	fi.material_override = fm
	root.add_child(fi)

	# 광원
	var light := OmniLight3D.new()
	light.light_color  = Color(1.0, 0.62, 0.22)
	light.omni_range   = 4.5
	light.light_energy = 2.0
	light.position.y   = 0.6
	root.add_child(light)


# ── 출구 마커 ────────────────────────────────────────────────────
func _build_exit_marker() -> void:
	var mi  := MeshInstance3D.new()
	var cm  := CylinderMesh.new()
	cm.height = 0.06; cm.top_radius = 2.0; cm.bottom_radius = 2.0
	mi.mesh = cm; mi.position.y = 0.04
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.35, 0.65, 1.0)
	mat.emission_enabled = true
	mat.emission = Color(0.15, 0.35, 0.8)
	mat.emission_energy_multiplier = 1.8
	mi.material_override = mat
	add_child(mi)

	var light := OmniLight3D.new()
	light.light_color  = Color(0.45, 0.65, 1.0)
	light.omni_range   = 3.5
	light.light_energy = 1.0
	light.position.y   = 0.5
	add_child(light)
