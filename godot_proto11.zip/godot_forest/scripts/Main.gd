extends Node3D
## 씬 루트. 맵 생성 → 플레이어/존재 배치 → 공포/타이머 루프.

const MapGenScript  := preload("res://scripts/MapGen.gd")
const RoomScript    := preload("res://scripts/Room.gd")
const PlayerScript  := preload("res://scripts/Player.gd")
const EntityScript  := preload("res://scripts/Entity.gd")
const HudScript     := preload("res://scripts/Hud.gd")

const ROOM_SIZE  := 10.0
const DAWN_TOTAL := 180.0   # 3분
const FEAR_MAX   := 100.0

enum State { PLAY, PANIC, WIN, LOSE }

var _state   := State.PLAY
var _dawn_t  := DAWN_TOTAL
var _fear    := 0.0
var _panic_t := 0.0

var _player: CharacterBody3D = null
var _entity: Node3D          = null
var _camera: Camera3D        = null
var _hud:    CanvasLayer     = null

var _rooms:           Dictionary = {}   # Vector2i → Room node
var _campfire_worlds: Array      = []   # 모닥불 월드 좌표 목록
var _conn_map:        Dictionary = {}   # Vector2i → Array[Vector2i]
var _exit_pos:        Vector2i


func _ready() -> void:
	randomize()
	_setup_environment()
	_generate_map()
	_setup_player()
	_setup_entity()
	_setup_camera()
	_hud = HudScript.new()
	add_child(_hud)


# ── 환경 ──────────────────────────────────────────────────────────
func _setup_environment() -> void:
	var we  := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode        = Environment.BG_COLOR
	env.background_color       = Color(0.0, 0.0, 0.02)
	env.ambient_light_source   = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color    = Color(0.04, 0.05, 0.08)
	env.ambient_light_energy   = 0.18
	we.environment = env
	add_child(we)


# ── 맵 생성 ───────────────────────────────────────────────────────
func _generate_map() -> void:
	var map: Dictionary       = MapGenScript.generate()
	var rooms_data: Dictionary = map["rooms"]
	var connections: Array     = map["connections"]
	_exit_pos = map["exit"]

	# 연결 맵 구성
	for conn in connections:
		var a: Vector2i = conn[0]
		var b: Vector2i = conn[1]
		if not _conn_map.has(a): _conn_map[a] = []
		if not _conn_map.has(b): _conn_map[b] = []
		_conn_map[a].append(b - a)
		_conn_map[b].append(a - b)

	# 방 생성
	for gpos in rooms_data:
		var rdata: Dictionary = rooms_data[gpos]
		var room: Node3D      = RoomScript.new()
		room.grid_pos  = gpos
		room.has_light = rdata["has_light"]
		room.is_exit   = (gpos == _exit_pos)
		add_child(room)
		room.position = Vector3(gpos.x * ROOM_SIZE, 0.0, gpos.y * ROOM_SIZE)
		room.build(_conn_map.get(gpos, []))
		_rooms[gpos] = room

		if room.has_light and room.campfire_pos != Vector3.ZERO:
			_campfire_worlds.append(room.position + room.campfire_pos)


# ── 플레이어 ──────────────────────────────────────────────────────
func _setup_player() -> void:
	_player = PlayerScript.new()
	add_child(_player)
	_player.position = Vector3(0.0, 0.5, 0.0)


# ── 존재 ──────────────────────────────────────────────────────────
func _setup_entity() -> void:
	_entity = EntityScript.new()
	_entity.setup(_exit_pos, _conn_map)
	add_child(_entity)
	_entity.position = Vector3(_exit_pos.x * ROOM_SIZE, 0.5, _exit_pos.y * ROOM_SIZE)
	_entity.entered_room.connect(_on_entity_moved)


# ── 카메라 (아이소메트릭 직교 투영) ─────────────────────────────
func _setup_camera() -> void:
	_camera = Camera3D.new()
	_camera.projection       = Camera3D.PROJECTION_ORTHOGONAL
	_camera.size             = 14.0
	_camera.rotation_degrees = Vector3(-35.264, 45.0, 0.0)
	add_child(_camera)


# ── 메인 루프 ─────────────────────────────────────────────────────
func _process(delta: float) -> void:
	if _state == State.WIN or _state == State.LOSE:
		return

	# 카메라 추종
	var cam_target := _player.global_position + Vector3(8.0, 10.0, 8.0)
	_camera.global_position = _camera.global_position.lerp(cam_target, 12.0 * delta)

	if _state == State.PANIC:
		_panic_t -= delta
		if _panic_t <= 0.0:
			_state = State.PLAY
			_player.panicking = false
		return

	# 새벽 타이머
	_dawn_t -= delta
	if _dawn_t <= 0.0:
		_end_game("dawn")
		return

	# 존재 가속 (남은 시간 절반부터 점점 빨라짐)
	var elapsed_ratio := 1.0 - (_dawn_t / DAWN_TOTAL)
	_entity.accelerate(elapsed_ratio)

	# 공포 업데이트
	_update_fear(delta)

	# 출구 도달 확인
	var exit_world := Vector3(_exit_pos.x * ROOM_SIZE, 0.5, _exit_pos.y * ROOM_SIZE)
	if _player.global_position.distance_to(exit_world) < 2.5:
		_end_game("win")
		return

	_hud.update(_dawn_t, DAWN_TOTAL, _fear, FEAR_MAX)


func _update_fear(delta: float) -> void:
	var player_room := _grid_of(_player.global_position)

	# 모닥불 근접 여부
	var near_fire := false
	for fp in _campfire_worlds:
		if _player.global_position.distance_to(fp) < 3.5:
			near_fire = true
			break

	# 존재 인접 여부
	var entity_adj: bool = (player_room - _entity.current_room).length() <= 1
	_hud.set_warning(entity_adj)

	var rate: float
	if near_fire:
		rate = -15.0
	elif entity_adj:
		rate = 22.0
	else:
		rate = 8.0

	_fear = clampf(_fear + rate * delta, 0.0, FEAR_MAX)

	if _fear >= FEAR_MAX and _state == State.PLAY:
		_trigger_panic()


func _trigger_panic() -> void:
	_state          = State.PANIC
	_panic_t        = 3.0
	_fear           = 0.0
	_player.panicking = true


func _on_entity_moved(gpos: Vector2i) -> void:
	if gpos == _grid_of(_player.global_position):
		_end_game("entity")


func _grid_of(world: Vector3) -> Vector2i:
	return Vector2i(roundi(world.x / ROOM_SIZE), roundi(world.z / ROOM_SIZE))


func _end_game(reason: String) -> void:
	if _state == State.WIN or _state == State.LOSE:
		return
	match reason:
		"win":
			_state = State.WIN
			_hud.show_message("탈출 성공!\n새벽이 밝아온다...")
		"entity":
			_state = State.LOSE
			_hud.show_message("숲이 당신을 삼켰다...")
		"dawn":
			_state = State.LOSE
			_hud.show_message("새벽이 오지 않았다...")
	await get_tree().create_timer(3.5).timeout
	get_tree().reload_current_scene()
