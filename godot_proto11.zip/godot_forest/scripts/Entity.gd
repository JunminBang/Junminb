extends Node3D
## 숲의 존재. 방과 방 사이를 N초마다 이동.
## 플레이어 방에 들어오면 entered_room 시그널 → Main이 게임오버 처리.

signal entered_room(gpos: Vector2i)

const ROOM_SIZE := 10.0

var current_room: Vector2i = Vector2i.ZERO
var _connections: Dictionary = {}   # Vector2i → Array[Vector2i]
var _move_interval := 6.5           # 초마다 이동
var _move_t        := 0.0
var _tween: Tween  = null


func setup(start: Vector2i, connections: Dictionary) -> void:
	current_room = start
	_connections = connections


func _ready() -> void:
	# 시각 표현: 흐릿한 보라색 오브 (어둠 속에선 거의 안 보임)
	var mi  := MeshInstance3D.new()
	var sm  := SphereMesh.new()
	sm.radius = 0.35; sm.height = 0.7
	mi.mesh = sm; mi.position.y = 1.1
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.25, 0.0, 0.45)
	mat.emission_enabled = true
	mat.emission = Color(0.45, 0.0, 0.75)
	mat.emission_energy_multiplier = 1.8
	mi.material_override = mat
	add_child(mi)

	var light := OmniLight3D.new()
	light.light_color  = Color(0.55, 0.0, 0.85)
	light.omni_range   = 1.0
	light.light_energy = 0.5
	light.position.y   = 1.1
	add_child(light)


func _process(delta: float) -> void:
	_move_t += delta
	if _move_t >= _move_interval:
		_move_t = 0.0
		_step()


func _step() -> void:
	var neighbors: Array = _connections.get(current_room, [])
	if neighbors.is_empty():
		return
	var dir: Vector2i = neighbors[randi() % neighbors.size()]
	current_room += dir

	var target := Vector3(current_room.x * ROOM_SIZE, 0.5, current_room.y * ROOM_SIZE)
	if _tween:
		_tween.kill()
	_tween = create_tween()
	_tween.tween_property(self, "position", target, _move_interval * 0.55)

	entered_room.emit(current_room)


## 새벽이 다가올수록 존재가 빨라짐
func accelerate(factor: float) -> void:
	_move_interval = maxf(3.0, 6.5 * (1.0 - factor * 0.5))
