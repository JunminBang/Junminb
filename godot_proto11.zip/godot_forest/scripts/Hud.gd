extends CanvasLayer
## HUD: 새벽 타이머 / 공포 게이지 / 경고 / 메시지

var _dawn_fill:   ColorRect
var _fear_fill:   ColorRect
var _time_lbl:    Label
var _warning_lbl: Label
var _msg_lbl:     Label

const DAWN_W := 900.0
const FEAR_H := 180.0


func _ready() -> void:
	layer = 10
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	# ── 새벽 타이머 바 (상단 중앙) ──────────────────────────────
	var dawn_bg := _rect(root, Vector2(190, 10), Vector2(DAWN_W, 14), Color(0.10, 0.05, 0.02))
	dawn_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_dawn_fill = _rect(root, Vector2(190, 10), Vector2(DAWN_W, 14), Color(0.90, 0.50, 0.10))

	var dawn_lbl := _label(root, Vector2(190, 26), "새벽까지", Color(0.8, 0.55, 0.2), 11)
	dawn_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_time_lbl = _label(root, Vector2(1060, 26), "3:00", Color(0.8, 0.55, 0.2), 11)

	# ── 공포 게이지 (우측 수직) ─────────────────────────────────
	var fear_bg := _rect(root, Vector2(1238, 50), Vector2(18, FEAR_H), Color(0.10, 0.0, 0.12))
	fear_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fear_fill = _rect(root, Vector2(1238, 50 + FEAR_H), Vector2(18, 0), Color(0.75, 0.0, 0.95))

	_label(root, Vector2(1230, 50 + FEAR_H + 4), "공포", Color(0.7, 0.0, 0.9), 11).mouse_filter = Control.MOUSE_FILTER_IGNORE

	# ── 경고 메시지 ─────────────────────────────────────────────
	_warning_lbl = _label(root, Vector2(0, 55), "⚠  무언가가 느껴진다...", Color(0.85, 0.1, 0.1), 17)
	_warning_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_warning_lbl.size = Vector2(1280, 36)
	_warning_lbl.visible = false

	# ── 중앙 메시지 (클리어 / 게임오버) ────────────────────────
	_msg_lbl = _label(root, Vector2(340, 300), "", Color.WHITE, 28)
	_msg_lbl.size = Vector2(600, 120)
	_msg_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_msg_lbl.vertical_alignment   = VERTICAL_ALIGNMENT_CENTER
	_msg_lbl.visible = false

	# ── 조작 안내 (최초 표시) ────────────────────────────────────
	_label(root, Vector2(10, 695), "WASD: 이동   |   출구(파란 빛)를 찾아 탈출하라", Color(0.5, 0.5, 0.5), 11)


func _rect(parent: Control, pos: Vector2, sz: Vector2, col: Color) -> ColorRect:
	var cr := ColorRect.new()
	cr.position = pos; cr.size = sz; cr.color = col
	cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(cr)
	return cr


func _label(parent: Control, pos: Vector2, txt: String, col: Color, fsize: int) -> Label:
	var l := Label.new()
	l.position = pos; l.text = txt
	l.add_theme_color_override("font_color", col)
	l.add_theme_font_size_override("font_size", fsize)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(l)
	return l


func update(remaining: float, total: float, fear: float, fear_max: float) -> void:
	_dawn_fill.size.x = DAWN_W * clampf(remaining / total, 0.0, 1.0)

	var fr := clampf(fear / fear_max, 0.0, 1.0)
	var fh := FEAR_H * fr
	_fear_fill.size.y     = fh
	_fear_fill.position.y = 50.0 + FEAR_H - fh

	var s := int(remaining)
	_time_lbl.text = "%d:%02d" % [s / 60, s % 60]


func set_warning(show: bool) -> void:
	_warning_lbl.visible = show


func show_message(msg: String) -> void:
	_msg_lbl.text    = msg
	_msg_lbl.visible = true
