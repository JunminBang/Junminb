extends CharacterBody3D
## 플레이어. WASD 아이소메트릭 이동.
## panicking = true 동안 이동 불가 (공포 MAX 패닉 상태).

const SPEED := 5.0

var panicking := false


func _ready() -> void:
	collision_layer = 2
	collision_mask  = 1   # 벽(StaticBody3D) 충돌

	var cs  := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.0
	cs.shape = cap
	add_child(cs)

	# 시야 광원 (반경 ~1m)
	var light := OmniLight3D.new()
	light.light_color        = Color(0.85, 0.80, 0.65)
	light.omni_range         = 4.0
	light.light_energy       = 1.5
	light.omni_attenuation   = 1.5
	light.position.y         = 0.9
	add_child(light)


func _physics_process(_delta: float) -> void:
	if panicking:
		velocity = Vector3.ZERO
		move_and_slide()
		return

	# 아이소메트릭 이동 벡터 (카메라 45° 기준)
	var dir := Vector3.ZERO
	if Input.is_physical_key_pressed(KEY_W): dir += Vector3(-1, 0, -1)
	if Input.is_physical_key_pressed(KEY_S): dir += Vector3( 1, 0,  1)
	if Input.is_physical_key_pressed(KEY_A): dir += Vector3(-1, 0,  1)
	if Input.is_physical_key_pressed(KEY_D): dir += Vector3( 1, 0, -1)
	if dir.length() > 0:
		dir = dir.normalized()

	velocity = dir * SPEED
	move_and_slide()
	position.y = 0.5   # Y 고정 (경사 없음)
