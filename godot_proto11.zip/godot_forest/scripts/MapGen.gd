extends RefCounted
## 랜덤 방 배치 생성기.
## generate() → {rooms: Dict[Vector2i→{has_light}], connections: Array[[a,b]], start, exit}

static func generate() -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.randomize()

	var rooms: Dictionary = {}   # Vector2i → {has_light: bool}
	var connections: Array = []  # [[Vector2i, Vector2i], ...]
	var all_dirs := [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]

	# 메인 경로: 역방향 회피 드렁크 워크
	var pos  := Vector2i.ZERO
	var last := Vector2i(1, 0)
	rooms[pos] = {"has_light": false}

	for _i in (10 + rng.randi_range(0, 4)):
		var fwd: Array = all_dirs.filter(func(d): return d != -last)
		var d: Vector2i = fwd[rng.randi() % fwd.size()]
		var nxt := pos + d
		if not rooms.has(nxt):
			rooms[nxt] = {"has_light": rng.randf() < 0.30}
			connections.append([pos, nxt])
		pos  = nxt
		last = d

	var exit_pos := pos

	# 막다른 가지 추가
	var keys: Array = rooms.keys()
	for _b in (2 + rng.randi_range(0, 2)):
		var src: Vector2i = keys[rng.randi() % keys.size()]
		var d: Vector2i   = all_dirs[rng.randi() % all_dirs.size()]
		var dst := src + d
		if not rooms.has(dst):
			rooms[dst] = {"has_light": rng.randf() < 0.20}
			connections.append([src, dst])
			keys.append(dst)

	# 시작: 어둠, 출구: 빛
	rooms[Vector2i.ZERO]["has_light"] = false
	rooms[exit_pos]["has_light"]      = true

	return {
		"rooms":       rooms,
		"connections": connections,
		"start":       Vector2i.ZERO,
		"exit":        exit_pos,
	}
