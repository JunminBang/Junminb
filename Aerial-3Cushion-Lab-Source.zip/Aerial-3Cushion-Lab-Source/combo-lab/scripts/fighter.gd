extends Node2D
## Shared movement and drawing. Positions are feet on a single flat arena.
## Combat uses explicit rectangles so hit ranges and timing are easy to tune.

const FLOOR_Y: float = 554.0
var ceiling_y: float = 188.0
var left_wall: float = 64.0
var right_wall: float = 1216.0
const GRAVITY: float = 1550.0

var arena: Node
var velocity: Vector2 = Vector2.ZERO
var facing: float = 1.0
var hp: float = 100.0
var max_hp: float = 100.0
var stun: float = 0.0
var flash: float = 0.0
var invincible: float = 0.0
var dead: bool = false
var body_color: Color = Color("62ead2")
var airborne: bool = false
var body_width: float = 30.0
var body_height: float = 65.0
var show_health_bar: bool = true
var pose: String = "idle"
var clock: float = 0.0

func on_ground() -> bool:
	return position.y >= FLOOR_Y - 0.5

func hurtbox() -> Rect2:
	return Rect2(position + Vector2(-body_width * 0.5, -body_height), Vector2(body_width, body_height))

func integrate(delta: float) -> void:
	clock += delta
	stun = maxf(0.0, stun - delta)
	flash = maxf(0.0, flash - delta)
	invincible = maxf(0.0, invincible - delta)
	velocity.y += GRAVITY * delta
	position += velocity * delta
	position.x = clampf(position.x, left_wall + body_width * 0.5, right_wall - body_width * 0.5)
	if position.y < ceiling_y + body_height:
		position.y = ceiling_y + body_height
		velocity.y = maxf(0.0, velocity.y)
	if position.y >= FLOOR_Y:
		position.y = FLOOR_Y
		velocity.y = 0.0
	if arena != null:
		for pillar: Rect2 in arena.room_pillars:
			_resolve_pillar(pillar)
	airborne = not on_ground()
	queue_redraw()

func _resolve_pillar(pillar: Rect2) -> void:
	var bx: float = position.x - body_width * 0.5
	var by: float = position.y - body_height
	if bx + body_width <= pillar.position.x or bx >= pillar.end.x:
		return
	if by + body_height <= pillar.position.y or by >= pillar.end.y:
		return
	var pl: float = bx + body_width - pillar.position.x
	var pr: float = pillar.end.x - bx
	var pt: float = by + body_height - pillar.position.y
	var pb: float = pillar.end.y - by
	var mp: float = minf(minf(pl, pr), minf(pt, pb))
	if mp == pl:
		position.x = pillar.position.x - body_width * 0.5
		if velocity.x > 0.0: velocity.x = 0.0
	elif mp == pr:
		position.x = pillar.end.x + body_width * 0.5
		if velocity.x < 0.0: velocity.x = 0.0
	elif mp == pt:
		position.y = pillar.position.y
		if velocity.y > 0.0: velocity.y = 0.0
	elif mp == pb:
		position.y = pillar.end.y + body_height
		if velocity.y < 0.0: velocity.y = 0.0

func _draw() -> void:
	if dead:
		return
	var tint: Color = Color.WHITE if flash > 0.0 else body_color
	if invincible > 0.0 and int(clock * 22.0) % 2 == 0:
		tint.a = 0.45
	var bob: float = sin(clock * 5.0) * 1.5 if on_ground() else 0.0
	var lean: float = clampf(velocity.x / 90.0, -5.0, 5.0)
	var stride: float = sin(clock * 17.0) * 7.0 if absf(velocity.x) > 30.0 and on_ground() else 0.0
	var hip: Vector2 = Vector2(lean, -23.0 + bob)
	draw_line(hip, Vector2(-10.0 + stride, -2.0), tint.darkened(0.25), 7.0, true)
	draw_line(hip, Vector2(10.0 - stride, -2.0), tint, 7.0, true)
	var torso: PackedVector2Array = PackedVector2Array([
		Vector2(-14.0 + lean, -49.0 + bob), Vector2(12.0 + lean, -49.0 + bob),
		Vector2(9.0 + lean, -23.0 + bob), Vector2(-9.0 + lean, -23.0 + bob)])
	draw_colored_polygon(torso, tint)
	draw_rect(Rect2(lean - 10.0, -65.0 + bob, 21.0, 15.0), tint)
	draw_rect(Rect2(lean + (1.0 if facing > 0.0 else -10.0), -61.0 + bob, 10.0, 4.0), Color("0c1827"))
	var hand: Vector2 = Vector2(facing * 21.0 + lean, -33.0 + bob)
	if pose == "attack":
		hand = Vector2(facing * 41.0, -40.0)
	elif pose == "launch":
		hand = Vector2(facing * 19.0, -76.0)
	draw_line(Vector2(lean, -44.0 + bob), hand, tint.lightened(0.2), 7.0, true)
	draw_line(hand, hand + Vector2(facing * 17.0, -17.0), Color("edfaff"), 4.0, true)
	if show_health_bar and body_color != Color("62ead2"):
		draw_rect(Rect2(-22.0, -80.0, 44.0, 4.0), Color("283245"))
		draw_rect(Rect2(-22.0, -80.0, 44.0 * maxf(0.0, hp / max_hp), 4.0), body_color)
