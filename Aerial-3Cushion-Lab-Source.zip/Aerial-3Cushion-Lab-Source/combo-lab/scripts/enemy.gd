extends "res://scripts/fighter.gd"
## Damage is banked during a combo and committed once its final beat resolves.
## Ricochets use substeps, directional wall tests and one event per corner contact.

const SHOT_DURATION: float = 3.2
const MAX_CUSHIONS: int = 3
const SETTLE_DELAY: float = 0.28
const HIT_CHAIN_TIMEOUT: float = 1.05

var windup: float = 0.0
var cooldown: float = 0.6
var attack_direction: float = 1.0
var thrown: bool = false
var thrown_hit_ids: Array[int] = []
var move_speed: float = 90.0
var attack_damage: float = 10.0
var pending_damage: float = 0.0
var pending_timer: float = 0.0
var cushions: int = 0
var shot_age: float = 0.0
var settle_timer: float = 0.0
var settling: bool = false
var contact_cooldown: float = 0.0
var trail: Array[Vector2] = []
var trail_timer: float = 0.0

func _ready() -> void:
	body_color = Color("ff7c91")
	show_health_bar = false

func tick(delta: float) -> void:
	if dead:
		return
	if settling:
		clock += delta
		settle_timer -= delta
		if settle_timer <= 0.0:
			resolve_damage()
		queue_redraw()
		return
	if thrown:
		clock += delta
		flash = maxf(0.0, flash - delta)
		contact_cooldown = maxf(0.0, contact_cooldown - delta)
		shot_age += delta
		integrate_ricochet(delta)
		trail_timer -= delta
		if trail_timer <= 0.0:
			trail.append(position + Vector2(0.0, -32.0))
			if trail.size() > 14:
				trail.pop_front()
			trail_timer = 0.025
		if shot_age >= SHOT_DURATION or cushions >= MAX_CUSHIONS:
			finish_sequence()
		queue_redraw()
		return
	if pending_damage > 0.0:
		pending_timer -= delta
		if pending_timer <= 0.0:
			finish_sequence()
			return
	cooldown = maxf(0.0, cooldown - delta)
	if stun > 0.0 or not on_ground():
		windup = 0.0
		pose = "idle"
		velocity.x = move_toward(velocity.x, 0.0, 380.0 * delta)
	elif windup > 0.0:
		velocity.x = 0.0
		windup -= delta
		if windup <= 0.0:
			strike()
	else:
		var offset: float = arena.player.position.x - position.x
		facing = 1.0 if offset >= 0.0 else -1.0
		pose = "idle"
		if absf(offset) < 76.0 and absf(arena.player.position.y - position.y) < 80.0 and cooldown <= 0.0:
			windup = 0.52
			attack_direction = facing
			velocity.x = 0.0
		else:
			velocity.x = facing * move_speed if absf(offset) > 51.0 else 0.0
	integrate(delta)

func strike() -> void:
	cooldown = 1.15
	pose = "attack"
	var box: Rect2 = Rect2(position + Vector2(-16.0 if attack_direction > 0.0 else -91.0, -74.0), Vector2(107.0, 78.0))
	arena.enemy_swing(position + Vector2(attack_direction * 50.0, -33.0))
	if box.intersects(arena.player.hurtbox()):
		arena.player.take_hit(attack_damage, Vector2(attack_direction * 290.0, -200.0))

func bank_damage(damage: float) -> void:
	if dead:
		return
	pending_damage += maxf(0.0, damage)
	pending_timer = HIT_CHAIN_TIMEOUT
	flash = 0.10
	queue_redraw()

func take_hit(damage: float, force: Vector2, hit_stun: float, is_throw: bool = false) -> void:
	if dead:
		return
	bank_damage(damage)
	windup = 0.0
	if settling:
		return
	if thrown:
		# Re-hits can redirect the shot, but cannot reset its timer or cushion damage.
		if is_throw:
			velocity = force
		return
	stun = hit_stun
	velocity = force
	if is_throw:
		thrown = true
		cushions = 0
		shot_age = 0.0
		contact_cooldown = 0.20
		thrown_hit_ids.clear()
		trail.clear()
		pose = "attack"

func integrate_ricochet(delta: float) -> void:
	var remaining: float = delta
	var left: float = left_wall + body_width * 0.5
	var right: float = right_wall - body_width * 0.5
	var top: float = ceiling_y + body_height
	while remaining > 0.00001 and cushions < MAX_CUSHIONS:
		var step: float = minf(remaining, 1.0 / 240.0)
		remaining -= step
		position += velocity * step
		var contact: Vector2 = position + Vector2(0.0, -32.0)
		var bounced: bool = false
		if position.x <= left and velocity.x < 0.0:
			position.x = left
			velocity.x = absf(velocity.x) * 0.96
			contact.x = left_wall
			bounced = true
		elif position.x >= right and velocity.x > 0.0:
			position.x = right
			velocity.x = -absf(velocity.x) * 0.96
			contact.x = right_wall
			bounced = true
		if position.y <= top and velocity.y < 0.0:
			position.y = top
			velocity.y = absf(velocity.y) * 0.96
			contact.y = ceiling_y
			bounced = true
		elif position.y >= FLOOR_Y and velocity.y > 0.0:
			position.y = FLOOR_Y
			velocity.y = -absf(velocity.y) * 0.96
			contact.y = FLOOR_Y
			bounced = true
		for pillar: Rect2 in arena.room_pillars:
			var ex_l: float = position.x - body_width * 0.5
			var ex_r: float = position.x + body_width * 0.5
			var ex_t: float = position.y - body_height
			var ex_b: float = position.y
			if ex_r <= pillar.position.x or ex_l >= pillar.end.x or ex_b <= pillar.position.y or ex_t >= pillar.end.y:
				continue
			var pl: float = ex_r - pillar.position.x
			var pr: float = pillar.end.x - ex_l
			var pt: float = ex_b - pillar.position.y
			var pb: float = pillar.end.y - ex_t
			var mp: float = minf(minf(pl, pr), minf(pt, pb))
			if mp == pl and velocity.x > 0.0:
				position.x = pillar.position.x - body_width * 0.5
				velocity.x = -absf(velocity.x) * 0.96
				contact = Vector2(pillar.position.x, position.y - 32.0)
				bounced = true
			elif mp == pr and velocity.x < 0.0:
				position.x = pillar.end.x + body_width * 0.5
				velocity.x = absf(velocity.x) * 0.96
				contact = Vector2(pillar.end.x, position.y - 32.0)
				bounced = true
			elif mp == pt and velocity.y > 0.0:
				position.y = pillar.position.y
				velocity.y = -absf(velocity.y) * 0.96
				contact = Vector2(position.x, pillar.position.y)
				bounced = true
			elif mp == pb and velocity.y < 0.0:
				position.y = pillar.end.y + body_height
				velocity.y = absf(velocity.y) * 0.96
				contact = Vector2(position.x, pillar.end.y)
				bounced = true
		position.x = clampf(position.x, left, right)
		position.y = clampf(position.y, top, FLOOR_Y)
		if bounced:
			on_cushion(contact)
		check_thrown_contacts()
	airborne = not on_ground()

func on_cushion(contact: Vector2) -> void:
	if dead or settling or cushions >= MAX_CUSHIONS:
		return
	cushions += 1
	var damage: float = (12.0 + 5.0 * (cushions - 1)) * arena.player.cushion_scale
	bank_damage(damage)
	arena.register_cushion(self, contact, damage)
	if arena.player.chain_lightning and cushions % 3 == 0:
		arena.lightning(self)

func check_thrown_contacts() -> void:
	for other in arena.enemies:
		if other == self or other.dead or thrown_hit_ids.has(other.get_instance_id()):
			continue
		if hurtbox().grow(3.0).intersects(other.hurtbox()):
			thrown_hit_ids.append(other.get_instance_id())
			other.take_hit(4.0, Vector2(signf(velocity.x) * 190.0, -180.0), 0.35)
			arena.register_hit(other.position + Vector2(0.0, -30.0), 4.0, false, false)
	if shot_age >= 0.20 and contact_cooldown <= 0.0 and arena.phase == "fight":
		if hurtbox().intersects(arena.player.hurtbox()):
			arena.player.take_hit(attack_damage, Vector2(signf(velocity.x) * 320.0, -210.0))
			contact_cooldown = 0.45

func finish_sequence() -> void:
	if dead or settling:
		return
	thrown = false
	settling = true
	settle_timer = SETTLE_DELAY
	velocity = Vector2.ZERO
	windup = 0.0
	pose = "idle"

func resolve_damage() -> void:
	if dead:
		return
	var total: float = pending_damage
	var lethal: bool = total >= hp
	hp = maxf(0.0, hp - total)
	pending_damage = 0.0
	pending_timer = 0.0
	settling = false
	thrown = false
	trail.clear()
	if lethal:
		dead = true
		arena.detonate(self, total)
	else:
		arena.damage_survived(self, total)
		stun = 0.32
		cooldown = 0.6
		velocity = Vector2(0.0, 60.0)
	cushions = 0
	queue_redraw()

func _draw() -> void:
	if dead:
		return
	var armed: bool = pending_damage >= hp
	var glow: Color = Color("ffc678") if armed else Color("88b9ff")
	if thrown or settling:
		for i in range(1, trail.size()):
			var color: Color = glow
			color.a = float(i) / trail.size() * 0.45
			draw_line(trail[i - 1] - position, trail[i] - position, color, 3.0, true)
		draw_arc(Vector2(0.0, -32.0), 41.0 + sin(clock * 18.0) * 2.0, 0.0, TAU, 32, glow, 2.0, true)
		if armed:
			draw_circle(Vector2(0.0, -32.0), 36.0, Color(1.0, 0.65, 0.2, 0.16))
	super._draw()
	var bar_y: float = maxf(-82.0, ceiling_y + 5.0 - position.y)
	draw_rect(Rect2(-25.0, bar_y, 50.0, 5.0), Color("283245"))
	draw_rect(Rect2(-25.0, bar_y, 50.0 * hp / max_hp, 5.0), body_color)
	if pending_damage > 0.0:
		var remaining: float = maxf(0.0, hp - pending_damage) / max_hp
		draw_rect(Rect2(-25.0 + 50.0 * remaining, bar_y, 50.0 * minf(hp, pending_damage) / max_hp, 5.0), glow)
		var text_y: float = maxf(-94.0, ceiling_y + 22.0 - position.y)
		var caption: String = "%d / %d" % [ceili(pending_damage), ceili(hp)]
		if armed:
			caption = "폭발 대기 " + caption
		elif cushions > 0:
			caption = "%d쿠션 " % cushions + caption
		draw_string(arena.font, Vector2(-49.0, text_y), caption, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 12, glow)
	if windup > 0.0:
		var progress: float = 1.0 - windup / 0.52
		draw_arc(Vector2(0.0, -34.0), 44.0, -PI * 0.5, -PI * 0.5 + TAU * progress, 24, Color("ffc678"), 3.0, true)
		draw_line(Vector2(0.0, -5.0), Vector2(attack_direction * 83.0, -5.0), Color(1.0, 0.45, 0.45, 0.35), 5.0)
