extends "res://scripts/fighter.gd"

const SPEED: float = 300.0
const ATTACK_DURATION: float = 0.30
const ACTIVE_START: float = 0.065
const ACTIVE_END: float = 0.17
const BUFFER_TIME: float = 0.22

var attack_time: float = 0.0
var attack_kind: String = ""
var attack_step: int = 0
var chain_step: int = 0
var chain_window: float = 0.0
var attack_buffer: float = 0.0
var launch_buffer: float = 0.0
var hit_ids: Array[int] = []
var dash_time: float = 0.0
var dash_cooldown: float = 0.0
var launch_cooldown: float = 0.0
var damage_scale: float = 1.0
var cushion_scale: float = 1.0
var air_bonus: float = 0.0
var launch_bonus: float = 0.0
var dash_recovery: float = 0.65
var wall_blast: bool = false
var chain_lightning: bool = false
var life_on_kill: float = 0.0
var air_hits: int = 0
var trail_clock: float = 0.0

func _ready() -> void:
	hp = 100.0
	max_hp = 100.0
	body_color = Color("62ead2")

func tick(delta: float) -> void:
	if dead:
		return
	attack_buffer = maxf(0.0, attack_buffer - delta)
	launch_buffer = maxf(0.0, launch_buffer - delta)
	chain_window = maxf(0.0, chain_window - delta)
	dash_cooldown = maxf(0.0, dash_cooldown - delta)
	launch_cooldown = maxf(0.0, launch_cooldown - delta)
	if chain_window <= 0.0 and attack_kind.is_empty():
		chain_step = 0
	if Input.is_action_just_pressed("attack"):
		attack_buffer = BUFFER_TIME
	if Input.is_action_just_pressed("launch"):
		launch_buffer = BUFFER_TIME
	var axis: float = Input.get_axis("move_left", "move_right")
	if absf(axis) > 0.1 and attack_kind.is_empty() and dash_time <= 0.0:
		facing = signf(axis)
	if Input.is_action_just_pressed("dash") and dash_cooldown <= 0.0 and stun <= 0.0:
		start_dash()
	if dash_time > 0.0:
		dash_time -= delta
		velocity.x = facing * 820.0
		velocity.y = minf(velocity.y, 0.0)
		trail_clock -= delta
		if trail_clock <= 0.0:
			arena.burst(position + Vector2(0.0, -30.0), body_color, 3)
			trail_clock = 0.035
	elif stun > 0.0:
		velocity.x = move_toward(velocity.x, 0.0, 700.0 * delta)
	else:
		if attack_kind.is_empty():
			velocity.x = move_toward(velocity.x, axis * SPEED, 2400.0 * delta)
			if Input.is_action_just_pressed("jump") and on_ground():
				velocity.y = -610.0
				arena.sound("jump")
			if launch_buffer > 0.0 and launch_cooldown <= 0.0:
				begin_attack("launch")
			elif attack_buffer > 0.0:
				begin_attack("normal")
		else:
			velocity.x = move_toward(velocity.x, axis * SPEED * 0.22, 1600.0 * delta)
		if not attack_kind.is_empty():
			attack_time += delta
			if attack_time >= ACTIVE_START and attack_time <= ACTIVE_END:
				resolve_attack()
			if attack_time >= ATTACK_DURATION:
				attack_kind = ""
				pose = "idle"
				chain_window = 0.46
			elif attack_time >= 0.20:
				if launch_buffer > 0.0 and launch_cooldown <= 0.0:
					begin_attack("launch")
				elif attack_buffer > 0.0:
					begin_attack("normal")
	integrate(delta)
	if on_ground():
		air_hits = 0

func start_dash() -> void:
	dash_time = 0.17
	dash_cooldown = dash_recovery
	invincible = 0.22
	attack_kind = ""
	attack_buffer = 0.0
	launch_buffer = 0.0
	pose = "idle"
	arena.sound("dash")

func begin_attack(kind: String) -> void:
	attack_kind = kind
	attack_time = 0.0
	hit_ids.clear()
	if kind == "launch":
		launch_buffer = 0.0
		attack_buffer = 0.0
		launch_cooldown = 0.8
		attack_step = 0
		chain_step = 0
		pose = "launch"
		velocity.y = -660.0 - launch_bonus
		velocity.x = facing * 75.0
	else:
		attack_buffer = 0.0
		attack_step = chain_step
		chain_step = (chain_step + 1) % 3
		pose = "attack"
		velocity.x = facing * 110.0
		if not on_ground():
			velocity.y = minf(velocity.y, -110.0)
	arena.slash(position + Vector2(facing * 44.0, -40.0), facing, kind == "launch", attack_step == 2)
	arena.sound("swing")

func attack_rect() -> Rect2:
	var width: float = 115.0 if attack_kind == "launch" else 100.0
	var top: float = -102.0 if attack_kind == "launch" else -86.0
	var height: float = 132.0 if attack_kind == "launch" else 92.0
	return Rect2(position + Vector2(-18.0 if facing > 0.0 else -width + 18.0, top), Vector2(width, height))

func resolve_attack() -> void:
	var box: Rect2 = attack_rect()
	for enemy in arena.enemies:
		if enemy.dead or hit_ids.has(enemy.get_instance_id()) or not box.intersects(enemy.hurtbox()):
			continue
		hit_ids.append(enemy.get_instance_id())
		var was_airborne: bool = not enemy.on_ground()
		var damage: float = (7.0 if attack_kind == "launch" else [5.0, 8.0, 12.0][attack_step]) * damage_scale
		var force: Vector2 = Vector2(facing * 105.0, -80.0)
		var launches: bool = attack_kind == "launch"
		var finisher: bool = not launches and attack_step == 2
		if launches:
			force = Vector2(facing * 65.0, -720.0 - launch_bonus)
		elif finisher:
			force = Vector2(facing * 1150.0, -520.0)
		elif was_airborne:
			force = Vector2(facing * 65.0, -180.0)
		if was_airborne:
			damage *= 1.0 + air_bonus
			air_hits += 1
		enemy.take_hit(damage, force, 0.42, finisher)
		arena.register_hit(enemy.position + Vector2(0.0, -35.0), damage, was_airborne, finisher)

		if was_airborne and not launches and not finisher:
			velocity.y = minf(velocity.y, -140.0)

func take_hit(damage: float, force: Vector2) -> void:
	if invincible > 0.0 or dead:
		return
	hp = maxf(0.0, hp - damage)
	stun = 0.20
	invincible = 0.85
	flash = 0.15
	velocity = force
	attack_kind = ""
	attack_buffer = 0.0
	launch_buffer = 0.0
	pose = "idle"
	arena.combo = 0
	arena.burst(position + Vector2(0.0, -30.0), Color("ff657d"), 14)
	arena.shake = 8.0
	arena.sound("hurt")
	if hp <= 0.0:
		dead = true
		arena.finish_run(false)
