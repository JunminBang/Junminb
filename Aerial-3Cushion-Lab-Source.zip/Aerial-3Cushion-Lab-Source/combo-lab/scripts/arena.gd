extends Node2D
## Side-scrolling arena with varied room shapes and internal pillars.

const PlayerScript = preload("res://scripts/player.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
const TOTAL_ROOMS: int = 6
const FLOOR_Y: float = 554.0
const ROOM_GAP: float = 160.0
const TRANSITION_DURATION: float = 0.5
const CYAN: Color = Color("62ead2")
const INK: Color = Color("0b111e")
const MUTED: Color = Color("8293ac")
const UPGRADES: Array[Dictionary] = [
	{"id": "power", "name": "단단한 쿠션", "tag": "CUSHION", "desc": "벽·천장·바닥 반사 피해 +25%p", "color": "62ead2"},
	{"id": "air", "name": "연속 충격", "tag": "BOUNCE", "desc": "벽·천장·바닥 반사 피해 +20%p", "color": "88b9ff"},
	{"id": "lightning", "name": "삼각 방전", "tag": "3-CUSHION", "desc": "3번째 반사에 주변 적 최대 2명에게\n누적 피해 18 추가", "color": "88b9ff"},
	{"id": "wall", "name": "연쇄 폭발", "tag": "FINISH", "desc": "마지막에 적이 폭발하면\n주변 적에게 누적 피해 24 추가", "color": "ffc678"},
	{"id": "dash", "name": "가벼운 발걸음", "tag": "MOBILITY", "desc": "회피 재사용 대기시간 0.65초 → 0.40초", "color": "62ead2"},
	{"id": "vitality", "name": "두 번째 호흡", "tag": "SURVIVE", "desc": "최대 체력 +25 / 체력 35 회복", "color": "ff7c91"},
	{"id": "leech", "name": "전투의 리듬", "tag": "RECOVER", "desc": "적을 처치할 때마다 체력 3 회복", "color": "ff7c91"},
	{"id": "launch", "name": "상승 기류", "tag": "LAUNCH", "desc": "띄우기 상승 속도 +90\n공중 적에게 주는 직접 공격 피해 +15%p", "color": "c2a3ff"}
]
# 방별 레벨 디자인: 폭, 천장 높이, 내부 기둥, 적 배치
# pillars: [{x, y, w, h}] — 방 왼쪽·천장 기준 오프셋
const ROOM_DEFS: Array[Dictionary] = [
	# 0: 입구 — 표준 비율, 기둥 없음 (튜토리얼)
	{"width": 1152, "ceiling": 188, "pillars": [], "enemies": 3, "hp": 60.0, "speed": 82.0, "atk": 9.0},
	# 1: 수직 통로 — 좁고 높음, 천장·바닥 바운스 지배적
	{"width": 500, "ceiling": 54, "pillars": [], "enemies": 4, "hp": 72.0, "speed": 87.0, "atk": 10.0},
	# 2: 기둥 광장 — 중앙 기둥이 경로를 갈라놓음
	{"width": 1100, "ceiling": 188, "pillars": [{"x": 470, "y": 60, "w": 160, "h": 200}], "enemies": 5, "hp": 80.0, "speed": 92.0, "atk": 11.0},
	# 3: 압축 회랑 — 매우 낮은 천장, 수평 핑퐁
	{"width": 1200, "ceiling": 354, "pillars": [], "enemies": 6, "hp": 90.0, "speed": 97.0, "atk": 12.0},
	# 4: 미로 — 두 기둥이 세 개의 레인을 만듦
	{"width": 900, "ceiling": 104, "pillars": [{"x": 250, "y": 80, "w": 100, "h": 300}, {"x": 550, "y": 80, "w": 100, "h": 300}], "enemies": 7, "hp": 100.0, "speed": 102.0, "atk": 13.0},
	# 5: 최종전 — 크고 높은 방, 게이트 기둥
	{"width": 1200, "ceiling": 34, "pillars": [{"x": 500, "y": 150, "w": 200, "h": 220}], "enemies": 8, "hp": 110.0, "speed": 107.0, "atk": 14.0},
]
const ROOM_NAMES: Array[String] = ["입 구", "수직 통로", "기둥 광장", "압축 회랑", "미 로", "최종전"]

var rooms: Array[Dictionary] = []
var current_room: int = 0
var room_pillars: Array[Rect2] = []
var player: Node2D
var enemies: Array[Node2D] = []
var world: Node2D
var camera: Camera2D
var phase: String = "title"
var wave: int = 0
var combo: int = 0
var best_combo: int = 0
var best_cushions: int = 0
var last_cushions: int = 0
var cushion_feedback: float = 0.0
var cushion_caption: String = ""
var combo_timeout: float = 0.0
var kills: int = 0
var elapsed: float = 0.0
var hit_stop: float = 0.0
var shake: float = 0.0
var intermission: float = 0.0
var ui_clock: float = 0.0
var effects: Array[Dictionary] = []
var chosen: Dictionary = {}
var offered: Array[Dictionary] = []
var font: SystemFont
var hud: Control
var modal: Control
var health_fill: ColorRect
var health_label: Label
var wave_label: Label
var count_label: Label
var combo_label: Label
var combo_caption: Label
var tip_label: Label
var cooldown_label: Label
var build_label: Label
var sound_on: bool = true
var audio_players: Array[AudioStreamPlayer] = []
var tones: Dictionary = {}
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var debug_boxes: bool = false
var capture_target: String = ""
var capture_ticks: int = 0
var transition_timer: float = 0.0
var transition_start_x: float = 0.0
var transition_end_x: float = 0.0

func _ready() -> void:
	rng.randomize()
	build_rooms()
	setup_input()
	font = SystemFont.new()
	font.font_names = PackedStringArray(["Malgun Gothic", "Noto Sans CJK KR", "Segoe UI"])
	world = Node2D.new()
	add_child(world)
	camera = Camera2D.new()
	camera.position = Vector2(640.0, 360.0)
	add_child(camera)
	camera.make_current()
	setup_audio()
	setup_hud()
	show_title()
	var args: PackedStringArray = OS.get_cmdline_user_args()
	for i in range(args.size()):
		if args[i] == "--capture" and i + 1 < args.size():
			capture_target = args[i + 1]
			start_run()
			player.position.x = 430.0
			enemies[0].position = Vector2(1000.0, 370.0)
			enemies[0].take_hit(9.0, Vector2(1050.0, -450.0), 0.4, true)
			enemies[0].on_cushion(Vector2(64.0, 310.0))
			enemies[0].on_cushion(Vector2(640.0, 188.0))
			enemies[0].on_cushion(Vector2(1216.0, 400.0))
		if args[i] == "--capture-title" and i + 1 < args.size():
			capture_target = args[i + 1]
		if args[i] == "--capture-upgrade" and i + 1 < args.size():
			capture_target = args[i + 1]
			start_run()
			show_upgrades()

func build_rooms() -> void:
	rooms.clear()
	var x: float = 64.0
	for def: Dictionary in ROOM_DEFS:
		var room_top: float = float(def.ceiling)
		var pillars_world: Array[Rect2] = []
		for p: Dictionary in def.pillars:
			pillars_world.append(Rect2(x + float(p.x), room_top + float(p.y), float(p.w), float(p.h)))
		rooms.append({
			"left": x, "right": x + float(def.width), "top": room_top,
			"pillars": pillars_world,
			"enemies": int(def.enemies), "hp": float(def.hp),
			"speed": float(def.speed), "atk": float(def.atk),
		})
		x += float(def.width) + ROOM_GAP

func setup_input() -> void:
	var bindings: Dictionary = {
		"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"jump": [KEY_SPACE], "attack": [KEY_J], "launch": [KEY_K], "dash": [KEY_L, KEY_SHIFT]
	}
	for action: String in bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key: int in bindings[action]:
			var event: InputEventKey = InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	match event.physical_keycode:
		KEY_ENTER:
			if phase == "title" or phase == "lost" or phase == "won":
				start_run()
		KEY_ESCAPE:
			if phase == "fight":
				phase = "pause"
				show_pause()
			elif phase == "pause":
				resume_game()
		KEY_R:
			if phase == "lost" or phase == "won" or phase == "pause":
				start_run()
		KEY_M:
			sound_on = not sound_on
		KEY_F3:
			debug_boxes = not debug_boxes
		KEY_1, KEY_2, KEY_3:
			if phase == "upgrade":
				choose_upgrade(event.physical_keycode - KEY_1)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and phase == "fight" and capture_target.is_empty():
		phase = "pause"
		show_pause()

func _physics_process(delta: float) -> void:
	ui_clock += delta
	cushion_feedback = maxf(0.0, cushion_feedback - delta)
	update_effects(delta)
	shake = move_toward(shake, 0.0, delta * 35.0)
	world.position = Vector2(rng.randf_range(-shake, shake), rng.randf_range(-shake, shake)) if shake > 0.1 else Vector2.ZERO
	if phase == "fight":
		if hit_stop > 0.0:
			hit_stop -= delta
		else:
			elapsed += delta
			combo_timeout -= delta
			if combo_timeout <= 0.0:
				combo = 0
			player.tick(delta)
			if phase == "fight":
				for enemy in enemies:
					enemy.tick(delta)
				if alive_count() == 0:
					intermission += delta
					if intermission > 0.8:
						if wave >= TOTAL_ROOMS:
							finish_run(true)
						else:
							show_upgrades()
	elif phase == "transition":
		transition_timer += delta
		var t: float = minf(transition_timer / TRANSITION_DURATION, 1.0)
		t = t * t * (3.0 - 2.0 * t)
		player.position.x = lerpf(transition_start_x, transition_end_x, t)
		player.position.y = FLOOR_Y
		player.velocity = Vector2.ZERO
		player.facing = 1.0
		player.pose = "idle"
		player.queue_redraw()
		if transition_timer >= TRANSITION_DURATION:
			enter_room(current_room + 1)
	update_camera()
	update_hud()
	queue_redraw()
	if not capture_target.is_empty():
		capture_ticks += 1
		if capture_ticks == 12:
			capture_frame.call_deferred()

func capture_frame() -> void:
	await RenderingServer.frame_post_draw
	var result: Error = get_viewport().get_texture().get_image().save_png(capture_target)
	print("CAPTURE_RESULT ", result)
	get_tree().quit(int(result))

func update_camera() -> void:
	if not is_instance_valid(player):
		return
	var target_x: float = player.position.x
	var target_y: float = 360.0
	if current_room < rooms.size():
		var room: Dictionary = rooms[current_room]
		target_y = (float(room.top) + FLOOR_Y) * 0.5
		var room_width: float = room.right - room.left
		if phase == "fight" or phase == "upgrade" or phase == "pause":
			if room_width <= 1280.0:
				target_x = (room.left + room.right) * 0.5
			else:
				target_x = clampf(player.position.x, room.left + 640.0, room.right - 640.0)
		elif phase in ["title", "won", "lost"]:
			target_x = (room.left + room.right) * 0.5
	camera.position = camera.position.lerp(Vector2(target_x, target_y), 0.12)

func start_run() -> void:
	clear_modal()
	for child in world.get_children():
		child.free()
	enemies.clear()
	effects.clear()
	chosen.clear()
	room_pillars.clear()
	current_room = 0
	wave = 0
	combo = 0
	best_combo = 0
	best_cushions = 0
	last_cushions = 0
	cushion_feedback = 0.0
	kills = 0
	elapsed = 0.0
	hit_stop = 0.0
	shake = 0.0
	combo_timeout = 0.0
	transition_timer = 0.0
	player = PlayerScript.new()
	player.arena = self
	world.add_child(player)
	var room: Dictionary = rooms[0]
	camera.position = Vector2((room.left + room.right) * 0.5, (float(room.top) + FLOOR_Y) * 0.5)
	phase = "fight"
	enter_room(0)

func enter_room(index: int) -> void:
	for enemy in enemies:
		enemy.free()
	enemies.clear()
	current_room = index
	wave = index + 1
	intermission = 0.0
	var room: Dictionary = rooms[index]
	room_pillars = room.pillars
	player.left_wall = room.left
	player.right_wall = room.right
	player.ceiling_y = float(room.top)
	player.position = Vector2(room.left + 80.0, FLOOR_Y)
	player.velocity = Vector2.ZERO
	player.stun = 0.0
	player.attack_kind = ""
	player.pose = "idle"
	player.chain_step = 0
	player.attack_buffer = 0.0
	player.launch_buffer = 0.0
	player.dash_time = 0.0
	player.invincible = 0.7
	for i in range(int(room.enemies)):
		var enemy: Node2D = EnemyScript.new()
		enemy.arena = self
		enemy.left_wall = room.left
		enemy.right_wall = room.right
		enemy.ceiling_y = float(room.top)
		enemy.max_hp = room.hp
		enemy.hp = room.hp
		enemy.move_speed = room.speed + float(i) * 3.0
		enemy.attack_damage = room.atk
		# 기둥 피해서 배치
		var spawn_x: float = room.right - 100.0 - float(i % 4) * 90.0
		if i % 2 == 1:
			spawn_x = room.left + 100.0 + float(i % 4) * 80.0
		if absf(spawn_x - player.position.x) < 200.0:
			spawn_x = room.right - 120.0
		for pillar: Rect2 in room_pillars:
			if spawn_x > pillar.position.x - 40.0 and spawn_x < pillar.end.x + 40.0:
				spawn_x = pillar.end.x + 60.0
		enemy.position = Vector2(clampf(spawn_x, room.left + 40.0, room.right - 40.0), FLOOR_Y)
		enemy.cooldown = 0.9 + float(i) * 0.14
		world.add_child(enemy)
		enemies.append(enemy)
		burst(enemy.position + Vector2(0.0, -25.0), Color("ff7c91"), 12)
	phase = "fight"

func start_transition() -> void:
	phase = "transition"
	transition_timer = 0.0
	transition_start_x = player.position.x
	var next_room: Dictionary = rooms[current_room + 1]
	transition_end_x = next_room.left + 80.0
	player.right_wall = next_room.right

func alive_count() -> int:
	var count: int = 0
	for enemy in enemies:
		if not enemy.dead:
			count += 1
	return count

func enemy_defeated(enemy: Node2D) -> void:
	kills += 1
	burst(enemy.position + Vector2(0.0, -32.0), Color("ff7c91"), 20)
	player.hp = minf(player.max_hp, player.hp + player.life_on_kill)
	enemy.queue_redraw()
	sound("kill")

func register_hit(point: Vector2, damage: float, aerial: bool, finisher: bool) -> void:
	combo += 1
	best_combo = maxi(best_combo, combo)
	combo_timeout = 2.0
	hit_stop = maxf(hit_stop, 0.065 if finisher else 0.035)
	shake = 6.0 if finisher else 2.5
	burst(point, Color("ffc678") if finisher else CYAN, 14 if finisher else 8)
	effects.append({"kind": "text", "pos": point + Vector2(rng.randf_range(-10.0, 10.0), -30.0), "vel": Vector2(0.0, -52.0), "life": 0.65, "max": 0.65, "text": str(int(damage)), "color": Color("ffc678") if aerial else Color.WHITE})
	sound("heavy" if finisher else "hit")

func lightning(source: Node2D) -> void:
	var targets: int = 0
	for enemy in enemies:
		if enemy == source or enemy.dead or enemy.position.distance_to(source.position) > 300.0:
			continue
		enemy.bank_damage(18.0)
		effects.append({"kind": "bolt", "pos": source.position + Vector2(0.0, -35.0), "end": enemy.position + Vector2(0.0, -35.0), "life": 0.25, "max": 0.25, "color": Color("88b9ff")})
		register_hit(enemy.position + Vector2(0.0, -35.0), 18.0, true, false)
		targets += 1
		if targets >= 2:
			break

func explode(point: Vector2, radius: float, damage: float, source: Node2D) -> void:
	effects.append({"kind": "ring", "pos": point + Vector2(0.0, -30.0), "radius": radius, "life": 0.35, "max": 0.35, "color": Color("ffc678")})
	for enemy in enemies:
		if enemy == source or enemy.dead or enemy.position.distance_to(point) > radius:
			continue
		enemy.bank_damage(damage)
		register_hit(enemy.position + Vector2(0.0, -30.0), damage, false, true)

func burst(point: Vector2, color: Color, count: int) -> void:
	for i in range(count):
		var angle: float = rng.randf_range(0.0, TAU)
		var life: float = rng.randf_range(0.18, 0.45)
		effects.append({"kind": "spark", "pos": point, "vel": Vector2.from_angle(angle) * rng.randf_range(70.0, 280.0), "life": life, "max": life, "color": color})

func slash(point: Vector2, direction: float, launch: bool, heavy: bool) -> void:
	effects.append({"kind": "slash", "pos": point, "face": direction, "launch": launch, "radius": 64.0 if heavy else 48.0, "life": 0.17, "max": 0.17, "color": Color("ffc678") if heavy else CYAN})

func enemy_swing(point: Vector2) -> void:
	effects.append({"kind": "ring", "pos": point, "radius": 40.0, "life": 0.16, "max": 0.16, "color": Color("ff7c91")})

func update_effects(delta: float) -> void:
	for i in range(effects.size() - 1, -1, -1):
		effects[i]["life"] -= delta
		if effects[i]["life"] <= 0.0:
			effects.remove_at(i)
			continue
		if effects[i].has("vel"):
			effects[i]["pos"] += effects[i]["vel"] * delta
			if effects[i]["kind"] == "spark":
				effects[i]["vel"].y += 380.0 * delta

func setup_hud() -> void:
	var canvas: CanvasLayer = CanvasLayer.new()
	canvas.layer = 10
	add_child(canvas)
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	canvas.add_child(hud)
	label(hud, "A E R I A L", Vector2(44.0, 28.0), 32, Color.WHITE)
	label(hud, "CUSHION LAB  /  사방 반사 전투", Vector2(46.0, 73.0), 12, MUTED)
	label(hud, "VITALS", Vector2(45.0, 110.0), 11, MUTED)
	var health_bg: ColorRect = rectangle(hud, Rect2(45.0, 134.0, 240.0, 8.0), Color("233148"))
	health_fill = rectangle(health_bg, Rect2(0.0, 0.0, 240.0, 8.0), CYAN)
	health_label = label(hud, "100 / 100", Vector2(305.0, 121.0), 18, Color.WHITE)
	wave_label = label(hud, "ROOM  01 / 06", Vector2(998.0, 35.0), 22, Color.WHITE)
	count_label = label(hud, "", Vector2(1000.0, 73.0), 13, MUTED)
	combo_label = label(hud, "", Vector2(575.0, 22.0), 58, CYAN)
	combo_label.size = Vector2(280.0, 80.0)
	combo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_caption = label(hud, "", Vector2(500.0, 110.0), 13, MUTED)
	combo_caption.size.x = 425.0
	combo_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tip_label = label(hud, "J 3연타로 날리기 · 3쿠션 후 정산 · 생존하면 바닥으로 낙하", Vector2(44.0, 595.0), 16, Color("d6e4f5"))
	cooldown_label = label(hud, "", Vector2(850.0, 595.0), 14, CYAN)
	build_label = label(hud, "BUILD  /  기본 장비", Vector2(44.0, 630.0), 12, MUTED)
	label(hud, "A D  이동     SPACE  점프     J  공격     K  띄우기     L / SHIFT  회피", Vector2(44.0, 678.0), 13, Color("b5c3d6"))
	label(hud, "ESC  일시정지    M  소리    F3  판정", Vector2(954.0, 678.0), 11, MUTED)
	modal = Control.new()
	modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.add_child(modal)

func update_hud() -> void:
	if not is_instance_valid(player):
		return
	health_fill.size.x = 240.0 * maxf(0.0, player.hp / player.max_hp)
	health_fill.color = CYAN if player.hp > player.max_hp * 0.3 else Color("ff7c91")
	health_label.text = "%d / %d" % [ceili(player.hp), int(player.max_hp)]
	wave_label.text = "ROOM  %02d / %02d" % [wave, TOTAL_ROOMS]
	var room_name: String = ROOM_NAMES[mini(current_room, ROOM_NAMES.size() - 1)] if current_room < ROOM_NAMES.size() else ""
	count_label.text = "%s  ·  적 %02d  ·  %02d:%02d" % [room_name, alive_count(), int(elapsed) / 60, int(elapsed) % 60]
	combo_label.text = "%02d" % last_cushions if cushion_feedback > 0.0 else ""
	combo_caption.text = cushion_caption if cushion_feedback > 0.0 else "최대 3쿠션 · 기둥도 반사면"
	cooldown_label.text = "회피 %s   ·   띄우기 %s%s" % ["준비" if player.dash_cooldown <= 0.0 else "%.1fs" % player.dash_cooldown, "준비" if player.launch_cooldown <= 0.0 else "%.1fs" % player.launch_cooldown, "   음소거" if not sound_on else ""]
	var names: PackedStringArray = PackedStringArray()
	for upgrade: Dictionary in UPGRADES:
		if chosen.has(upgrade.id):
			names.append(upgrade.name + (" ×%d" % chosen[upgrade.id] if chosen[upgrade.id] > 1 else ""))
	build_label.text = "BUILD  /  " + (" · ".join(names) if not names.is_empty() else "기본 장비")

func rectangle(parent: Node, rect: Rect2, color: Color) -> ColorRect:
	var item: ColorRect = ColorRect.new()
	item.position = rect.position
	item.size = rect.size
	item.color = color
	item.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(item)
	return item

func label(parent: Node, text: String, pos: Vector2, size_px: int, color: Color) -> Label:
	var item: Label = Label.new()
	item.text = text
	item.position = pos
	item.add_theme_font_override("font", font)
	item.add_theme_font_size_override("font_size", size_px)
	item.add_theme_color_override("font_color", color)
	item.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(item)
	return item

func button(parent: Node, text: String, rect: Rect2, callback: Callable, color: Color = CYAN) -> Button:
	var item: Button = Button.new()
	item.text = text
	item.position = rect.position
	item.size = rect.size
	item.add_theme_font_override("font", font)
	item.add_theme_font_size_override("font_size", 17)
	item.add_theme_color_override("font_color", INK)
	item.add_theme_color_override("font_hover_color", INK)
	item.add_theme_color_override("font_focus_color", INK)
	for state: String in ["normal", "hover", "pressed", "focus"]:
		var style: StyleBoxFlat = StyleBoxFlat.new()
		style.bg_color = color.lightened(0.15) if state == "hover" else color
		style.corner_radius_top_left = 5
		style.corner_radius_top_right = 5
		style.corner_radius_bottom_left = 5
		style.corner_radius_bottom_right = 5
		if state == "focus":
			style.bg_color = Color.TRANSPARENT
			style.set_border_width_all(2)
			style.border_color = Color.WHITE
		item.add_theme_stylebox_override(state, style)
	item.pressed.connect(callback)
	parent.add_child(item)
	return item

func clear_modal() -> void:
	for child in modal.get_children():
		modal.remove_child(child)
		child.queue_free()
	modal.mouse_filter = Control.MOUSE_FILTER_IGNORE

func modal_backdrop() -> void:
	clear_modal()
	modal.mouse_filter = Control.MOUSE_FILTER_STOP
	rectangle(modal, Rect2(0.0, 0.0, 1280.0, 720.0), Color(0.025, 0.035, 0.06, 0.94))

func show_title() -> void:
	modal_backdrop()
	label(modal, "P R O T O T Y P E   0 2   /   C U S H I O N", Vector2(86.0, 72.0), 14, CYAN)
	label(modal, "AERIAL", Vector2(80.0, 122.0), 94, Color.WHITE)
	label(modal, "날리고. 튕기고. 마지막에 펑.", Vector2(87.0, 260.0), 26, Color("dce7f4"))
	label(modal, "방마다 모양이 다릅니다. 기둥도 반사면입니다.\n직접 공격은 약하게. 벽 반사로 피해를 쌓아 터뜨리세요.", Vector2(89.0, 326.0), 17, MUTED)
	button(modal, "전투 시작    ↵", Rect2(88.0, 444.0, 280.0, 58.0), start_run)
	label(modal, "ENTER 시작  /  약 3~6분  /  키보드 조작", Vector2(90.0, 525.0), 13, MUTED)
	rectangle(modal, Rect2(746.0, 110.0, 1.0, 425.0), Color("27364c"))
	label(modal, "THE COMBO", Vector2(799.0, 125.0), 13, CYAN)
	var instructions: Array = [["01", "J → J → J", "약한 공격 3타로 적을 대각선으로 발사"], ["02", "벽 · 천장 · 기둥", "12 → 17 → 22… 반사할수록 피해 누적"], ["03", "L / SHIFT  회피", "돌아오는 적도 위험! 피하면서 폭발을 기다리기"]]
	for i in range(instructions.size()):
		var y: float = 188.0 + i * 112.0
		label(modal, instructions[i][0], Vector2(800.0, y), 18, CYAN)
		label(modal, instructions[i][1], Vector2(848.0, y - 4.0), 23, Color.WHITE)
		label(modal, instructions[i][2], Vector2(849.0, y + 36.0), 13, MUTED)
	label(modal, "A D / ← → 이동       SPACE 점프       M 소리 켜기·끄기", Vector2(89.0, 649.0), 14, MUTED)

func show_upgrades() -> void:
	phase = "upgrade"
	hit_stop = 0.0
	combo = 0
	offered.clear()
	var pool: Array[Dictionary] = []
	for upgrade: Dictionary in UPGRADES:
		if upgrade.id in ["lightning", "wall", "dash", "launch"] and chosen.has(upgrade.id):
			continue
		pool.append(upgrade)
	for i in range(3):
		var index: int = rng.randi_range(0, pool.size() - 1)
		offered.append(pool[index])
		pool.remove_at(index)
	modal_backdrop()
	label(modal, "ROOM %02d  COMPLETE  /  %s" % [wave, ROOM_NAMES[mini(current_room, ROOM_NAMES.size() - 1)]], Vector2(100.0, 90.0), 14, CYAN)
	label(modal, "다음 콤보를 고르세요.", Vector2(96.0, 130.0), 42, Color.WHITE)
	label(modal, "강화 1개 선택  ·  다음 방 시작 시 체력 12 회복", Vector2(100.0, 196.0), 16, MUTED)
	for i in range(offered.size()):
		var upgrade: Dictionary = offered[i]
		var x: float = 100.0 + i * 367.0
		var color: Color = Color(upgrade.color)
		rectangle(modal, Rect2(x, 272.0, 346.0, 280.0), Color("121e30"))
		rectangle(modal, Rect2(x, 272.0, 346.0, 3.0), color)
		label(modal, "0%d  /  %s" % [i + 1, upgrade.tag], Vector2(x + 22.0, 297.0), 13, color)
		label(modal, upgrade.name, Vector2(x + 22.0, 341.0), 25, Color.WHITE)
		var desc: Label = label(modal, upgrade.desc, Vector2(x + 22.0, 391.0), 15, Color("a9bbd3"))
		desc.size = Vector2(302.0, 72.0)
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		button(modal, "%d   선택" % [i + 1], Rect2(x + 22.0, 485.0, 302.0, 44.0), choose_upgrade.bind(i), color)
	label(modal, "숫자 1 · 2 · 3 또는 버튼 클릭으로 선택", Vector2(100.0, 603.0), 14, MUTED)

func choose_upgrade(index: int) -> void:
	if phase != "upgrade" or index < 0 or index >= offered.size():
		return
	apply_upgrade(offered[index].id)
	player.hp = minf(player.max_hp, player.hp + 12.0)
	clear_modal()
	sound("upgrade")
	start_transition()

func apply_upgrade(id: String) -> void:
	chosen[id] = int(chosen.get(id, 0)) + 1
	match id:
		"power": player.cushion_scale += 0.25
		"air": player.cushion_scale += 0.20
		"lightning": player.chain_lightning = true
		"wall": player.wall_blast = true
		"dash": player.dash_recovery = 0.4
		"vitality":
			player.max_hp += 25.0
			player.hp = minf(player.max_hp, player.hp + 35.0)
		"leech": player.life_on_kill += 3.0
		"launch":
			player.launch_bonus += 90.0
			player.air_bonus += 0.15

func show_pause() -> void:
	modal_backdrop()
	label(modal, "PAUSED", Vector2(455.0, 208.0), 58, Color.WHITE)
	label(modal, "잠시 숨을 고르세요.", Vector2(493.0, 301.0), 21, MUTED)
	button(modal, "계속하기  /  ESC", Rect2(450.0, 378.0, 380.0, 55.0), resume_game)
	button(modal, "처음부터 다시  /  R", Rect2(450.0, 452.0, 380.0, 48.0), start_run, Color("b5c3d6"))

func resume_game() -> void:
	clear_modal()
	phase = "fight"

func finish_run(won: bool) -> void:
	phase = "won" if won else "lost"
	hit_stop = 0.0
	modal_backdrop()
	label(modal, "RUN COMPLETE" if won else "TRY AGAIN", Vector2(140.0, 139.0), 15, CYAN)
	label(modal, "멋진 마무리." if won else "다음 콤보는 더 길게.", Vector2(135.0, 186.0), 52, Color.WHITE)
	label(modal, "모든 방을 돌파했습니다." if won else "튕겨 돌아오는 적도 피하세요. 피해는 콤보 마지막에 정산됩니다.", Vector2(141.0, 279.0), 18, MUTED)
	label(modal, "ROOM\n%02d / %02d" % [wave, TOTAL_ROOMS], Vector2(141.0, 358.0), 23, Color("dce7f4"))
	label(modal, "BEST CUSHION\n%d BOUNCES" % best_cushions, Vector2(391.0, 358.0), 23, CYAN)
	label(modal, "DEFEATED\n%d" % kills, Vector2(681.0, 358.0), 23, Color("dce7f4"))
	label(modal, "TIME\n%02d:%02d" % [int(elapsed) / 60, int(elapsed) % 60], Vector2(949.0, 358.0), 23, Color("dce7f4"))
	button(modal, "다시 도전  /  ENTER", Rect2(140.0, 514.0, 330.0, 60.0), start_run)

func setup_audio() -> void:
	var presets: Dictionary = {"swing": [240.0, 0.06, 0.09], "hit": [125.0, 0.09, 0.2], "heavy": [67.0, 0.16, 0.25], "jump": [480.0, 0.1, 0.07], "dash": [320.0, 0.1, 0.1], "hurt": [92.0, 0.2, 0.22], "kill": [420.0, 0.12, 0.13], "upgrade": [660.0, 0.3, 0.1]}
	for key: String in presets:
		var spec: Array = presets[key]
		var stream: AudioStreamWAV = AudioStreamWAV.new()
		stream.format = AudioStreamWAV.FORMAT_16_BITS
		stream.mix_rate = 22050
		var samples: int = int(float(spec[1]) * 22050)
		var data: PackedByteArray = PackedByteArray()
		data.resize(samples * 2)
		for i in range(samples):
			var t: float = float(i) / 22050.0
			var env: float = pow(1.0 - float(i) / samples, 2.0) * minf(t * 500.0, 1.0)
			var sample: float = sin(TAU * float(spec[0]) * t * (1.0 - t * 1.5))
			if key in ["hit", "heavy", "hurt", "dash"]:
				sample = sample * 0.6 + rng.randf_range(-0.4, 0.4)
			data.encode_s16(i * 2, int(sample * env * float(spec[2]) * 32767.0))
		stream.data = data
		tones[key] = stream
	for i in range(8):
		var audio: AudioStreamPlayer = AudioStreamPlayer.new()
		audio.volume_db = -8.0
		add_child(audio)
		audio_players.append(audio)

func sound(key: String) -> void:
	if not sound_on or not tones.has(key):
		return
	for audio in audio_players:
		if not audio.playing:
			audio.stream = tones[key]
			audio.play()
			return

func _draw() -> void:
	var level_left: float = rooms[0].left - 200.0
	var level_right: float = rooms[rooms.size() - 1].right + 200.0
	draw_rect(Rect2(level_left, -200.0, level_right - level_left, 1000.0), INK)
	for i in range(rooms.size()):
		draw_room(i)
	for i in range(rooms.size() - 1):
		draw_corridor(rooms[i], rooms[i + 1])
	# 플레이어 그림자
	if is_instance_valid(player) and not player.dead:
		draw_set_transform(Vector2(player.position.x, FLOOR_Y - 3.0), 0.0, Vector2(1.0, 0.18))
		draw_circle(Vector2.ZERO, maxf(12.0, 25.0 - (FLOOR_Y - player.position.y) * 0.025), Color(0.2, 0.9, 0.8, 0.14))
		draw_set_transform(Vector2.ZERO)
	# 이펙트
	for effect: Dictionary in effects:
		var color: Color = effect.color
		color.a *= clampf(float(effect.life) / float(effect.max), 0.0, 1.0)
		var point: Vector2 = effect.pos
		match effect.kind:
			"spark": draw_line(point, point - Vector2(effect.vel) * 0.028, color, 2.5, true)
			"text": draw_string(font, point, effect.text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 22, color)
			"ring": draw_arc(point, float(effect.radius) * (1.0 - float(effect.life) / float(effect.max) * 0.75), 0.0, TAU, 32, color, 3.0, true)
			"slash":
				var angle: float = 0.0 if effect.face > 0.0 else PI
				if effect.launch: angle = -PI * 0.5
				draw_arc(point, effect.radius, angle - 1.1, angle + 1.1, 24, color, 5.0, true)
			"bolt":
				var end: Vector2 = effect.end
				var mid: Vector2 = (point + end) * 0.5
				draw_polyline(PackedVector2Array([point, mid + Vector2(-13.0, -18.0), mid + Vector2(11.0, 14.0), end]), color, 3.0, true)
	if debug_boxes and is_instance_valid(player):
		draw_rect(player.hurtbox(), Color(0.1, 1.0, 0.3, 0.7), false, 1.0)
		if not player.attack_kind.is_empty():
			draw_rect(player.attack_rect(), Color(1.0, 0.9, 0.1, 0.5), false, 2.0)
		for enemy in enemies:
			if not enemy.dead:
				draw_rect(enemy.hurtbox(), Color(1.0, 0.3, 0.4, 0.7), false, 1.0)
		for pillar: Rect2 in room_pillars:
			draw_rect(pillar, Color(1.0, 1.0, 0.0, 0.3), false, 2.0)

func draw_room(index: int) -> void:
	var room: Dictionary = rooms[index]
	var left: float = room.left
	var right: float = room.right
	var top: float = float(room.top)
	var bottom: float = FLOOR_Y
	var wt: float = 20.0
	var room_h: float = bottom - top
	# 건물 실루엣
	var bx: float = left + 10.0
	var bi: int = 0
	var max_bh: float = room_h * 0.65
	while bx < right - 60.0:
		var height: float = minf(120.0 + float((bi * 71) % 140), max_bh)
		draw_rect(Rect2(bx, bottom - height, 62.0, height), Color("101c2c"))
		for j in range(3):
			if bottom - height + 18.0 > top:
				draw_rect(Rect2(bx + 12.0 + j * 15.0, bottom - height + 18.0, 4.0, 16.0), Color("20364a"))
		bx += 90.0
		bi += 1
	# 격자선
	var gx: float = left + 40.0
	while gx < right:
		draw_line(Vector2(gx, top + 2.0), Vector2(gx, bottom), Color(0.15, 0.24, 0.34, 0.16), 1.0)
		gx += 80.0
	# 중앙 장식
	var cx: float = (left + right) * 0.5
	var cy: float = (top + bottom) * 0.5 + 50.0
	var arc_r: float = minf(178.0, (right - left) * 0.2)
	draw_arc(Vector2(cx, cy), arc_r, PI, TAU, 64, Color("1d3445"), 1.0, true)
	draw_arc(Vector2(cx, cy), arc_r * 0.8, PI, TAU, 64, Color("182c3e"), 1.0, true)
	draw_line(Vector2(cx, top + 50.0), Vector2(cx, bottom - 50.0), Color("182c3e"), 1.0)
	if font != null:
		draw_string(font, Vector2(cx - 50.0, cy - 40.0), ROOM_NAMES[mini(index, ROOM_NAMES.size() - 1)], HORIZONTAL_ALIGNMENT_LEFT, -1.0, 26, Color("294257"))
		draw_string(font, Vector2(cx - 64.0, cy - 12.0), "C U S H I O N   /   0 %d" % (index + 1), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 12, Color("365167"))
	# 바닥
	draw_rect(Rect2(left - wt, bottom, right - left + wt * 2, 22.0), Color("182839"))
	draw_line(Vector2(left, bottom), Vector2(right, bottom), CYAN.darkened(0.2), 2.0)
	var fx: float = left + 16.0
	while fx < right:
		draw_line(Vector2(fx, bottom + 5.0), Vector2(fx - 10.0, bottom + 16.0), Color("2a4052"), 2.0)
		fx += 24.0
	# 천장
	draw_rect(Rect2(left - wt, top - 18.0, right - left + wt * 2, 18.0), Color("203344"))
	draw_line(Vector2(left, top), Vector2(right, top), CYAN, 3.0)
	var dx: float = left + 20.0
	while dx < right:
		draw_circle(Vector2(dx, top - 9.0), 2.0, Color("9fb9ba"))
		dx += 56.0
	# 왼벽
	var draw_left: bool = not (phase == "transition" and index == current_room + 1)
	if draw_left:
		draw_rect(Rect2(left - wt, top - 18.0, wt, bottom - top + 40.0), Color("203344"))
		draw_line(Vector2(left, top), Vector2(left, bottom), CYAN, 3.0)
		var wy: float = top + 20.0
		while wy < bottom:
			draw_circle(Vector2(left - 10.0, wy), 2.0, Color("9fb9ba"))
			wy += 48.0
	# 오른벽
	var draw_right: bool = not (phase == "transition" and index == current_room)
	if draw_right:
		draw_rect(Rect2(right, top - 18.0, wt, bottom - top + 40.0), Color("203344"))
		draw_line(Vector2(right, top), Vector2(right, bottom), CYAN, 3.0)
		var wy2: float = top + 20.0
		while wy2 < bottom:
			draw_circle(Vector2(right + 10.0, wy2), 2.0, Color("9fb9ba"))
			wy2 += 48.0
	# 기둥
	for pillar: Rect2 in room.pillars:
		draw_rect(pillar, Color("203344"))
		draw_rect(Rect2(pillar.position.x + 3.0, pillar.position.y + 3.0, pillar.size.x - 6.0, pillar.size.y - 6.0), Color("182839"))
		# 기둥 반사면 강조
		draw_line(pillar.position, Vector2(pillar.end.x, pillar.position.y), CYAN.darkened(0.3), 2.0)
		draw_line(Vector2(pillar.position.x, pillar.end.y), pillar.end, CYAN.darkened(0.3), 2.0)
		draw_line(pillar.position, Vector2(pillar.position.x, pillar.end.y), CYAN.darkened(0.3), 2.0)
		draw_line(Vector2(pillar.end.x, pillar.position.y), pillar.end, CYAN.darkened(0.3), 2.0)
		# 기둥 리벳
		var py: float = pillar.position.y + 15.0
		while py < pillar.end.y:
			draw_circle(Vector2(pillar.position.x + 8.0, py), 1.5, Color("9fb9ba"))
			draw_circle(Vector2(pillar.end.x - 8.0, py), 1.5, Color("9fb9ba"))
			py += 32.0

func draw_corridor(room_a: Dictionary, room_b: Dictionary) -> void:
	var left_end: float = room_a.right
	var right_start: float = room_b.left
	draw_rect(Rect2(left_end, FLOOR_Y, right_start - left_end, 22.0), Color("182839"))
	draw_line(Vector2(left_end, FLOOR_Y), Vector2(right_start, FLOOR_Y), CYAN.darkened(0.5), 1.0)
	var fx: float = left_end + 16.0
	while fx < right_start:
		draw_line(Vector2(fx, FLOOR_Y + 5.0), Vector2(fx - 10.0, FLOOR_Y + 16.0), Color("2a4052"), 1.0)
		fx += 32.0
	# 복도 천장 연결선 (높이 차이 시각화)
	var top_a: float = float(room_a.top)
	var top_b: float = float(room_b.top)
	if absf(top_a - top_b) > 10.0:
		draw_line(Vector2(left_end, top_a), Vector2(right_start, top_b), Color("203344"), 2.0)

func register_cushion(enemy: Node2D, point: Vector2, damage: float) -> void:
	last_cushions = enemy.cushions
	best_cushions = maxi(best_cushions, last_cushions)
	cushion_feedback = 3.5
	cushion_caption = "CUSHION  /  누적 %d · 필요 %d" % [ceili(enemy.pending_damage), ceili(enemy.hp)]
	register_hit(point, damage, true, true)
	burst(point, Color("ffc678"), 20)
	effects.append({"kind": "ring", "pos": point, "radius": 62.0, "life": 0.3, "max": 0.3, "color": Color("ffc678")})
	effects.append({"kind": "text", "pos": Vector2(clampf(point.x - 50.0, 85.0, 1080.0), clampf(point.y, 230.0, 525.0)), "vel": Vector2(0.0, -24.0), "life": 0.85, "max": 0.85, "text": "%d쿠션 +%d" % [last_cushions, ceili(damage)], "color": Color("ffc678")})

func detonate(enemy: Node2D, damage: float) -> void:
	var point: Vector2 = enemy.position + Vector2(0.0, -32.0)
	enemy_defeated(enemy)
	burst(point, Color("ffc678"), 48)
	burst(point, Color.WHITE, 16)
	effects.append({"kind": "ring", "pos": point, "radius": 135.0, "life": 0.5, "max": 0.5, "color": Color("ffc678")})
	effects.append({"kind": "ring", "pos": point, "radius": 83.0, "life": 0.34, "max": 0.34, "color": Color.WHITE})
	effects.append({"kind": "text", "pos": point + Vector2(-42.0, -20.0), "vel": Vector2(0.0, -45.0), "life": 1.0, "max": 1.0, "text": "펑! %d" % ceili(damage), "color": Color("ffc678")})
	hit_stop = 0.09
	shake = 12.0
	sound("heavy")
	cushion_feedback = 2.0
	cushion_caption = "콤보 정산 %d  /  폭발!" % ceili(damage)
	if player.wall_blast:
		explode(enemy.position, 145.0, 24.0, enemy)

func damage_survived(enemy: Node2D, damage: float) -> void:
	if damage <= 0.0:
		return
	var point: Vector2 = enemy.position + Vector2(-45.0, -90.0)
	effects.append({"kind": "text", "pos": point, "vel": Vector2(0.0, -25.0), "life": 0.9, "max": 0.9, "text": "생존 · HP %d" % ceili(enemy.hp), "color": Color("88b9ff")})
	cushion_feedback = 1.6
	cushion_caption = "콤보 정산 %d  /  적 생존 · HP %d" % [ceili(damage), ceili(enemy.hp)]
