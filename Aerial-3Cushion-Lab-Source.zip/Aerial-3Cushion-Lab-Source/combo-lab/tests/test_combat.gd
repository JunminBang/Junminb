extends SceneTree
## Run with Godot --headless --path . --script res://tests/test_combat.gd
var arena: Node
var checks: int = 0
var failures: int = 0

func _initialize() -> void:
	run.call_deferred()

func check(condition: bool, message: String) -> void:
	checks += 1
	if condition:
		print("PASS: ", message)
	else:
		failures += 1
		push_error("FAIL: " + message)

func fresh() -> void:
	arena.start_run()
	arena.sound_on = false
	arena.set_physics_process(false)
	arena.player.position = Vector2(500.0, 554.0)
	for i in range(arena.enemies.size()):
		arena.enemies[i].position = Vector2(560.0 if i == 0 else 1100.0 + i * 30.0, 554.0)
		arena.enemies[i].hp = 1000.0
		arena.enemies[i].max_hp = 1000.0
		arena.enemies[i].move_speed = 0.0
		arena.enemies[i].cooldown = 100.0

func frames(count: int) -> void:
	for i in range(count):
		arena._physics_process(1.0 / 60.0)

func run() -> void:
	arena = load("res://scenes/main.tscn").instantiate()
	root.add_child(arena)
	await process_frame
	arena.set_physics_process(false)
	check(arena.phase == "title", "Title loads")
	fresh()
	check(arena.wave == 1 and arena.alive_count() == 3, "First room spawns three enemies")
	# Direct attacks are rebalanced: stronger but still weaker than cushion.
	arena.player.begin_attack("normal")
	arena.player.resolve_attack()
	arena.player.resolve_attack()
	check(arena.enemies[0].pending_damage == 5.0 and arena.enemies[0].hp == 1000.0, "One weak hit banks 5 damage without immediate HP loss")
	arena.player.begin_attack("normal")
	arena.player.resolve_attack()
	arena.player.begin_attack("normal")
	arena.player.resolve_attack()
	check(arena.enemies[0].pending_damage == 25.0, "Three-hit direct damage is 5 + 8 + 12")
	check(arena.enemies[0].thrown and arena.enemies[0].velocity.x == 1150.0, "Third hit begins diagonal ricochet")
	fresh()
	arena.enemies[0].position.x = 440.0
	arena.player.begin_attack("normal")
	arena.player.resolve_attack()
	check(arena.enemies[0].pending_damage == 0.0, "Attacks cannot hit behind player")
	# All four wall faces reflect only incoming motion.
	var starts: Array[Vector2] = [Vector2(81.0, 400.0), Vector2(1199.0, 400.0), Vector2(700.0, 255.0), Vector2(700.0, 552.0)]
	var forces: Array[Vector2] = [Vector2(-1000.0, 0.0), Vector2(1000.0, 0.0), Vector2(0.0, -1000.0), Vector2(0.0, 1000.0)]
	for side in range(4):
		fresh()
		var enemy: Node = arena.enemies[0]
		enemy.position = starts[side]
		enemy.take_hit(0.0, forces[side], 0.4, true)
		enemy.tick(0.01)
		check(enemy.cushions == 1 and enemy.pending_damage == 12.0, "Wall face %d awards one cushion hit" % side)
		check(enemy.velocity.dot(forces[side]) < 0.0, "Wall face %d reverses direction" % side)
		enemy.tick(0.001)
		check(enemy.cushions == 1, "Wall face %d does not retrigger while leaving" % side)
	fresh()
	var enemy: Node = arena.enemies[0]
	enemy.position = Vector2(80.0, 254.0)
	enemy.take_hit(0.0, Vector2(-600.0, -600.0), 0.4, true)
	enemy.tick(0.01)
	check(enemy.cushions == 1 and enemy.velocity.x > 0.0 and enemy.velocity.y > 0.0, "Corner reflects both axes but awards a single contact")
	fresh()
	enemy = arena.enemies[0]
	enemy.take_hit(9.0, Vector2(1150.0, -520.0), 0.4, true)
	for i in range(3):
		enemy.on_cushion(Vector2(64.0, 300.0))
	check(enemy.pending_damage == 60.0 and enemy.hp == 1000.0, "Cushions add 12 + 17 + 22 to banked direct damage")
	enemy.on_cushion(Vector2(1216.0, 300.0))
	enemy.on_cushion(Vector2(700.0, 554.0))
	check(enemy.cushions == 3 and enemy.pending_damage == 60.0, "Fourth and fifth cushion events add neither damage nor bounces")
	enemy.shot_age = 2.0
	enemy.take_hit(4.0, Vector2(-1150.0, -520.0), 0.4, true)
	check(enemy.cushions == 3 and enemy.shot_age == 2.0 and enemy.pending_damage == 64.0, "Re-hit redirects without resetting accumulated combo or timer")
	# Physical path, including long frames, remains inside the sealed room.
	fresh()
	enemy = arena.enemies[0]
	enemy.position = Vector2(570.0, 490.0)
	enemy.take_hit(9.0, Vector2(1150.0, -520.0), 0.4, true)
	var bounded: bool = true
	var observed_cushions: int = 0
	for i in range(210):
		enemy.tick(1.0 / 60.0)
		observed_cushions = maxi(observed_cushions, enemy.cushions)
		if enemy.position.x < 79.0 or enemy.position.x > 1201.0 or enemy.position.y < 253.0 or enemy.position.y > 554.0:
			bounded = false
	check(bounded and observed_cushions == 3, "Real diagonal trajectory stops at exactly three cushions and stays inside")
	check(not enemy.dead and enemy.hp < 1000.0 and enemy.pending_damage == 0.0, "Insufficient ricochet damage resolves once and leaves a living enemy")
	check(not enemy.thrown and not enemy.settling, "Survivor returns to normal combat")
	check(enemy.on_ground() and is_equal_approx(enemy.hp, 940.0), "Three-cushion survivor falls to floor with exactly 60 damage")
	var landed_hp: float = enemy.hp
	for i in range(90):
		enemy.tick(1.0 / 60.0)
	check(enemy.on_ground() and enemy.hp == landed_hp and enemy.cushions == 0, "Landing does not start another bounce or add cushion damage")
	fresh()
	enemy = arena.enemies[0]
	enemy.position = Vector2(500.0, 400.0)
	enemy.take_hit(1.0, Vector2(9000.0, -5000.0), 0.4, true)
	enemy.tick(0.4)
	check(enemy.position.x >= 79.0 and enemy.position.x <= 1201.0 and enemy.position.y >= 253.0 and enemy.position.y <= 554.0, "Substeps prevent tunneling on fast long frames")
	fresh()
	enemy = arena.enemies[0]
	enemy.position = Vector2(700.0, 255.0)
	enemy.take_hit(9.0, Vector2(0.0, -1000.0), 0.4, true)
	enemy.on_cushion(Vector2(64.0, 400.0))
	enemy.on_cushion(Vector2(1216.0, 400.0))
	enemy.tick(0.01)
	check(enemy.cushions == 3 and enemy.settling and not enemy.thrown and enemy.velocity == Vector2.ZERO, "Third ceiling contact immediately stops ricochet")
	enemy.tick(0.3)
	var drop_y: float = enemy.position.y
	enemy.tick(0.1)
	check(not enemy.dead and enemy.position.y > drop_y and enemy.velocity.y > 0.0 and not enemy.thrown, "Surviving ceiling settlement switches to downward gravity")
	# Sufficient damage does not kill until the final settlement beat.
	fresh()
	enemy = arena.enemies[0]
	enemy.hp = 50.0
	enemy.position = Vector2(700.0, 400.0)
	enemy.take_hit(9.0, Vector2(1150.0, -520.0), 0.4, true)
	for i in range(3):
		enemy.on_cushion(Vector2(64.0, 300.0))
	check(enemy.pending_damage >= enemy.hp and not enemy.dead and arena.kills == 0, "Crossing lethal threshold does not kill during flight")
	enemy.finish_sequence()
	enemy.tick(0.15)
	check(not enemy.dead and enemy.settling and arena.kills == 0, "Final fuse delays explosion")
	enemy.tick(0.14)
	check(enemy.dead and enemy.hp == 0.0 and arena.kills == 1, "Sufficient damage explodes at final settlement")
	var has_boom: bool = false
	for effect: Dictionary in arena.effects:
		if effect.get("kind") == "text" and str(effect.get("text", "")).begins_with("펑!"):
			has_boom = true
	check(has_boom, "Lethal settlement creates explicit explosion effect")
	enemy.resolve_damage()
	enemy.take_hit(999.0, Vector2.ZERO, 0.0)
	check(arena.kills == 1, "Explosion cannot award duplicate kills")
	fresh()
	enemy = arena.enemies[0]
	enemy.hp = 60.0
	enemy.take_hit(20.0, Vector2.ZERO, 0.1)
	enemy.finish_sequence()
	enemy.tick(0.3)
	check(not enemy.dead and enemy.hp == 40.0, "Insufficient damage is committed and remaining HP persists")
	enemy.take_hit(40.0, Vector2.ZERO, 0.1)
	enemy.finish_sequence()
	enemy.tick(0.3)
	check(enemy.dead, "Exact remaining HP is sufficient for final explosion")
	fresh()
	enemy = arena.enemies[0]
	enemy.take_hit(2.0, Vector2.ZERO, 0.1)
	for i in range(90):
		enemy.tick(1.0 / 60.0)
	check(enemy.pending_damage == 0.0 and enemy.hp == 998.0, "A stopped weak combo settles without trapping the enemy")
	# Player takes damage immediately, including from returning ricochets.
	fresh()
	arena.player.invincible = 0.0
	arena.player.take_hit(11.0, Vector2.ZERO)
	check(arena.player.hp == 89.0, "Player damage is immediate rather than banked")
	fresh()
	enemy = arena.enemies[0]
	enemy.position = arena.player.position
	enemy.take_hit(0.0, Vector2(500.0, -20.0), 0.4, true)
	arena.player.invincible = 0.0
	enemy.check_thrown_contacts()
	check(arena.player.hp == 100.0, "Launch grace prevents unavoidable point-blank self-hit")
	enemy.shot_age = 0.4
	enemy.contact_cooldown = 0.0
	enemy.check_thrown_contacts()
	check(arena.player.hp == 91.0, "Returning projectile contact hurts player immediately")
	enemy.check_thrown_contacts()
	check(arena.player.hp == 91.0, "Contact cooldown prevents repeated damage in one contact")
	fresh()
	arena.player.start_dash()
	arena.player.take_hit(20.0, Vector2.ZERO)
	check(arena.player.hp == 100.0 and arena.player.attack_kind.is_empty(), "Dash cancels attacks and blocks incoming hits")
	frames(20)
	arena.player.take_hit(20.0, Vector2.ZERO)
	check(arena.player.hp == 80.0, "Dash invulnerability expires normally")
	fresh()
	arena.player.position = Vector2(80.0, 254.0)
	arena.player.velocity = Vector2(-1000.0, -1000.0)
	arena.player.integrate(0.1)
	check(arena.player.position.x == 79.0 and arena.player.position.y == 253.0, "Player cannot leave through ceiling or left wall")
	arena.player.position = Vector2(1200.0, 553.0)
	arena.player.velocity = Vector2(1000.0, 1000.0)
	arena.player.integrate(0.1)
	check(arena.player.position.x == 1201.0 and arena.player.position.y == 554.0, "Player cannot leave through floor or right wall")
	# AI and original aerial controls still work under the new damage model.
	fresh()
	arena.player.invincible = 0.0
	arena.enemies[0].cooldown = 0.0
	frames(1)
	check(arena.enemies[0].windup > 0.0 and arena.player.hp == 100.0, "Enemy attack still telegraphs")
	frames(34)
	check(arena.player.hp < 100.0, "Enemy attack deals immediate player damage")
	fresh()
	arena.player.begin_attack("launch")
	frames(12)
	check(arena.player.position.y < 554.0 and arena.enemies[0].position.y < 554.0, "Launcher still lifts both combatants")
	arena.player.attack_buffer = 0.22
	frames(15)
	arena.player.attack_buffer = 0.22
	frames(14)
	arena.player.attack_buffer = 0.22
	frames(14)
	check(arena.enemies[0].thrown and arena.enemies[0].pending_damage >= 25.0, "Buffered aerial three-hit chain starts ricochet")
	# Upgrades enhance cushions, and splash damage is also banked.
	fresh()
	arena.apply_upgrade("power")
	arena.apply_upgrade("air")
	arena.enemies[0].on_cushion(Vector2(64.0, 400.0))
	check(is_equal_approx(arena.enemies[0].pending_damage, 12.0 * 1.45) and arena.player.damage_scale == 1.0, "Damage upgrades strengthen cushions while direct attacks stay weak")
	fresh()
	arena.apply_upgrade("lightning")
	arena.enemies[1].position = Vector2(710.0, 554.0)
	for i in range(3):
		arena.enemies[0].on_cushion(Vector2(64.0, 400.0))
	check(arena.enemies[1].pending_damage == 18.0 and arena.enemies[1].hp == 1000.0, "Third-cushion lightning adds deferred damage")
	fresh()
	arena.apply_upgrade("wall")
	arena.enemies[1].position.x = 630.0
	arena.enemies[0].hp = 10.0
	arena.enemies[0].take_hit(20.0, Vector2.ZERO, 0.0)
	check(arena.enemies[1].pending_damage == 0.0, "Explosion upgrade does not trigger before final detonation")
	arena.enemies[0].finish_sequence()
	arena.enemies[0].tick(0.3)
	check(arena.enemies[1].pending_damage == 24.0 and not arena.enemies[1].dead, "Final explosion banks nearby damage instead of killing immediately")
	fresh()
	arena.apply_upgrade("leech")
	arena.player.hp = 50.0
	arena.enemies[0].take_hit(1001.0, Vector2.ZERO, 0.0)
	check(arena.player.hp == 50.0, "No kill heal before the final explosion")
	arena.enemies[0].finish_sequence()
	arena.enemies[0].tick(0.3)
	check(arena.player.hp == 53.0, "Kill heal occurs on final explosion")
	fresh()
	for id in ["launch", "dash", "wall", "lightning"]:
		arena.apply_upgrade(id)
	arena.show_upgrades()
	var unique_unlocks: bool = true
	for upgrade: Dictionary in arena.offered:
		if upgrade.id in ["launch", "dash", "wall", "lightning"]:
			unique_unlocks = false
	check(unique_unlocks, "Already owned unique upgrades are not offered")
	# Delayed deaths gate room completion correctly, with transitions between rooms.
	fresh()
	for stage in range(1, 7):
		for target in arena.enemies:
			target.take_hit(2000.0, Vector2.ZERO, 0.0)
		check(arena.alive_count() > 0 and arena.phase == "fight", "Room %d waits for pending deaths" % stage)
		frames(160)
		if stage < 6:
			check(arena.phase == "upgrade" and arena.offered.size() == 3, "Room %d ends after explosions and offers upgrades" % stage)
			arena.choose_upgrade(0)
			frames(40)
	check(arena.phase == "won" and arena.kills == 33, "Six-room run ends after 33 final explosions")
	fresh()
	arena.enemies[0].take_hit(2000.0, Vector2(1000.0, -500.0), 0.0, true)
	arena.phase = "pause"
	var before: Vector2 = arena.enemies[0].position
	frames(120)
	check(arena.enemies[0].position == before and not arena.enemies[0].dead, "Pause freezes ricochet and settlement")
	arena.resume_game()
	check(arena.phase == "fight", "Resume returns to combat")
	arena.player.invincible = 0.0
	arena.player.take_hit(200.0, Vector2.ZERO)
	check(arena.phase == "lost", "Player zero HP immediately ends run")
	arena.start_run()
	check(arena.phase == "fight" and arena.player.hp == 100.0 and arena.chosen.is_empty() and arena.best_cushions == 0, "Restart clears damage, upgrades, and cushion records")
	fresh()
	arena.set_physics_process(true)
	Input.action_press("move_right")
	for i in range(12):
		await physics_frame
	Input.action_release("move_right")
	check(arena.player.position.x > 510.0, "Live movement input works")
	Input.action_press("jump")
	await physics_frame
	await physics_frame
	Input.action_release("jump")
	check(arena.player.position.y < 554.0, "Live jump input works")
	arena.set_physics_process(false)
	print("RESULT: %d checks, %d failures" % [checks, failures])
	arena.free()
	await process_frame
	quit(1 if failures else 0)
