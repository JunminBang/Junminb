extends SceneTree

func _initialize() -> void:
	var file: FileAccess = FileAccess.open("res://GODOT-NOTICES.txt", FileAccess.WRITE)
	if file == null:
		quit(1)
		return
	file.store_string("AERIAL / Combo Lab - Godot Engine and third-party notices\n\n")
	file.store_string(Engine.get_license_text())
	file.store_string("\n\nCOPYRIGHT INFORMATION\n\n")
	file.store_string(JSON.stringify(Engine.get_copyright_info(), "  "))
	file.store_string("\n\nTHIRD-PARTY LICENSE TEXTS\n\n")
	var licenses: Dictionary = Engine.get_license_info()
	for license_name: String in licenses:
		file.store_string(license_name + "\n" + String(licenses[license_name]) + "\n\n")
	file.close()
	quit(0)
